//#region node_modules/jalaali-js/dist/index.js
/**
* Jalaali years that begin a new 33-year leap cycle. Used by the
* Borkowski algorithm to locate the correct cycle for any given year.
*/
var BREAKS = [
	-61,
	9,
	38,
	199,
	426,
	686,
	756,
	818,
	1111,
	1181,
	1210,
	1635,
	2060,
	2097,
	2192,
	2262,
	2324,
	2394,
	2456,
	3178
];
/** Minimum supported Jalaali year (inclusive). */
var MIN_JALAALI_YEAR = BREAKS[0];
/** Maximum supported Jalaali year (inclusive). */
var MAX_JALAALI_YEAR = BREAKS[BREAKS.length - 1] - 1;
function toJalaali(gyOrDate, gm, gd) {
	if (gyOrDate instanceof Date) return d2j(g2d(gyOrDate.getFullYear(), gyOrDate.getMonth() + 1, gyOrDate.getDate()));
	return d2j(g2d(gyOrDate, gm, gd));
}
/**
* Returns `true` if the given Jalaali year is leap (366 days).
*
* @example
* isLeapJalaaliYear(1394) // false
* isLeapJalaaliYear(1395) // true
*
* @throws {RangeError} if `jy` falls outside `[-61, 3177]`.
*/
function isLeapJalaaliYear(jy) {
	return jalCalLeap(jy) === 0;
}
/**
* Returns the number of days in the given Jalaali month.
*
* The function trusts its inputs: `jm` is not range-checked, and an
* out-of-range `jm` will return whichever branch happens to match.
* For input validation, use {@link isValidJalaaliDate} instead.
*
* @example
* jalaaliMonthLength(1394, 12) // 29 (common year)
* jalaaliMonthLength(1395, 12) // 30 (leap year)
*/
function jalaaliMonthLength(jy, jm) {
	if (jm <= 6) return 31;
	if (jm <= 11) return 30;
	return isLeapJalaaliYear(jy) ? 30 : 29;
}
/**
* Computes the leap-cycle state of a Jalaali year and the Gregorian date
* of Farvardin 1 in that year.
*
* Use this directly when you need the leap field; if you only need
* `{ gy, march }`, prefer {@link jalCalShort}.
*
* @example
* jalCal(1391) // { leap: 0, gy: 2012, march: 20 }
* jalCal(1395) // { leap: 0, gy: 2016, march: 20 }
*
* @throws {RangeError} if `jy` falls outside `[-61, 3177]`.
*/
function jalCal(jy) {
	const { gy, march, jump, n } = jalCalCore(jy);
	return {
		leap: leapFromCycle(jump, n),
		gy,
		march
	};
}
/**
* Like {@link jalCal} but omits the leap-cycle computation.
*
* @remarks
* Equivalent to v1's `jalCal(jy, true)` — extracted to its own export
* in v2 to give it a proper return type. Prefer this when the leap field
* isn't needed; it avoids a small amount of work per call.
*
* @example
* jalCalShort(1391) // { gy: 2012, march: 20 }
*
* @throws {RangeError} if `jy` falls outside `[-61, 3177]`.
*/
function jalCalShort(jy) {
	const { gy, march } = jalCalCore(jy);
	return {
		gy,
		march
	};
}
/**
* Converts a Jalaali date to a Julian Day number.
*
* The result is an integer corresponding to noon UT on the given calendar
* day. Inputs are not range-checked — pass valid dates.
*
* @example
* j2d(1395, 1, 23) // 2457490
*/
function j2d(jy, jm, jd) {
	const r = jalCalShort(jy);
	return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1;
}
var FIRST_JALAALI_JDN = j2d(MIN_JALAALI_YEAR, 1, 1);
var LAST_JALAALI_JDN = j2d(MAX_JALAALI_YEAR, 12, jalaaliMonthLength(MAX_JALAALI_YEAR, 12));
/**
* Converts a Julian Day number to a Jalaali date.
*
* @example
* d2j(2457490) // { jy: 1395, jm: 1, jd: 23 }
*
* @throws {RangeError} if `jdn` falls outside the supported Jalaali range
*   `[-61, 3177]`.
*/
function d2j(jdn) {
	if (jdn < FIRST_JALAALI_JDN || jdn > LAST_JALAALI_JDN) throw new RangeError(`Invalid Julian Day number ${jdn}: outside the supported Jalaali range [${MIN_JALAALI_YEAR}, ${MAX_JALAALI_YEAR}]`);
	const gy = d2g(jdn).gy;
	let jy = Math.min(gy - 621, MAX_JALAALI_YEAR);
	const r = jalCal(jy);
	let k = jdn - g2d(r.gy, 3, r.march);
	if (k >= 0) {
		if (k <= 185) return {
			jy,
			jm: 1 + div(k, 31),
			jd: mod(k, 31) + 1
		};
		k -= 186;
	} else {
		jy -= 1;
		k += 179;
		if (r.leap === 1) k += 1;
	}
	return {
		jy,
		jm: 7 + div(k, 30),
		jd: mod(k, 30) + 1
	};
}
/**
* Converts a Gregorian date to a Julian Day number.
*
* Tested correct from 1 March, -100100 (of both calendars) through several
* million years into the future.
*
* @example
* g2d(2016, 4, 11) // 2457490
*/
function g2d(gy, gm, gd) {
	let d = div((gy + div(gm - 8, 6) + 100100) * 1461, 4) + div(153 * mod(gm + 9, 12) + 2, 5) + gd - 34840408;
	d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
	return d;
}
/**
* Converts a Julian Day number to a Gregorian date.
*
* Valid for `jdn ≥ -34839655` (year -100100 of both calendars).
*
* @example
* d2g(2457490) // { gy: 2016, gm: 4, gd: 11 }
*/
function d2g(jdn) {
	let j = 4 * jdn + 139361631;
	j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
	const i = div(mod(j, 1461), 4) * 5 + 308;
	const gd = div(mod(i, 153), 5) + 1;
	const gm = mod(div(i, 153), 12) + 1;
	return {
		gy: div(j, 1461) - 100100 + div(8 - gm, 6),
		gm,
		gd
	};
}
/**
* Core of the Borkowski algorithm: locate the Jalaali year inside the
* cycle table and compute Farvardin 1's Gregorian date.
*/
function jalCalCore(jy) {
	if (!Number.isFinite(jy) || jy < MIN_JALAALI_YEAR || jy > MAX_JALAALI_YEAR) throw new RangeError(`Invalid Jalaali year ${jy}: must be a finite number between ${MIN_JALAALI_YEAR} and ${MAX_JALAALI_YEAR} (inclusive)`);
	const gy = jy + 621;
	let leapJ = -14;
	let jp = BREAKS[0];
	let jm = 0;
	let jump = 0;
	for (let i = 1; i < BREAKS.length; i += 1) {
		jm = BREAKS[i];
		jump = jm - jp;
		if (jy < jm) break;
		leapJ = leapJ + div(jump, 33) * 8 + div(mod(jump, 33), 4);
		jp = jm;
	}
	const n = jy - jp;
	leapJ = leapJ + div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
	if (mod(jump, 33) === 4 && jump - n === 4) leapJ += 1;
	const leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
	return {
		gy,
		march: 20 + leapJ - leapG,
		jump,
		n
	};
}
/**
* Given a 33-year cycle length `jump` and the year offset `n` within that
* cycle, returns the number of years since the last leap year (`0 … 4`).
* `0` means the current year is leap.
*/
function leapFromCycle(jump, n) {
	let adjusted = n;
	if (jump - n < 6) adjusted = n - jump + div(jump + 4, 33) * 33;
	let leap = mod(mod(adjusted + 1, 33) - 1, 4);
	if (leap === -1) leap = 4;
	return leap;
}
/**
* Leap-only variant — same loop as {@link jalCalCore} without computing
* the Gregorian fields. Kept separate to avoid the per-call object
* allocation on the hot `isLeapJalaaliYear` path.
*/
function jalCalLeap(jy) {
	if (!Number.isFinite(jy) || jy < MIN_JALAALI_YEAR || jy > MAX_JALAALI_YEAR) throw new RangeError(`Invalid Jalaali year ${jy}: must be a finite number between ${MIN_JALAALI_YEAR} and ${MAX_JALAALI_YEAR} (inclusive)`);
	let jp = BREAKS[0];
	let jm = 0;
	let jump = 0;
	for (let i = 1; i < BREAKS.length; i += 1) {
		jm = BREAKS[i];
		jump = jm - jp;
		if (jy < jm) break;
		jp = jm;
	}
	return leapFromCycle(jump, jy - jp);
}
/**
* Integer division — `Math.trunc(a / b)` equivalent that's faster on V8
* for values that fit in 32 bits. Used pervasively inside the algorithm.
*/
function div(a, b) {
	return ~~(a / b);
}
/**
* Mathematical modulo — like `%` but always returns a non-negative result
* when `b` is positive (matches Python's `%` semantics, not JavaScript's).
*/
function mod(a, b) {
	return a - ~~(a / b) * b;
}
//#endregion
export { toJalaali as t };
