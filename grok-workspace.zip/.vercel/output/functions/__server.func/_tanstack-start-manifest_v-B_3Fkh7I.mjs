//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B_3Fkh7I.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/assets",
			"/audit",
			"/import",
			"/ledger",
			"/obligations",
			"/people",
			"/rates"
		],
		preloads: ["/assets/index-Dr1dyi_p.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Dr1dyi_p.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BofXdKeo.js",
			"/assets/card-DXAzsQFk.js",
			"/assets/button-CU_0LNb6.js",
			"/assets/badge-DQ1JocA3.js",
			"/assets/money-CD4wSwQC.js"
		]
	},
	"/assets": {
		filePath: "/workspace/src/routes/assets.tsx",
		children: void 0,
		preloads: [
			"/assets/assets-CcnulIiL.js",
			"/assets/dialog-f0tggo-5.js",
			"/assets/card-DXAzsQFk.js",
			"/assets/button-CU_0LNb6.js",
			"/assets/input-CGj-3gLi.js",
			"/assets/select-DOOlB597.js",
			"/assets/badge-DQ1JocA3.js",
			"/assets/money-CD4wSwQC.js",
			"/assets/types-DD_niwv9.js"
		]
	},
	"/audit": {
		filePath: "/workspace/src/routes/audit.tsx",
		children: void 0,
		preloads: [
			"/assets/audit-BzWCOi2b.js",
			"/assets/card-DXAzsQFk.js",
			"/assets/input-CGj-3gLi.js",
			"/assets/select-DOOlB597.js",
			"/assets/badge-DQ1JocA3.js",
			"/assets/money-CD4wSwQC.js"
		]
	},
	"/import": {
		filePath: "/workspace/src/routes/import.tsx",
		children: void 0,
		preloads: [
			"/assets/import-B7mQg9Wo.js",
			"/assets/card-DXAzsQFk.js",
			"/assets/button-CU_0LNb6.js",
			"/assets/input-CGj-3gLi.js",
			"/assets/select-DOOlB597.js",
			"/assets/badge-DQ1JocA3.js",
			"/assets/money-CD4wSwQC.js"
		]
	},
	"/ledger": {
		filePath: "/workspace/src/routes/ledger.tsx",
		children: void 0,
		preloads: [
			"/assets/ledger-BewGvp2o.js",
			"/assets/dialog-f0tggo-5.js",
			"/assets/card-DXAzsQFk.js",
			"/assets/button-CU_0LNb6.js",
			"/assets/input-CGj-3gLi.js",
			"/assets/select-DOOlB597.js",
			"/assets/badge-DQ1JocA3.js",
			"/assets/money-CD4wSwQC.js",
			"/assets/types-DD_niwv9.js"
		]
	},
	"/obligations": {
		filePath: "/workspace/src/routes/obligations.tsx",
		children: void 0,
		preloads: [
			"/assets/obligations-BAIeMBGT.js",
			"/assets/dialog-f0tggo-5.js",
			"/assets/card-DXAzsQFk.js",
			"/assets/button-CU_0LNb6.js",
			"/assets/input-CGj-3gLi.js",
			"/assets/select-DOOlB597.js",
			"/assets/badge-DQ1JocA3.js",
			"/assets/money-CD4wSwQC.js"
		]
	},
	"/people": {
		filePath: "/workspace/src/routes/people.tsx",
		children: void 0,
		preloads: [
			"/assets/people-C-rq3Byu.js",
			"/assets/dialog-f0tggo-5.js",
			"/assets/card-DXAzsQFk.js",
			"/assets/button-CU_0LNb6.js",
			"/assets/input-CGj-3gLi.js",
			"/assets/money-CD4wSwQC.js"
		]
	},
	"/rates": {
		filePath: "/workspace/src/routes/rates.tsx",
		children: void 0,
		preloads: [
			"/assets/rates-B1vVN1ud.js",
			"/assets/card-DXAzsQFk.js",
			"/assets/button-CU_0LNb6.js",
			"/assets/input-CGj-3gLi.js",
			"/assets/select-DOOlB597.js",
			"/assets/badge-DQ1JocA3.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
