import { i as __toESM } from "../_runtime.mjs";
import { c as todayIso, s as toJalali, t as faNum } from "./format-C2WtUIVu.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useLedger, n as selectLedgerState, o as labelTx, u as uid } from "./router-DAQffrml.mjs";
import { n as CardHint, r as CardTitle, t as Card } from "./card-Bsabj3Ds.mjs";
import { t as Button } from "./button-CRV3Xh9o.mjs";
import { t as Field } from "./input-CViW_zGK.mjs";
import { t as Select } from "./select-DHVV7RmC.mjs";
import { t as Badge } from "./badge-BMlXm8zj.mjs";
import { t as Money } from "./money-CJqFG9y8.mjs";
import { n as utils, r as writeSync, t as readSync } from "../_libs/xlsx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/import-C2V__5-s.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var HEADER_ALIASES = {
	date: [
		"date",
		"تاریخ",
		"created_at",
		"time",
		"زمان",
		"روز"
	],
	type: [
		"type",
		"نوع",
		"transaction_type",
		"kind",
		"عملیات"
	],
	amount: [
		"amount",
		"مبلغ",
		"value",
		"volume_dst",
		"price"
	],
	currency: [
		"currency",
		"ارز",
		"coin",
		"symbol",
		"dstcurrency",
		"src"
	],
	description: [
		"description",
		"شرح",
		"توضیح",
		"memo",
		"details",
		"title"
	],
	person: [
		"person",
		"شخص",
		"name",
		"from",
		"عضو"
	],
	quantity: [
		"quantity",
		"تعداد",
		"qty",
		"volume",
		"amount_src"
	],
	symbol: [
		"market",
		"بازار",
		"pair",
		"نماد"
	]
};
function norm(s) {
	return s.toLowerCase().replace(/[\s_\-]/g, "").replace(/ي/g, "ی").replace(/ك/g, "ک");
}
function detectColumn(headers, key) {
	const aliases = HEADER_ALIASES[key].map(norm);
	return headers.findIndex((h) => aliases.includes(norm(h)));
}
function parseDate(v) {
	if (v instanceof Date && !Number.isNaN(v.getTime())) {
		const mm = String(v.getMonth() + 1).padStart(2, "0");
		const dd = String(v.getDate()).padStart(2, "0");
		return `${v.getFullYear()}-${mm}-${dd}`;
	}
	const s = String(v ?? "").trim();
	if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
	const j = s.match(/^(\d{4})[\/.-](\d{1,2})[\/.-](\d{1,2})/);
	if (j) {
		const y = Number(j[1]);
		if (y > 1500 && y < 1600) return s;
		const mm = j[2].padStart(2, "0");
		const dd = j[3].padStart(2, "0");
		return `${j[1]}-${mm}-${dd}`;
	}
	return todayIso();
}
function guessType(raw) {
	const t = norm(raw);
	if (/(deposit|واریز|شارژ|contribution|in)/.test(t)) return "contribution";
	if (/(withdraw|برداشت|خروج|withdrawal|out)/.test(t)) return "withdrawal";
	if (/(expense|هزینه|خرید\s?کالا)/.test(t)) return "expense";
	if (/(buy|خرید|purchase)/.test(t)) return "purchase";
	if (/(sell|فروش|sale)/.test(t)) return "sale";
	if (/(transfer|انتقال)/.test(t)) return "transfer";
	if (/(gift|هدیه)/.test(t)) return "gift";
	if (/(val|ارزش)/.test(t)) return "valuation";
	return "contribution";
}
function parseAmount(v) {
	if (typeof v === "number") return v;
	const s = String(v ?? "").replace(/[,\s]/g, "").replace(/٬/g, "");
	const n = Number(s);
	return Number.isFinite(n) ? n : 0;
}
function guessCurrency(raw) {
	const t = norm(raw);
	if (/(usdt|tether|تتر)/.test(t)) return "USDT";
	if (/(usd|dollar|دلار)/.test(t)) return "USD";
	if (/(btc|bitcoin|بیت)/.test(t)) return "BTC";
	if (/(eth|اتریوم)/.test(t)) return "ETH";
	if (/(eur|یورو)/.test(t)) return "EUR";
	if (/(irr|rial|ریال|rls)/.test(t)) return "IRR";
	if (/(irt|toman|تومان)/.test(t)) return "IRT";
	return raw.toUpperCase() || "IRT";
}
function parseWorkbook(data) {
	const wb = readSync(data, {
		type: "array",
		cellDates: true
	});
	const sheet = wb.Sheets[wb.SheetNames[0]];
	const aoa = utils.sheet_to_json(sheet, {
		header: 1,
		defval: "",
		raw: true
	});
	if (!aoa.length) return {
		headers: [],
		rows: []
	};
	const headers = (aoa[0] ?? []).map((h) => String(h));
	const iDate = detectColumn(headers, "date");
	const iType = detectColumn(headers, "type");
	const iAmount = detectColumn(headers, "amount");
	const iCur = detectColumn(headers, "currency");
	const iDesc = detectColumn(headers, "description");
	const iPerson = detectColumn(headers, "person");
	const iQty = detectColumn(headers, "quantity");
	const rows = [];
	for (let i = 1; i < aoa.length; i++) {
		const line = aoa[i] ?? [];
		if (line.every((c) => c === "" || c == null)) continue;
		const raw = {};
		headers.forEach((h, idx) => {
			raw[h] = line[idx];
		});
		const amount = parseAmount(iAmount >= 0 ? line[iAmount] : 0);
		if (!amount && !String(iDesc >= 0 ? line[iDesc] : "").trim()) continue;
		rows.push({
			date: parseDate(iDate >= 0 ? line[iDate] : todayIso()),
			type: guessType(String(iType >= 0 ? line[iType] : "contribution")),
			amount: Math.abs(amount),
			currency: guessCurrency(String(iCur >= 0 ? line[iCur] : "IRT")),
			description: String(iDesc >= 0 ? line[iDesc] : `ردیف ${i}`),
			person: String(iPerson >= 0 ? line[iPerson] : ""),
			quantity: iQty >= 0 && line[iQty] !== "" ? parseAmount(line[iQty]) : null,
			raw
		});
	}
	return {
		headers,
		rows
	};
}
function rowsToTransactions(rows, state, poolId, startSeq) {
	const byName = new Map(state.people.map((p) => [p.name.trim(), p.id]));
	return rows.map((row, idx) => {
		const personId = row.person ? byName.get(row.person.trim()) : void 0;
		const isOut = row.type === "withdrawal" || row.type === "expense";
		let amount = row.amount;
		let currency = row.currency;
		if (currency === "IRR") {
			amount = amount / 10;
			currency = "IRT";
		}
		return {
			id: uid("tx"),
			seq: startSeq + idx + 1,
			type: row.type,
			date: row.date,
			description: row.description || "واردشده از اکسل",
			poolId,
			assetId: null,
			amount,
			currency,
			quantity: row.quantity,
			fromPersonIds: personId && isOut ? [personId] : personId ? [personId] : [],
			toPersonIds: personId && !isOut ? [] : [],
			splits: personId && row.type === "contribution" ? [{
				personId,
				percent: 100
			}] : [],
			expenseMode: row.type === "expense" ? "pooled" : row.type === "withdrawal" ? "personal" : null,
			relatedObligationId: null,
			relatedAssetId: null,
			fxRateToIrt: currency === "IRT" ? 1 : null,
			fxSource: currency === "IRT" ? "base" : null,
			importSource: "excel",
			notes: ""
		};
	});
}
function buildTemplateWorkbook() {
	const ws = utils.aoa_to_sheet([
		[
			"تاریخ",
			"نوع",
			"مبلغ",
			"ارز",
			"شرح",
			"شخص",
			"تعداد"
		],
		[
			"2023-04-10",
			"واریز",
			5e7,
			"IRT",
			"واریز اولیه فربد",
			"فربد",
			""
		],
		[
			"2023-06-15",
			"واریز",
			3e7,
			"IRT",
			"واریز مشترک",
			"فربد",
			""
		],
		[
			"2023-09-01",
			"خرید",
			1e7,
			"IRT",
			"خرید تتر",
			"",
			200
		],
		[
			"2024-08-20",
			"هزینه",
			5e6,
			"IRT",
			"درمان",
			"",
			""
		],
		[
			"2024-12-01",
			"برداشت",
			3e6,
			"IRT",
			"برداشت شخصی فربد",
			"فربد",
			""
		]
	]);
	const wb = utils.book_new();
	utils.book_append_sheet(wb, ws, "تراکنش‌ها");
	return writeSync(wb, {
		type: "array",
		bookType: "xlsx"
	});
}
function downloadBuffer(buf, filename) {
	const blob = new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
function ImportView() {
	const state = useLedger(selectLedgerState);
	const importTransactions = useLedger((s) => s.importTransactions);
	const [rows, setRows] = (0, import_react.useState)([]);
	const [headers, setHeaders] = (0, import_react.useState)([]);
	const [poolId, setPoolId] = (0, import_react.useState)(state.pools[0]?.id ?? "");
	const [error, setError] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)(0);
	async function onFile(file) {
		setError("");
		setDone(0);
		try {
			const parsed = parseWorkbook(await file.arrayBuffer());
			setHeaders(parsed.headers);
			setRows(parsed.rows);
		} catch (e) {
			setError(e instanceof Error ? e.message : "خواندن فایل ممکن نشد.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-semibold",
				children: "ورود از اکسل"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm text-ink-muted",
				children: "خروجی نوبیتکس یا هر جدول با ستون‌های تاریخ، نوع، مبلغ، ارز، شرح و شخص. ستون‌ها به‌صورت خودکار تشخیص داده می‌شوند. مبالغ ریال نوبیتکس به تومان تبدیل می‌گردد."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-wrap items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => downloadBuffer(buildTemplateWorkbook(), "sahmban-template.xlsx"),
						children: "دانلود نمونه اکسل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex h-11 cursor-pointer items-center rounded-md bg-teal px-4 text-sm text-teal-fg",
						children: ["انتخاب فایل", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: ".xlsx,.xls,.csv",
							className: "hidden",
							onChange: (e) => {
								const f = e.target.files?.[0];
								if (f) onFile(f);
							}
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "صندوق مقصد",
						className: "min-w-48",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: poolId,
							onChange: (e) => setPoolId(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "بدون صندوق"
							}), state.pools.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))]
						})
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-rose",
				role: "alert",
				children: error
			}),
			!!headers.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "ستون‌های شناسایی‌شده" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, { children: headers.join(" · ") })] }),
			!!rows.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "overflow-x-auto p-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-xl text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-line text-right text-ink-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "تاریخ"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "نوع"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "شرح"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "شخص"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "مبلغ"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.slice(0, 80).map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-line/70",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: toJalali(r.date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "muted",
									children: labelTx(r.type)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: r.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: r.person || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
									amount: r.amount,
									currency: r.currency === "IRR" ? "IRR" : r.currency
								})
							})
						]
					}, i)) })]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => {
						const start = state.transactions.reduce((m, t) => Math.max(m, t.seq), 0);
						const txs = rowsToTransactions(rows, state, poolId || null, start);
						importTransactions(txs);
						setDone(txs.length);
						setRows([]);
					},
					children: [
						"ثبت ",
						faNum(rows.length),
						" ردیف در دفتر"
					]
				}), done > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sm text-forest",
					children: [faNum(done), " تراکنش وارد شد."]
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "نکتهٔ نوبیتکس" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-7 text-ink-muted",
				children: "در خروجی‌های نوبیتکس مبلغ معمولاً به ریال است. اگر ستون ارز «RLS» یا «IRR» باشد، سهم‌بان هنگام ورود آن را به تومان تبدیل می‌کند. نام افراد باید با نام ثبت‌شده در بخش افراد یکی باشد تا واریز به حساب همان شخص بنشیند."
			})] })
		]
	});
}
var SplitComponent = ImportView;
//#endregion
export { SplitComponent as component };
