import { i as __toESM } from "../_runtime.mjs";
import { n as faPercent, s as toJalali, t as faNum } from "./format-C2WtUIVu.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as replay, i as useLedger, n as selectLedgerState, o as labelTx, r as useEngine } from "./router-DAQffrml.mjs";
import { n as CardHint, r as CardTitle, t as Card } from "./card-Bsabj3Ds.mjs";
import { n as Input, t as Field } from "./input-CViW_zGK.mjs";
import { t as Select } from "./select-DHVV7RmC.mjs";
import { t as Badge } from "./badge-BMlXm8zj.mjs";
import { t as Money } from "./money-CJqFG9y8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/audit-C2sScGyy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuditView() {
	const state = useLedger(selectLedgerState);
	const live = useEngine();
	const [personId, setPersonId] = (0, import_react.useState)(state.people[0]?.id ?? "");
	const [asOf, setAsOf] = (0, import_react.useState)("");
	const engine = (0, import_react.useMemo)(() => asOf ? replay(state, asOf, false) : live, [
		asOf,
		state,
		live
	]);
	const person = state.people.find((p) => p.id === personId);
	const net = engine.personNets.find((p) => p.personId === personId);
	const pool = state.pools[0] ? engine.pools[state.pools[0].id] : null;
	const steps = personId ? engine.steps.filter((s) => s.effects.some((e) => e.personId === personId) || s.narrative.join(" ").includes(person?.name ?? "___never___") || s.type === "valuation" || s.type === "expense") : engine.steps;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-semibold",
				children: "ردپای محاسبه"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm text-ink-muted",
				children: "به‌جای یک عدد نهایی، مسیر رسیدن به سهم هر نفر را می‌بینید: ارزش صندوق قبل و بعد، تعداد واحد، نرخ هر واحد، و اثر هر رویداد."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "فرد",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: personId,
							onChange: (e) => setPersonId(e.target.value),
							children: state.people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "تا تاریخ (اختیاری)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: asOf,
							onChange: (e) => setAsOf(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md bg-paper-inset p-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-ink-subtle",
								children: ["وضعیت فعلی ", person?.name]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 font-medium",
								children: [
									faPercent(net?.poolPercent ?? 0),
									" از صندوق · ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: net?.poolValueIrt ?? 0 })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-ink-muted",
								children: [
									faNum(net?.poolUnits ?? 0, 2),
									" واحد از ",
									faNum(pool?.totalUnits ?? 0, 2)
								]
							})
						]
					})
				]
			}),
			pool && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "فرمول سهم" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, { children: "سهم ریالی = تعداد واحد فرد × (ارزش روز صندوق ÷ تعداد کل واحدها)" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm leading-7",
					children: [
						"برای ",
						person?.name,
						": ",
						faNum(net?.poolUnits ?? 0, 2),
						" × (",
						faNum(pool.navIrt, 0),
						" ÷",
						" ",
						faNum(pool.totalUnits, 2),
						") = ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: net?.poolValueIrt ?? 0 })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-ink-muted leading-7",
					children: "واریز واحد جدید در نرخ روز می‌خرد؛ برداشت شخصی واحد را بازخرید می‌کند؛ هزینهٔ مشترک واحد را کم نمی‌کند و فقط ارزش واحد را پایین می‌آورد. رشد قیمت رمزارز بین همه به نسبت واحد تقسیم می‌شود."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "space-y-3",
				children: engine.steps.map((step, i) => {
					const relevant = steps.includes(step);
					if (personId && !relevant) return null;
					const effect = step.effects.filter((e) => e.personId === personId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "ledger-rule",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-ink-subtle",
									children: [
										toJalali(step.date),
										" · رویداد ",
										faNum(i + 1)
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
									className: "mt-1",
									children: step.title
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "muted",
									children: labelTx(step.type)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 space-y-1.5 text-sm leading-7",
								children: step.narrative.map((line, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, idx))
							}),
							!!step.journal.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 overflow-x-auto",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "text-ink-muted",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-1 text-right font-medium",
												children: "حساب"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-1 text-right font-medium",
												children: "بدهکار"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-1 text-right font-medium",
												children: "بستانکار"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-1 text-right font-medium",
												children: "شرح"
											})
										]
									}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: step.journal.map((j, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-t border-line/80",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "py-1",
												children: j.account
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "tabular",
												children: j.debit ? faNum(j.debit, 0) : "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "tabular",
												children: j.credit ? faNum(j.credit, 0) : "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: j.memo })
										]
									}, idx)) })]
								})
							}),
							!!effect.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 rounded-md bg-teal-soft/60 p-3 text-sm",
								children: [
									"اثر روی ",
									person?.name,
									":",
									effect.map((e, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-1",
										children: [
											e.note,
											e.deltaUnits !== 0 && ` · واحد ${faNum(e.deltaUnits, 2)}`,
											e.deltaValueIrt !== 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
												" ",
												"· ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: e.deltaValueIrt })
											] })
										]
									}, idx))
								]
							}),
							step.after && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid gap-2 text-xs text-ink-muted sm:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										"ارزش صندوق: ",
										faNum(step.after.navIrt, 0),
										" تومان"
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["واحد کل: ", faNum(step.after.totalUnits, 2)] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["NAV واحد: ", faNum(step.after.navPerUnit, 4)] })
								]
							})
						]
					}) }, step.txId);
				})
			})
		]
	});
}
var SplitComponent = AuditView;
//#endregion
export { SplitComponent as component };
