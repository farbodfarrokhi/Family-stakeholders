//#region node_modules/.nitro/vite/services/ssr/assets/types-6e-Pobfr.js
var ASSET_CLASSES = [
	"cash",
	"crypto",
	"fiat_foreign",
	"gold",
	"jewelry",
	"vehicle",
	"real_estate",
	"stock",
	"other"
];
var TX_TYPES = [
	"contribution",
	"withdrawal",
	"expense",
	"purchase",
	"sale",
	"transfer",
	"gift",
	"exchange",
	"valuation",
	"obligation",
	"settlement",
	"ownership_change"
];
//#endregion
export { TX_TYPES as n, ASSET_CLASSES as t };
