import { i as __toESM } from "../_runtime.mjs";
import { c as todayIso, n as faPercent, s as toJalali, t as faNum } from "./format-C2WtUIVu.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as assetClassLabel, i as useLedger } from "./router-DAQffrml.mjs";
import { n as CardHint, r as CardTitle, t as Card } from "./card-Bsabj3Ds.mjs";
import { t as Button } from "./button-CRV3Xh9o.mjs";
import { n as Input, r as Textarea, t as Field } from "./input-CViW_zGK.mjs";
import { t as Select } from "./select-DHVV7RmC.mjs";
import { n as DialogContent, r as DialogTrigger, t as Dialog } from "./dialog-C9IV0xiP.mjs";
import { t as Badge } from "./badge-BMlXm8zj.mjs";
import { n as PersonChip, t as Money } from "./money-CJqFG9y8.mjs";
import { t as ASSET_CLASSES } from "./types-6e-Pobfr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assets-SRWwUmBL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AssetsView() {
	const assets = useLedger((s) => s.assets);
	const people = useLedger((s) => s.people);
	const pools = useLedger((s) => s.pools);
	const addAsset = useLedger((s) => s.addAsset);
	const updateAsset = useLedger((s) => s.updateAsset);
	const removeAsset = useLedger((s) => s.removeAsset);
	const grouped = ASSET_CLASSES.map((c) => ({
		class: c,
		items: assets.filter((a) => a.assetClass === c)
	})).filter((g) => g.items.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-semibold",
				children: "دارایی‌ها"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm text-ink-muted",
				children: "هر دارایی جداگانه ثبت می‌شود: بهای تمام‌شده، ارزش روز، مالک، و پرداخت‌کننده. دارایی صندوق با واحدهای سرمایه‌ای افراد اداره می‌شود؛ دارایی شخصی می‌تواند مالکیت جزئی داشته باشد."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssetDialog, {
				title: "دارایی جدید",
				people,
				pools,
				onSave: (v) => addAsset(v)
			})]
		}), grouped.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "space-y-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium text-ink-muted",
				children: assetClassLabel(g.class)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: g.items.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: a.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHint, { children: [
							a.symbol ? `${a.symbol} · ` : "",
							faNum(a.quantity, a.assetClass === "crypto" ? 6 : 2),
							" ",
							a.unit
						] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: a.poolId ? "teal" : "muted",
							children: a.poolId ? "صندوق" : "شخصی"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 grid grid-cols-2 gap-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-ink-subtle",
								children: "بهای تمام‌شده"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
								amount: a.costBasis,
								currency: a.costCurrency
							}) })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-ink-subtle",
								children: "ارزش روز"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
								amount: a.currentValue,
								currency: a.valueCurrency
							}) })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-ink-subtle",
								children: "تاریخ تملک"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: toJalali(a.acquiredAt) })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-ink-subtle",
								children: "وضعیت"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: a.status === "held" ? "در اختیار" : a.status })] })
						]
					}),
					!!a.ownership.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-ink-subtle",
							children: "مالکیت"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-1 space-y-1",
							children: a.ownership.map((o) => {
								const p = people.find((x) => x.id === o.personId);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonChip, {
										name: p?.name ?? o.personId,
										color: p?.color ?? "#5c4a3a"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: faPercent(o.percent) })]
								}, o.personId);
							})
						})]
					}),
					!!a.paidBy.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-ink-subtle",
							children: "پرداخت‌کنندهٔ اصلی"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-1 space-y-1",
							children: a.paidBy.map((o) => {
								const p = people.find((x) => x.id === o.personId);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p?.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
										amount: o.amount,
										currency: o.currency
									})]
								}, o.personId);
							})
						})]
					}),
					a.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-ink-muted",
						children: a.notes
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssetDialog, {
							title: "ویرایش دارایی",
							people,
							pools,
							initial: a,
							onSave: (v) => updateAsset(a.id, v),
							trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								children: "ویرایش"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => removeAsset(a.id),
							children: "حذف"
						})]
					})
				] }, a.id))
			})]
		}, g.class))]
	});
}
function AssetDialog({ title, people, pools, initial, onSave, trigger }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)(initial?.name ?? "");
	const [assetClass, setAssetClass] = (0, import_react.useState)(initial?.assetClass ?? "crypto");
	const [symbol, setSymbol] = (0, import_react.useState)(initial?.symbol ?? "");
	const [quantity, setQuantity] = (0, import_react.useState)(String(initial?.quantity ?? 1));
	const [unit, setUnit] = (0, import_react.useState)(initial?.unit ?? "عدد");
	const [costBasis, setCostBasis] = (0, import_react.useState)(String(initial?.costBasis ?? 0));
	const [currentValue, setCurrentValue] = (0, import_react.useState)(String(initial?.currentValue ?? 0));
	const [acquiredAt, setAcquiredAt] = (0, import_react.useState)(initial?.acquiredAt ?? todayIso());
	const [poolId, setPoolId] = (0, import_react.useState)(initial?.poolId ?? "");
	const [notes, setNotes] = (0, import_react.useState)(initial?.notes ?? "");
	const [ownerId, setOwnerId] = (0, import_react.useState)(initial?.ownership[0]?.personId ?? people[0]?.id ?? "");
	const [payerId, setPayerId] = (0, import_react.useState)(initial?.paidBy[0]?.personId ?? people[0]?.id ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: trigger ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: title })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			title,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نام",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: name,
							onChange: (e) => setName(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "طبقه",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: assetClass,
							onChange: (e) => setAssetClass(e.target.value),
							children: ASSET_CLASSES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c,
								children: assetClassLabel(c)
							}, c))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نماد",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: symbol,
							onChange: (e) => setSymbol(e.target.value),
							placeholder: "USDT"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "واحد شمارش",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: unit,
							onChange: (e) => setUnit(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "مقدار",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: quantity,
							onChange: (e) => setQuantity(e.target.value),
							inputMode: "decimal"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "تاریخ تملک",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: acquiredAt,
							onChange: (e) => setAcquiredAt(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "بهای تمام‌شده (تومان)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: costBasis,
							onChange: (e) => setCostBasis(e.target.value),
							inputMode: "decimal"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "ارزش روز (تومان)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: currentValue,
							onChange: (e) => setCurrentValue(e.target.value),
							inputMode: "decimal"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "صندوق",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: poolId,
							onChange: (e) => setPoolId(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "دارایی شخصی / خانوادگی"
							}), pools.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "مالک فعلی",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: ownerId,
							onChange: (e) => setOwnerId(e.target.value),
							children: people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "پرداخت‌کنندهٔ اصلی",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: payerId,
							onChange: (e) => setPayerId(e.target.value),
							children: people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "یادداشت",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value)
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				onClick: () => {
					if (!name.trim()) return;
					const cost = Number(costBasis) || 0;
					onSave({
						name: name.trim(),
						assetClass,
						symbol,
						quantity: Number(quantity) || 0,
						unit,
						costBasis: cost,
						costCurrency: "IRT",
						currentValue: Number(currentValue) || 0,
						valueCurrency: "IRT",
						acquiredAt,
						poolId: poolId || null,
						ownership: ownerId && !poolId ? [{
							personId: ownerId,
							percent: 100
						}] : [],
						paidBy: payerId ? [{
							personId: payerId,
							amount: cost,
							currency: "IRT"
						}] : [],
						notes,
						status: "held"
					});
					setOpen(false);
				},
				children: "ذخیره"
			})]
		})]
	});
}
var SplitComponent = AssetsView;
//#endregion
export { SplitComponent as component };
