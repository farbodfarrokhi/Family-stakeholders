import { i as __toESM } from "../_runtime.mjs";
import { a as roundMoney, n as faPercent, o as roundUnits, r as formatMoney, t as faNum } from "./format-C2WtUIVu.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as useRouter, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Scale, c as FileSpreadsheet, i as TriangleAlert, l as Coins, n as Wallet, o as LayoutDashboard, r as Users, s as Landmark, u as BookOpen } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DAQffrml.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	return `${prefix}_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36).slice(-4)}`;
}
var FARBOD = "p_farbod";
var SARA = "p_sara";
var MARYAM = "p_maryam";
var HOSSEIN = "p_hossein";
var SIBLINGS = "g_siblings";
var POOL = "pool_nobitex";
var A_USDT = "a_usdt";
var A_BTC = "a_btc";
var A_RING = "a_ring";
var A_CAR = "a_car";
var OB_RING = "ob_ring";
function createDemoLedger() {
	return {
		version: 1,
		settings: {
			displayUnit: "toman",
			baseCurrency: "IRT",
			preferredFx: "nobitex"
		},
		people: [
			{
				id: FARBOD,
				name: "فربد",
				notes: "پسر خانواده؛ مدیریت صندوق نوبیتکس",
				color: "#2f4f4c"
			},
			{
				id: SARA,
				name: "سارا",
				notes: "خواهر فربد",
				color: "#5c4a3a"
			},
			{
				id: MARYAM,
				name: "مریم",
				notes: "مادر",
				color: "#4a5366"
			},
			{
				id: HOSSEIN,
				name: "حسین",
				notes: "عمو",
				color: "#3f5348"
			}
		],
		groups: [{
			id: SIBLINGS,
			name: "فربد و سارا",
			memberIds: [FARBOD, SARA],
			notes: "سهم مشترک خواهر و برادر از صندوق و دارایی‌های خانوادگی"
		}],
		pools: [{
			id: POOL,
			name: "صندوق نوبیتکس خانواده",
			baseCurrency: "IRT",
			notes: "سرمایهٔ تجمیعی خانواده در صرافی نوبیتکس. سهم هر نفر با روش واحد (NAV) محاسبه می‌شود."
		}],
		assets: [
			{
				id: A_USDT,
				name: "تتر (USDT)",
				assetClass: "crypto",
				symbol: "USDT",
				quantity: 200,
				unit: "USDT",
				costBasis: 1e7,
				costCurrency: "IRT",
				currentValue: 2e7,
				valueCurrency: "IRT",
				acquiredAt: "2023-09-01",
				poolId: POOL,
				ownership: [],
				paidBy: [],
				notes: "نگهداری‌شده در صندوق نوبیتکس",
				status: "held"
			},
			{
				id: A_BTC,
				name: "بیت‌کوین",
				assetClass: "crypto",
				symbol: "BTC",
				quantity: .002,
				unit: "BTC",
				costBasis: 7e6,
				costCurrency: "IRT",
				currentValue: 12e6,
				valueCurrency: "IRT",
				acquiredAt: "2025-03-10",
				poolId: POOL,
				ownership: [],
				paidBy: [],
				notes: "خرید از محل وجه صندوق",
				status: "held"
			},
			{
				id: A_RING,
				name: "انگشتر طلا",
				assetClass: "jewelry",
				symbol: "",
				quantity: 1,
				unit: "عدد",
				costBasis: 8e6,
				costCurrency: "IRT",
				currentValue: 11e6,
				valueCurrency: "IRT",
				acquiredAt: "2022-04-12",
				poolId: null,
				ownership: [{
					personId: FARBOD,
					percent: 100
				}],
				paidBy: [{
					personId: MARYAM,
					amount: 8e6,
					currency: "IRT"
				}],
				notes: "ابتدا متعلق به سارا بود. مادر هزینه را پرداخت کرد. سپس به فربد منتقل شد و فربد به مادر بدهکار گردید.",
				status: "held"
			},
			{
				id: A_CAR,
				name: "پراید خانوادگی",
				assetClass: "vehicle",
				symbol: "",
				quantity: 1,
				unit: "دستگاه",
				costBasis: 18e7,
				costCurrency: "IRT",
				currentValue: 22e7,
				valueCurrency: "IRT",
				acquiredAt: "2024-05-01",
				poolId: null,
				ownership: [{
					personId: FARBOD,
					percent: 50
				}, {
					personId: HOSSEIN,
					percent: 50
				}],
				paidBy: [{
					personId: FARBOD,
					amount: 9e7,
					currency: "IRT"
				}, {
					personId: HOSSEIN,
					amount: 9e7,
					currency: "IRT"
				}],
				notes: "مالکیت پنجاه‌پنجاه فربد و حسین",
				status: "held"
			}
		],
		rates: [
			{
				id: "r1",
				date: "2023-09-01",
				base: "USDT",
				quote: "IRT",
				rate: 5e4,
				source: "manual"
			},
			{
				id: "r2",
				date: "2024-06-01",
				base: "USDT",
				quote: "IRT",
				rate: 7e4,
				source: "manual"
			},
			{
				id: "r3",
				date: "2025-03-10",
				base: "USDT",
				quote: "IRT",
				rate: 85e3,
				source: "manual"
			},
			{
				id: "r4",
				date: "2025-03-10",
				base: "BTC",
				quote: "IRT",
				rate: 35e8,
				source: "manual"
			},
			{
				id: "r5",
				date: "2026-01-01",
				base: "USDT",
				quote: "IRT",
				rate: 1e5,
				source: "manual"
			},
			{
				id: "r6",
				date: "2026-01-01",
				base: "BTC",
				quote: "IRT",
				rate: 6e9,
				source: "manual"
			},
			{
				id: "r7",
				date: "2026-01-01",
				base: "USD",
				quote: "IRT",
				rate: 1e5,
				source: "manual"
			}
		],
		obligations: [{
			id: OB_RING,
			fromPersonId: FARBOD,
			toPersonId: MARYAM,
			amount: 8e6,
			currency: "IRT",
			remaining: 8e6,
			dueDate: "2026-12-31",
			createdAt: "2025-09-01",
			relatedAssetId: A_RING,
			relatedTxId: "tx_ring_x",
			reason: "مادر در اصل بهای انگشتر را برای سارا پرداخته بود. پس از انتقال انگشتر به فربد، فربد متعهد شد معادل آن را به مادر بپردازد.",
			status: "open"
		}],
		transactions: [
			{
				id: "tx_c1",
				seq: 1,
				type: "contribution",
				date: "2023-04-10",
				description: "واریز اولیه فربد به نوبیتکس",
				poolId: POOL,
				assetId: null,
				amount: 5e7,
				currency: "IRT",
				quantity: null,
				fromPersonIds: [FARBOD],
				toPersonIds: [],
				splits: [{
					personId: FARBOD,
					percent: 100
				}],
				expenseMode: null,
				relatedObligationId: null,
				relatedAssetId: null,
				fxRateToIrt: 1,
				fxSource: "base",
				importSource: null,
				notes: ""
			},
			{
				id: "tx_c2",
				seq: 2,
				type: "contribution",
				date: "2023-06-15",
				description: "واریز مشترک فربد و سارا",
				poolId: POOL,
				assetId: null,
				amount: 3e7,
				currency: "IRT",
				quantity: null,
				fromPersonIds: [FARBOD, SARA],
				toPersonIds: [],
				splits: [{
					personId: FARBOD,
					percent: 60
				}, {
					personId: SARA,
					percent: 40
				}],
				expenseMode: null,
				relatedObligationId: null,
				relatedAssetId: null,
				fxRateToIrt: 1,
				fxSource: "base",
				importSource: null,
				notes: "فربد ۶۰٪ و سارا ۴۰٪ از این واریز"
			},
			{
				id: "tx_buy_usdt",
				seq: 3,
				type: "purchase",
				date: "2023-09-01",
				description: "خرید ۲۰۰ تتر از محل صندوق",
				poolId: POOL,
				assetId: A_USDT,
				amount: 1e7,
				currency: "IRT",
				quantity: 200,
				fromPersonIds: [],
				toPersonIds: [],
				splits: [],
				expenseMode: null,
				relatedObligationId: null,
				relatedAssetId: A_USDT,
				fxRateToIrt: 1,
				fxSource: "manual",
				importSource: null,
				notes: "نرخ ۵۰٬۰۰۰ تومان برای هر تتر"
			},
			{
				id: "tx_c3",
				seq: 4,
				type: "contribution",
				date: "2024-01-20",
				description: "واریز حسین",
				poolId: POOL,
				assetId: null,
				amount: 2e7,
				currency: "IRT",
				quantity: null,
				fromPersonIds: [HOSSEIN],
				toPersonIds: [],
				splits: [{
					personId: HOSSEIN,
					percent: 100
				}],
				expenseMode: null,
				relatedObligationId: null,
				relatedAssetId: null,
				fxRateToIrt: 1,
				fxSource: "base",
				importSource: null,
				notes: ""
			},
			{
				id: "tx_val_usdt",
				seq: 5,
				type: "valuation",
				date: "2024-06-01",
				description: "ارزش‌گذاری تتر پس از رشد نرخ",
				poolId: POOL,
				assetId: A_USDT,
				amount: 14e6,
				currency: "IRT",
				quantity: 200,
				fromPersonIds: [],
				toPersonIds: [],
				splits: [],
				expenseMode: null,
				relatedObligationId: null,
				relatedAssetId: A_USDT,
				fxRateToIrt: 1,
				fxSource: "manual",
				importSource: null,
				notes: "نرخ ۷۰٬۰۰۰ تومان"
			},
			{
				id: "tx_exp",
				seq: 6,
				type: "expense",
				date: "2024-08-20",
				description: "هزینه درمان خانواده از محل صندوق",
				poolId: POOL,
				assetId: null,
				amount: 5e6,
				currency: "IRT",
				quantity: null,
				fromPersonIds: [],
				toPersonIds: [],
				splits: [],
				expenseMode: "pooled",
				relatedObligationId: null,
				relatedAssetId: null,
				fxRateToIrt: 1,
				fxSource: "base",
				importSource: null,
				notes: "هزینه مشترک؛ واحدها ثابت می‌مانند و NAV کاهش می‌یابد"
			},
			{
				id: "tx_wd",
				seq: 7,
				type: "withdrawal",
				date: "2024-12-01",
				description: "برداشت شخصی فربد",
				poolId: POOL,
				assetId: null,
				amount: 3e6,
				currency: "IRT",
				quantity: null,
				fromPersonIds: [FARBOD],
				toPersonIds: [FARBOD],
				splits: [{
					personId: FARBOD,
					percent: 100
				}],
				expenseMode: "personal",
				relatedObligationId: null,
				relatedAssetId: null,
				fxRateToIrt: 1,
				fxSource: "base",
				importSource: null,
				notes: ""
			},
			{
				id: "tx_buy_btc",
				seq: 8,
				type: "purchase",
				date: "2025-03-10",
				description: "خرید ۰.۰۰۲ بیت‌کوین",
				poolId: POOL,
				assetId: A_BTC,
				amount: 7e6,
				currency: "IRT",
				quantity: .002,
				fromPersonIds: [],
				toPersonIds: [],
				splits: [],
				expenseMode: null,
				relatedObligationId: null,
				relatedAssetId: A_BTC,
				fxRateToIrt: 1,
				fxSource: "manual",
				importSource: null,
				notes: ""
			},
			{
				id: "tx_val_now",
				seq: 9,
				type: "valuation",
				date: "2026-01-01",
				description: "ارزش‌گذاری ابتدای ۱۴۰۴/۱۴۰۵ — تتر",
				poolId: POOL,
				assetId: A_USDT,
				amount: 2e7,
				currency: "IRT",
				quantity: 200,
				fromPersonIds: [],
				toPersonIds: [],
				splits: [],
				expenseMode: null,
				relatedObligationId: null,
				relatedAssetId: A_USDT,
				fxRateToIrt: 1,
				fxSource: "manual",
				importSource: null,
				notes: "نرخ ۱۰۰٬۰۰۰ تومان"
			},
			{
				id: "tx_val_btc",
				seq: 10,
				type: "valuation",
				date: "2026-01-01",
				description: "ارزش‌گذاری بیت‌کوین",
				poolId: POOL,
				assetId: A_BTC,
				amount: 12e6,
				currency: "IRT",
				quantity: .002,
				fromPersonIds: [],
				toPersonIds: [],
				splits: [],
				expenseMode: null,
				relatedObligationId: null,
				relatedAssetId: A_BTC,
				fxRateToIrt: 1,
				fxSource: "manual",
				importSource: null,
				notes: ""
			},
			{
				id: "tx_ring_x",
				seq: 11,
				type: "exchange",
				date: "2025-09-01",
				description: "انتقال انگشتر از سارا به فربد",
				poolId: null,
				assetId: A_RING,
				amount: 8e6,
				currency: "IRT",
				quantity: 1,
				fromPersonIds: [SARA],
				toPersonIds: [FARBOD],
				splits: [{
					personId: FARBOD,
					percent: 100
				}],
				expenseMode: null,
				relatedObligationId: OB_RING,
				relatedAssetId: A_RING,
				fxRateToIrt: 1,
				fxSource: "base",
				importSource: null,
				notes: "مالکیت به فربد رسید. پرداخت‌کنندهٔ اصلی مادر است. تعهد جداگانه به نفع مادر ثبت شد."
			},
			{
				id: "tx_ring_ob",
				seq: 12,
				type: "obligation",
				date: "2025-09-01",
				description: "تعهد فربد به مادر بابت انگشتر",
				poolId: null,
				assetId: A_RING,
				amount: 8e6,
				currency: "IRT",
				quantity: null,
				fromPersonIds: [FARBOD],
				toPersonIds: [MARYAM],
				splits: [],
				expenseMode: null,
				relatedObligationId: OB_RING,
				relatedAssetId: A_RING,
				fxRateToIrt: 1,
				fxSource: "base",
				importSource: null,
				notes: "دریافت‌کننده دارایی (فربد) با طلبکار (مادر) متفاوت است."
			}
		]
	};
}
function emptyUnits(people) {
	const u = {};
	for (const p of people) u[p.id] = 0;
	return u;
}
function cloneUnits(u) {
	return { ...u };
}
function totalUnitsOf(u) {
	return Object.values(u).reduce((s, n) => s + n, 0);
}
function sharesFromUnits(units, navIrt) {
	const totalUnits = totalUnitsOf(units);
	const sharePercent = {};
	const shareValueIrt = {};
	for (const [id, qty] of Object.entries(units)) {
		const pct = totalUnits > 0 ? qty / totalUnits * 100 : 0;
		sharePercent[id] = roundMoney(pct, 6);
		shareValueIrt[id] = roundMoney(qty * (totalUnits > 0 ? navIrt / totalUnits : 0), 4);
	}
	return {
		totalUnits,
		sharePercent,
		shareValueIrt
	};
}
function convertToIrt(amount, currency, date, rates, fallbackRate) {
	if (currency === "IRT" || currency === "TOMAN") return {
		irt: amount,
		rate: 1,
		source: "base"
	};
	if (currency === "IRR") return {
		irt: amount / 10,
		rate: .1,
		source: "rial"
	};
	const quoteIrt = (base) => {
		const exact = rates.filter((r) => r.base === base && (r.quote === "IRT" || r.quote === "IRR") && r.date <= date).sort((a, b) => a.date < b.date ? 1 : -1)[0];
		if (!exact) return null;
		return {
			rate: exact.quote === "IRR" ? exact.rate / 10 : exact.rate,
			source: exact.source
		};
	};
	const hit = quoteIrt(currency);
	if (hit) return {
		irt: amount * hit.rate,
		rate: hit.rate,
		source: hit.source
	};
	if ((currency === "USD" || currency === "USDT") && quoteIrt(currency === "USD" ? "USDT" : "USD")) {
		const alt = quoteIrt(currency === "USD" ? "USDT" : "USD");
		return {
			irt: amount * alt.rate,
			rate: alt.rate,
			source: alt.source
		};
	}
	if (fallbackRate && fallbackRate > 0) return {
		irt: amount * fallbackRate,
		rate: fallbackRate,
		source: "tx"
	};
	const any = rates.filter((r) => r.base === currency && (r.quote === "IRT" || r.quote === "IRR")).sort((a, b) => a.date < b.date ? 1 : -1)[0];
	if (any) {
		const rate = any.quote === "IRR" ? any.rate / 10 : any.rate;
		return {
			irt: amount * rate,
			rate,
			source: any.source
		};
	}
	return {
		irt: amount,
		rate: 1,
		source: "unknown"
	};
}
function personName(state, id) {
	return state.people.find((p) => p.id === id)?.name ?? id;
}
function assetName(state, id) {
	if (!id) return "—";
	return state.assets.find((a) => a.id === id)?.name ?? id;
}
function snapshotOf(date, cashIrt, positions, units) {
	const navIrt = roundMoney(cashIrt + positions.reduce((s, p) => s + p.valueIrt, 0), 4);
	const { totalUnits, sharePercent, shareValueIrt } = sharesFromUnits(units, navIrt);
	const navPerUnit = totalUnits > 0 ? navIrt / totalUnits : 1;
	return {
		date,
		cashIrt: roundMoney(cashIrt, 4),
		positions: positions.map((p) => ({ ...p })),
		units: cloneUnits(units),
		totalUnits: roundUnits(totalUnits),
		navIrt,
		navPerUnit: roundMoney(navPerUnit, 8),
		sharePercent,
		shareValueIrt
	};
}
function splitPercents(tx, fallbackIds) {
	if (tx.splits.length > 0) {
		const sum = tx.splits.reduce((s, x) => s + x.percent, 0) || 100;
		return tx.splits.map((s) => ({
			personId: s.personId,
			percent: s.percent / sum * 100
		}));
	}
	const ids = fallbackIds.length ? fallbackIds : [];
	if (!ids.length) return [];
	const even = 100 / ids.length;
	return ids.map((personId) => ({
		personId,
		percent: even
	}));
}
function positionValue(asset, qty, date, valuations, asOfNow) {
	if (qty === 0) return 0;
	if (asOfNow && asset.currentValue && asset.quantity) return asset.currentValue / asset.quantity * qty;
	const last = valuations.filter((v) => v.assetId === asset.id && v.date <= date).sort((a, b) => a.date < b.date ? 1 : a.date > b.date ? -1 : 0)[0];
	if (last) return last.unitPriceIrt * qty;
	if (asset.costBasis && asset.quantity) return asset.costBasis / asset.quantity * qty;
	return 0;
}
function rebuildPositions(state, poolId, qtyByAsset, date, valuations, asOfNow) {
	const out = [];
	for (const asset of state.assets.filter((a) => a.poolId === poolId)) {
		const qty = qtyByAsset[asset.id] ?? 0;
		if (qty === 0) continue;
		out.push({
			assetId: asset.id,
			quantity: qty,
			valueIrt: roundMoney(positionValue(asset, qty, date, valuations, asOfNow), 4)
		});
	}
	return out;
}
function replay(state, asOf, asOfNow = true) {
	const asOfDate = asOf ?? "9999-12-31";
	const txs = [...state.transactions].filter((t) => t.date <= asOfDate).sort((a, b) => a.date === b.date ? a.seq - b.seq : a.date.localeCompare(b.date));
	const steps = [];
	const poolCash = {};
	const poolUnits = {};
	const poolQty = {};
	const valuations = [];
	for (const pool of state.pools) {
		poolCash[pool.id] = 0;
		poolUnits[pool.id] = emptyUnits(state.people);
		poolQty[pool.id] = {};
	}
	const assetOwner = {};
	for (const a of state.assets) assetOwner[a.id] = a.ownership.map((o) => ({ ...o }));
	const obligations = state.obligations.map((o) => ({ ...o }));
	for (const tx of txs) {
		const poolId = tx.poolId;
		const before = poolId && poolUnits[poolId] ? snapshotOf(tx.date, poolCash[poolId], rebuildPositions(state, poolId, poolQty[poolId], tx.date, valuations, false), poolUnits[poolId]) : null;
		const journal = [];
		const narrative = [];
		const effects = [];
		const conv = convertToIrt(tx.amount, tx.currency, tx.date, state.rates, tx.fxRateToIrt);
		const amountIrt = roundMoney(conv.irt, 4);
		if (tx.currency !== "IRT" && conv.source !== "base") narrative.push(`نرخ تبدیل ${tx.currency} به تومان در تاریخ ${tx.date}: ${faNum(conv.rate, 0)} (منبع: ${conv.source}). مبلغ معادل ${formatMoney(amountIrt, "IRT")}.`);
		if (tx.type === "contribution" && poolId) {
			const snap = before;
			const navPerUnit = snap.totalUnits > 0 ? snap.navPerUnit : 1;
			const unitsIssued = navPerUnit > 0 ? amountIrt / navPerUnit : amountIrt;
			const parts = splitPercents(tx, tx.fromPersonIds);
			narrative.push(snap.totalUnits === 0 ? "صندوق خالی بود؛ ارزش هر واحد برابر ۱ تومان قرار گرفت." : `ارزش صندوق پیش از واریز ${formatMoney(snap.navIrt, "IRT")} و تعداد واحد ${faNum(snap.totalUnits, 2)} بود؛ بنابراین ارزش هر واحد ${faNum(navPerUnit, 4)} تومان است.`);
			narrative.push(`مبلغ واریزی ${formatMoney(amountIrt, "IRT")} معادل ${faNum(unitsIssued, 4)} واحد جدید است.`);
			poolCash[poolId] += amountIrt;
			journal.push({
				account: "cash",
				personId: null,
				debit: amountIrt,
				credit: 0,
				memo: "افزایش وجه صندوق"
			});
			for (const part of parts) {
				const u = unitsIssued * part.percent / 100;
				poolUnits[poolId][part.personId] = (poolUnits[poolId][part.personId] ?? 0) + u;
				journal.push({
					account: "capital",
					personId: part.personId,
					debit: 0,
					credit: amountIrt * part.percent / 100,
					memo: `صدور واحد برای ${personName(state, part.personId)}`
				});
				effects.push({
					personId: part.personId,
					deltaUnits: u,
					deltaValueIrt: amountIrt * part.percent / 100,
					note: `${faPercent(part.percent)} از واریز → ${faNum(u, 4)} واحد`
				});
				narrative.push(`${personName(state, part.personId)} ${faPercent(part.percent)} از این واریز را دارد (${faNum(u, 4)} واحد).`);
			}
		} else if (tx.type === "withdrawal" && poolId) {
			const navPerUnit = before.navPerUnit || 1;
			const unitsRedeemed = amountIrt / navPerUnit;
			const payer = tx.fromPersonIds[0];
			const available = poolUnits[poolId][payer] ?? 0;
			const redeem = Math.min(unitsRedeemed, available);
			const cashOut = redeem * navPerUnit;
			poolCash[poolId] -= cashOut;
			poolUnits[poolId][payer] = available - redeem;
			journal.push({
				account: "capital",
				personId: payer,
				debit: cashOut,
				credit: 0,
				memo: "بازخرید واحد"
			});
			journal.push({
				account: "cash",
				personId: null,
				debit: 0,
				credit: cashOut,
				memo: "خروج وجه از صندوق"
			});
			effects.push({
				personId: payer,
				deltaUnits: -redeem,
				deltaValueIrt: -cashOut,
				note: "برداشت شخصی از محل واحدهای خودش"
			});
			narrative.push(`برداشت شخصی ${personName(state, payer)} به مبلغ ${formatMoney(amountIrt, "IRT")}.`);
			narrative.push(`ارزش هر واحد ${faNum(navPerUnit, 4)} تومان بود؛ ${faNum(redeem, 4)} واحد بازخرید شد و سهم سرمایه‌ای او کاهش یافت. ارزش هر واحد بقیهٔ اعضا تغییر نمی‌کند.`);
		} else if (tx.type === "expense" && poolId) {
			const snap = before;
			if (tx.expenseMode === "personal" && tx.fromPersonIds[0]) {
				const payer = tx.fromPersonIds[0];
				const redeem = amountIrt / (snap.navPerUnit || 1);
				poolUnits[poolId][payer] = (poolUnits[poolId][payer] ?? 0) - redeem;
				poolCash[poolId] -= amountIrt;
				effects.push({
					personId: payer,
					deltaUnits: -redeem,
					deltaValueIrt: -amountIrt,
					note: "هزینه به حساب شخصی او"
				});
				narrative.push(`هزینهٔ ${formatMoney(amountIrt, "IRT")} از سهم ${personName(state, payer)} کسر شد (بازخرید واحد).`);
			} else {
				poolCash[poolId] -= amountIrt;
				journal.push({
					account: "expense",
					personId: null,
					debit: amountIrt,
					credit: 0,
					memo: tx.description || "هزینه مشترک"
				});
				journal.push({
					account: "cash",
					personId: null,
					debit: 0,
					credit: amountIrt,
					memo: "پرداخت از صندوق"
				});
				narrative.push(`هزینهٔ مشترک ${formatMoney(amountIrt, "IRT")} از وجه صندوق پرداخت شد. تعداد واحدها ثابت ماند؛ ارزش هر واحد کاهش یافت و همه به نسبت واحدهایشان در هزینه شریک شدند.`);
				if (snap.totalUnits > 0) for (const [pid, u] of Object.entries(snap.units)) {
					if (u <= 0) continue;
					const share = u / snap.totalUnits * amountIrt;
					effects.push({
						personId: pid,
						deltaUnits: 0,
						deltaValueIrt: -share,
						note: `تحمل ${faPercent(u / snap.totalUnits * 100)} از هزینهٔ مشترک`
					});
				}
			}
		} else if (tx.type === "purchase" && poolId && tx.assetId) {
			const qty = tx.quantity ?? 0;
			poolCash[poolId] -= amountIrt;
			poolQty[poolId][tx.assetId] = (poolQty[poolId][tx.assetId] ?? 0) + qty;
			if (qty > 0) valuations.push({
				date: tx.date,
				assetId: tx.assetId,
				unitPriceIrt: amountIrt / qty
			});
			journal.push({
				account: `asset:${tx.assetId}`,
				personId: null,
				debit: amountIrt,
				credit: 0,
				memo: `خرید ${assetName(state, tx.assetId)}`
			});
			journal.push({
				account: "cash",
				personId: null,
				debit: 0,
				credit: amountIrt,
				memo: "پرداخت از صندوق"
			});
			narrative.push(`خرید ${faNum(qty, 6)} ${assetName(state, tx.assetId)} به بهای تمام‌شده ${formatMoney(amountIrt, "IRT")}. وجه نقد کم و دارایی صندوق زیاد شد؛ تعداد واحدها ثابت است.`);
		} else if (tx.type === "sale" && poolId && tx.assetId) {
			const qty = tx.quantity ?? 0;
			poolCash[poolId] += amountIrt;
			poolQty[poolId][tx.assetId] = Math.max(0, (poolQty[poolId][tx.assetId] ?? 0) - qty);
			journal.push({
				account: "cash",
				personId: null,
				debit: amountIrt,
				credit: 0,
				memo: "وجه حاصل از فروش"
			});
			journal.push({
				account: `asset:${tx.assetId}`,
				personId: null,
				debit: 0,
				credit: amountIrt,
				memo: `فروش ${assetName(state, tx.assetId)}`
			});
			narrative.push(`فروش ${faNum(qty, 6)} ${assetName(state, tx.assetId)} به مبلغ ${formatMoney(amountIrt, "IRT")}.`);
		} else if (tx.type === "valuation" && tx.assetId) {
			const qty = tx.quantity ?? state.assets.find((a) => a.id === tx.assetId)?.quantity ?? 0;
			const unit = qty > 0 ? amountIrt / qty : amountIrt;
			valuations.push({
				date: tx.date,
				assetId: tx.assetId,
				unitPriceIrt: unit
			});
			narrative.push(`ارزش‌گذاری ${assetName(state, tx.assetId)}: ارزش روز ${formatMoney(amountIrt, "IRT")}` + (qty ? ` برای ${faNum(qty, 6)} واحد (هر واحد ${formatMoney(unit, "IRT")}).` : "."));
			narrative.push("تعداد واحد صندوق تغییر نمی‌کند؛ سود یا زیان تحقق‌نیافته در ارزش خالص دارایی منعکس می‌شود و به نسبت واحد بین اعضا تقسیم می‌گردد.");
		} else if (tx.type === "transfer" || tx.type === "gift" || tx.type === "exchange" || tx.type === "ownership_change") {
			const assetId = tx.assetId ?? tx.relatedAssetId;
			if (assetId && tx.toPersonIds.length) {
				const parts = splitPercents(tx, tx.toPersonIds);
				assetOwner[assetId] = parts.map((p) => ({
					personId: p.personId,
					percent: p.percent
				}));
				narrative.push(`مالکیت «${assetName(state, assetId)}» به ${parts.map((p) => `${personName(state, p.personId)} (${faPercent(p.percent)})`).join("، ")} منتقل شد.`);
				if (tx.fromPersonIds.length) narrative.push(`انتقال‌دهنده: ${tx.fromPersonIds.map((id) => personName(state, id)).join("، ")}.`);
				if (tx.type === "gift") narrative.push("این انتقال هدیه است و به‌خودی‌خود بدهی ایجاد نمی‌کند.");
				if (tx.type === "exchange" && amountIrt > 0) narrative.push(`ارزش توافقی مبادله: ${formatMoney(amountIrt, "IRT")}.`);
			}
			if (tx.type === "transfer" && poolId && tx.fromPersonIds[0] && tx.toPersonIds[0] && amountIrt > 0) {
				const from = tx.fromPersonIds[0];
				const to = tx.toPersonIds[0];
				const u = amountIrt / (before?.navPerUnit || 1);
				poolUnits[poolId][from] = (poolUnits[poolId][from] ?? 0) - u;
				poolUnits[poolId][to] = (poolUnits[poolId][to] ?? 0) + u;
				effects.push({
					personId: from,
					deltaUnits: -u,
					deltaValueIrt: -amountIrt,
					note: "انتقال واحد"
				});
				effects.push({
					personId: to,
					deltaUnits: u,
					deltaValueIrt: amountIrt,
					note: "دریافت واحد"
				});
				narrative.push(`${faNum(u, 4)} واحد صندوق از ${personName(state, from)} به ${personName(state, to)} منتقل شد.`);
			}
		} else if (tx.type === "obligation") {
			narrative.push(`تعهد ثبت شد: ${personName(state, tx.fromPersonIds[0] ?? "")} باید ${formatMoney(amountIrt, tx.currency === "IRT" ? "IRT" : tx.currency)} به ${personName(state, tx.toPersonIds[0] ?? "")} بپردازد.`);
			if (tx.relatedAssetId) narrative.push(`این تعهد مربوط به دارایی «${assetName(state, tx.relatedAssetId)}» است. مالکیت دارایی از هویت پرداخت‌کننده و هویت طلبکار جدا ثبت شده است.`);
		} else if (tx.type === "settlement") {
			const ob = obligations.find((o) => o.id === tx.relatedObligationId);
			if (ob) {
				ob.remaining = Math.max(0, ob.remaining - tx.amount);
				ob.status = ob.remaining <= 1e-4 ? "settled" : "partial";
			}
			narrative.push(`بازپرداخت ${formatMoney(tx.amount, tx.currency)} بابت تعهد.`);
		} else if (tx.type === "contribution") narrative.push(`واریز ${formatMoney(amountIrt, "IRT")} خارج از صندوق (ثبت سرمایه‌ای شخصی).`);
		else if (tx.type === "withdrawal") narrative.push(`برداشت ${formatMoney(amountIrt, "IRT")} خارج از صندوق.`);
		const after = poolId && poolUnits[poolId] ? snapshotOf(tx.date, poolCash[poolId], rebuildPositions(state, poolId, poolQty[poolId], tx.date, valuations, false), poolUnits[poolId]) : null;
		if (after && before && after.totalUnits > 0) narrative.push(`پس از این رویداد: ارزش صندوق ${formatMoney(after.navIrt, "IRT")}، تعداد واحد ${faNum(after.totalUnits, 2)}، ارزش هر واحد ${faNum(after.navPerUnit, 4)} تومان.`);
		steps.push({
			txId: tx.id,
			date: tx.date,
			type: tx.type,
			title: tx.description || labelTx(tx.type),
			narrative,
			journal,
			before,
			after,
			effects
		});
	}
	const pools = {};
	for (const pool of state.pools) pools[pool.id] = snapshotOf(asOf ?? todayStamp(), poolCash[pool.id] ?? 0, rebuildPositions(state, pool.id, poolQty[pool.id] ?? {}, asOf ?? todayStamp(), valuations, asOfNow), poolUnits[pool.id] ?? emptyUnits(state.people));
	const mainPool = state.pools[0]?.id;
	const mainSnap = mainPool ? pools[mainPool] : null;
	const personNets = state.people.map((person) => {
		const poolUnitsQty = mainSnap?.units[person.id] ?? 0;
		const poolValueIrt = mainSnap?.shareValueIrt[person.id] ?? 0;
		const poolPercent = mainSnap?.sharePercent[person.id] ?? 0;
		let privateAssetsIrt = 0;
		for (const asset of state.assets) {
			if (asset.poolId) continue;
			if (asset.status !== "held") continue;
			const own = (assetOwner[asset.id] ?? asset.ownership).find((o) => o.personId === person.id);
			if (!own) continue;
			const val = convertToIrt(asset.currentValue, asset.valueCurrency, asOf ?? todayStamp(), state.rates, null).irt;
			privateAssetsIrt += val * own.percent / 100;
		}
		let receivablesIrt = 0;
		let payablesIrt = 0;
		for (const ob of obligations) {
			if (ob.status === "settled") continue;
			const irt = convertToIrt(ob.remaining, ob.currency, asOf ?? todayStamp(), state.rates, null).irt;
			if (ob.toPersonId === person.id) receivablesIrt += irt;
			if (ob.fromPersonId === person.id) payablesIrt += irt;
		}
		return {
			personId: person.id,
			poolValueIrt: roundMoney(poolValueIrt, 2),
			poolPercent: roundMoney(poolPercent, 4),
			poolUnits: roundUnits(poolUnitsQty),
			privateAssetsIrt: roundMoney(privateAssetsIrt, 2),
			receivablesIrt: roundMoney(receivablesIrt, 2),
			payablesIrt: roundMoney(payablesIrt, 2),
			netIrt: roundMoney(poolValueIrt + privateAssetsIrt + receivablesIrt - payablesIrt, 2)
		};
	});
	const groupNets = state.groups.map((g) => {
		const members = personNets.filter((p) => g.memberIds.includes(p.personId));
		const poolValueIrt = members.reduce((s, m) => s + m.poolValueIrt, 0);
		const netIrt = members.reduce((s, m) => s + m.netIrt, 0);
		const poolPercent = members.reduce((s, m) => s + m.poolPercent, 0);
		const memberShareOfGroup = {};
		for (const m of members) memberShareOfGroup[m.personId] = poolValueIrt > 0 ? m.poolValueIrt / poolValueIrt * 100 : 0;
		return {
			groupId: g.id,
			poolValueIrt,
			poolPercent,
			netIrt,
			members,
			memberShareOfGroup
		};
	});
	return {
		asOf: asOf ?? todayStamp(),
		pools,
		steps,
		personNets,
		groupNets,
		openObligations: obligations.filter((o) => o.status !== "settled")
	};
}
function todayStamp() {
	const d = /* @__PURE__ */ new Date();
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function labelTx(type) {
	return {
		contribution: "واریز به صندوق",
		withdrawal: "برداشت شخصی",
		expense: "هزینه",
		purchase: "خرید دارایی",
		sale: "فروش دارایی",
		transfer: "انتقال",
		gift: "هدیه",
		exchange: "مبادله / تسویه چندطرفه",
		valuation: "ارزش‌گذاری",
		obligation: "ثبت تعهد",
		settlement: "بازپرداخت تعهد",
		ownership_change: "تغییر مالکیت"
	}[type];
}
function assetClassLabel(c) {
	return {
		cash: "نقد",
		crypto: "رمزارز",
		fiat_foreign: "ارز خارجی",
		gold: "طلا",
		jewelry: "جواهرات",
		vehicle: "وسیله نقلیه",
		real_estate: "ملک",
		stock: "سهام",
		other: "سایر"
	}[c];
}
function netBetween(state, a, b) {
	let n = 0;
	for (const o of state.obligations) {
		if (o.status === "settled") continue;
		const irt = convertToIrt(o.remaining, o.currency, o.createdAt, state.rates, null).irt;
		if (o.fromPersonId === a && o.toPersonId === b) n -= irt;
		if (o.fromPersonId === b && o.toPersonId === a) n += irt;
	}
	return roundMoney(n, 2);
}
var demo = createDemoLedger();
var useLedger = create()(persist((set, get) => ({
	...demo,
	hydrated: false,
	setHydrated: (v) => set({ hydrated: v }),
	resetDemo: () => set({
		...createDemoLedger(),
		hydrated: true
	}),
	replaceAll: (state) => set({
		...state,
		hydrated: true
	}),
	addPerson: (p) => {
		const id = p.id ?? uid("p");
		set({ people: [...get().people, {
			...p,
			id
		}] });
		return id;
	},
	updatePerson: (id, patch) => set({ people: get().people.map((x) => x.id === id ? {
		...x,
		...patch
	} : x) }),
	removePerson: (id) => set({
		people: get().people.filter((x) => x.id !== id),
		groups: get().groups.map((g) => ({
			...g,
			memberIds: g.memberIds.filter((m) => m !== id)
		}))
	}),
	addGroup: (g) => {
		const id = g.id ?? uid("g");
		set({ groups: [...get().groups, {
			...g,
			id
		}] });
		return id;
	},
	updateGroup: (id, patch) => set({ groups: get().groups.map((x) => x.id === id ? {
		...x,
		...patch
	} : x) }),
	removeGroup: (id) => set({ groups: get().groups.filter((x) => x.id !== id) }),
	addPool: (p) => {
		const id = p.id ?? uid("pool");
		set({ pools: [...get().pools, {
			...p,
			id
		}] });
		return id;
	},
	addAsset: (a) => {
		const id = a.id ?? uid("a");
		set({ assets: [...get().assets, {
			...a,
			id
		}] });
		return id;
	},
	updateAsset: (id, patch) => set({ assets: get().assets.map((x) => x.id === id ? {
		...x,
		...patch
	} : x) }),
	removeAsset: (id) => set({ assets: get().assets.filter((x) => x.id !== id) }),
	addTransaction: (t) => {
		const id = t.id ?? uid("tx");
		const seq = get().transactions.reduce((m, x) => Math.max(m, x.seq), 0) + 1;
		set({ transactions: [...get().transactions, {
			...t,
			id,
			seq
		}] });
		return id;
	},
	updateTransaction: (id, patch) => set({ transactions: get().transactions.map((x) => x.id === id ? {
		...x,
		...patch
	} : x) }),
	removeTransaction: (id) => set({ transactions: get().transactions.filter((x) => x.id !== id) }),
	addObligation: (o) => {
		const id = o.id ?? uid("ob");
		set({ obligations: [...get().obligations, {
			...o,
			id
		}] });
		return id;
	},
	updateObligation: (id, patch) => set({ obligations: get().obligations.map((x) => x.id === id ? {
		...x,
		...patch
	} : x) }),
	removeObligation: (id) => set({ obligations: get().obligations.filter((x) => x.id !== id) }),
	upsertRate: (r) => {
		const existing = get().rates.find((x) => x.date === r.date && x.base === r.base && x.quote === r.quote && x.source === r.source);
		if (existing) {
			set({ rates: get().rates.map((x) => x.id === existing.id ? {
				...existing,
				...r
			} : x) });
			return existing.id;
		}
		const id = r.id ?? uid("r");
		set({ rates: [...get().rates, {
			...r,
			id
		}] });
		return id;
	},
	removeRate: (id) => set({ rates: get().rates.filter((x) => x.id !== id) }),
	importTransactions: (txs) => set({ transactions: [...get().transactions, ...txs] })
}), {
	name: "sahmban-ledger-v1",
	storage: createJSONStorage(() => {
		if (typeof window === "undefined") return {
			getItem: () => null,
			setItem: () => {},
			removeItem: () => {}
		};
		return localStorage;
	}),
	skipHydration: true,
	partialize: (s) => ({
		version: s.version,
		people: s.people,
		groups: s.groups,
		pools: s.pools,
		assets: s.assets,
		transactions: s.transactions,
		obligations: s.obligations,
		rates: s.rates,
		settings: s.settings
	})
}));
function selectLedgerState(s) {
	return {
		version: s.version,
		people: s.people,
		groups: s.groups,
		pools: s.pools,
		assets: s.assets,
		transactions: s.transactions,
		obligations: s.obligations,
		rates: s.rates,
		settings: s.settings
	};
}
function useEngine(asOf) {
	return replay(useLedger(selectLedgerState), asOf, !asOf);
}
var NAV = [
	{
		to: "/",
		label: "نمای کلی",
		icon: LayoutDashboard
	},
	{
		to: "/people",
		label: "افراد و گروه‌ها",
		icon: Users
	},
	{
		to: "/assets",
		label: "دارایی‌ها",
		icon: Landmark
	},
	{
		to: "/ledger",
		label: "دفتر تراکنش‌ها",
		icon: BookOpen
	},
	{
		to: "/obligations",
		label: "بدهی و مطالبات",
		icon: Scale
	},
	{
		to: "/audit",
		label: "ردپای محاسبه",
		icon: Wallet
	},
	{
		to: "/import",
		label: "ورود اکسل",
		icon: FileSpreadsheet
	},
	{
		to: "/rates",
		label: "نرخ ارز",
		icon: Coins
	}
];
function Shell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const setHydrated = useLedger((s) => s.setHydrated);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const api = useLedger.persist;
		const done = () => {
			setHydrated(true);
			setReady(true);
		};
		if (api && typeof api.rehydrate === "function") Promise.resolve(api.rehydrate()).finally(done);
		else done();
	}, [setHydrated]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-paper text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-7xl gap-0 md:gap-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden h-dvh w-60 shrink-0 flex-col border-l border-line p-5 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-8 flex flex-col gap-1",
						children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex h-11 items-center gap-2 rounded-md px-3 text-sm transition-colors duration-150", pathname === item.to ? "bg-teal text-teal-fg" : "text-ink-muted hover:bg-paper-inset hover:text-ink"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-4" }), item.label]
						}, item.to))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-auto text-xs leading-6 text-ink-subtle",
						children: "حساب خانوادگی با واحد صندوق. همهٔ سهم‌ها از دفتر تراکنش‌ها قابل ردیابی است."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1 px-4 pt-5 pb-24 md:px-6 md:pb-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: "mb-6 flex items-end justify-between border-b border-line pb-4 md:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, { compact: true })
				}), !ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-40 rounded-md bg-paper-inset" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-32 rounded-xl bg-paper-inset" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-32 rounded-xl bg-paper-inset" })
					]
				}) : children]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "fixed inset-x-0 bottom-0 z-40 flex overflow-x-auto border-t border-line bg-paper-elevated md:hidden",
			children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: item.to,
				className: cn("flex min-w-16 flex-1 flex-col items-center gap-1 px-2 py-2.5 text-[11px]", pathname === item.to ? "text-teal" : "text-ink-subtle"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: item.label
				})]
			}, item.to))
		})]
	});
}
function Brand({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-xl font-semibold tracking-tight text-teal",
		children: "سهم‌بان"
	}), !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-1 text-xs text-ink-muted",
		children: "دفتر حساب خانواده"
	})] });
}
var styles_default = "/assets/styles-BYdL154C.css";
var APP_NAME = "سهم‌بان";
var Route$8 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#1f4e4a"
			},
			{
				name: "description",
				content: "دفتر حساب خانواده برای سهم صندوق، دارایی و تعهدها"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "fa",
		dir: "rtl",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "min-h-dvh bg-paper text-ink",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
					position: "top-center",
					dir: "rtl"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter$7 = () => import("./routes-CttbhWcc.mjs");
var Route$7 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./assets-SRWwUmBL.mjs");
var Route$6 = createFileRoute("/assets")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./audit-C2sScGyy.mjs");
var Route$5 = createFileRoute("/audit")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./import-C2V__5-s.mjs");
var Route$4 = createFileRoute("/import")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./ledger-D3wlExFp.mjs");
var Route$3 = createFileRoute("/ledger")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./obligations-XII9BIOI.mjs");
var Route$2 = createFileRoute("/obligations")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./people-BW3tufsF.mjs");
var Route$1 = createFileRoute("/people")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./rates-D8szJxas.mjs");
var Route = createFileRoute("/rates")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$7.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$8
	}),
	AssetsRoute: Route$6.update({
		id: "/assets",
		path: "/assets",
		getParentRoute: () => Route$8
	}),
	AuditRoute: Route$5.update({
		id: "/audit",
		path: "/audit",
		getParentRoute: () => Route$8
	}),
	ImportRoute: Route$4.update({
		id: "/import",
		path: "/import",
		getParentRoute: () => Route$8
	}),
	LedgerRoute: Route$3.update({
		id: "/ledger",
		path: "/ledger",
		getParentRoute: () => Route$8
	}),
	ObligationsRoute: Route$2.update({
		id: "/obligations",
		path: "/obligations",
		getParentRoute: () => Route$8
	}),
	PeopleRoute: Route$1.update({
		id: "/people",
		path: "/people",
		getParentRoute: () => Route$8
	}),
	RatesRoute: Route.update({
		id: "/rates",
		path: "/rates",
		getParentRoute: () => Route$8
	})
};
var routeTree = Route$8._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { assetClassLabel as a, replay as c, useLedger as i, cn as l, selectLedgerState as n, labelTx as o, useEngine as r, netBetween as s, router_exports as t, uid as u };
