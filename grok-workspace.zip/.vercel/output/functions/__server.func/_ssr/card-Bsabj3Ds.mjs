import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { l as cn } from "./router-DAQffrml.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/card-Bsabj3Ds.js
var import_jsx_runtime = require_jsx_runtime();
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-xl border border-line bg-paper-elevated p-5 shadow-[0_1px_0_color-mix(in_oklab,var(--color-ink)_4%,transparent)]", className),
		...props
	});
}
function CardTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: cn("text-base font-semibold text-ink", className),
		...props
	});
}
function CardHint({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("mt-1 text-sm text-ink-muted", className),
		...props
	});
}
//#endregion
export { CardHint as n, CardTitle as r, Card as t };
