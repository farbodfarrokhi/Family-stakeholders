import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { l as cn } from "./router-DAQffrml.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-BMlXm8zj.js
var import_jsx_runtime = require_jsx_runtime();
function Badge({ className, tone = "muted", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium", {
			muted: "bg-paper-inset text-ink-muted",
			teal: "bg-teal-soft text-teal",
			rose: "bg-rose-soft text-rose",
			forest: "bg-teal-soft text-forest"
		}[tone], className),
		...props
	});
}
//#endregion
export { Badge as t };
