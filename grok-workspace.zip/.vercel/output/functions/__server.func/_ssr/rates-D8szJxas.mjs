import { i as __toESM } from "../_runtime.mjs";
import { c as todayIso, s as toJalali, t as faNum } from "./format-C2WtUIVu.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useLedger } from "./router-DAQffrml.mjs";
import { n as CardHint, r as CardTitle, t as Card } from "./card-Bsabj3Ds.mjs";
import { t as Button } from "./button-CRV3Xh9o.mjs";
import { n as Input, t as Field } from "./input-CViW_zGK.mjs";
import { t as Select } from "./select-DHVV7RmC.mjs";
import { t as Badge } from "./badge-BMlXm8zj.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rates-D8szJxas.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var fetchHistoricalRate = createServerFn({ method: "POST" }).validator((d) => d).handler(createSsrRpc("bc7c778aef02c4cdc3895afc44a5ada91008818845e6d38bebc905eceaebccae"));
var fetchNobitexLatest = createServerFn({ method: "POST" }).validator((d) => d).handler(createSsrRpc("e16ec785c2d4d07761a9f3ddf7be88545999b652c2d3c27caabcce044b7d9390"));
function RatesView() {
	const rates = useLedger((s) => s.rates);
	const upsertRate = useLedger((s) => s.upsertRate);
	const removeRate = useLedger((s) => s.removeRate);
	const [date, setDate] = (0, import_react.useState)("2024-06-01");
	const [base, setBase] = (0, import_react.useState)("USDT");
	const [quote, setQuote] = (0, import_react.useState)("IRT");
	const [source, setSource] = (0, import_react.useState)("nobitex");
	const [status, setStatus] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [manualRate, setManualRate] = (0, import_react.useState)("");
	const [live, setLive] = (0, import_react.useState)("");
	async function pull() {
		setBusy(true);
		setStatus("");
		try {
			const res = await fetchHistoricalRate({ data: {
				date,
				base,
				quote,
				source
			} });
			upsertRate({
				date: res.date,
				base: res.base,
				quote: res.quote,
				rate: res.rate,
				source: res.source
			});
			setStatus(`نرخ ذخیره‌شد: ۱ ${res.base} = ${faNum(res.rate, res.quote === "IRT" ? 0 : 4)} ${res.quote} — ${res.note}`);
		} catch (e) {
			setStatus(e instanceof Error ? e.message : "خطا در دریافت نرخ");
		} finally {
			setBusy(false);
		}
	}
	async function pullLive() {
		setBusy(true);
		try {
			const res = await fetchNobitexLatest({ data: {
				src: "usdt",
				dst: "irt"
			} });
			setLive(`آخرین قیمت تتر نوبیتکس: ${faNum(res.latestToman, 0)} تومان (خام ریال: ${faNum(res.latestRial, 0)})`);
			upsertRate({
				date: todayIso(),
				base: "USDT",
				quote: "IRT",
				rate: res.latestToman,
				source: "nobitex"
			});
		} catch (e) {
			setLive(e instanceof Error ? e.message : "نوبیتکس در دسترس نیست");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-semibold",
				children: "نرخ ارز و قیمت تاریخی"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm text-ink-muted",
				children: "برای خانوادهٔ ایرانی که در نوبیتکس سرمایه‌گذاری می‌کند، نرخ «دلار به تومان» باید نرخ بازار آزاد باشد نه نرخ رسمی. سه منبع آماده است؛ می‌توانید کلید یا پروکسی خودتان را بعداً جایگزین کنید."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "teal",
							children: "پیشنهادی"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
							className: "mt-2",
							children: "نوبیتکس"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHint, { children: [
							"تاریخچهٔ روزانهٔ USDTIRT از",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-ink",
								children: "api.nobitex.ir/market/udf/history"
							}),
							". قیمت به ریال است و سهم‌بان برای تومان بر ۱۰ تقسیم می‌کند. نزدیک‌ترین معادل دلار نقدی بازار آزاد."
						] })
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "فرانکفورتر" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, { children: "api.frankfurter.dev — رایگان، بدون کلید، نرخ مرجع بانک مرکزی اروپا از ۱۹۹۹. برای USD/EUR/GBP عالی است. ریال ایران را ندارد." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Currency API" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, { children: "CDN فاوِز احمد، نرخ روزانه بر اساس تاریخ. برای IRR معمولاً نرخ رسمی است و با بازار آزاد فاصله دارد؛ فقط به‌عنوان مقایسه استفاده شود." })] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "دریافت نرخ تاریخی" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "تاریخ میلادی",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: date,
								onChange: (e) => setDate(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "مبدأ",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: base,
								onChange: (e) => setBase(e.target.value.toUpperCase())
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "مقصد",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: quote,
								onChange: (e) => setQuote(e.target.value.toUpperCase())
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "منبع",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: source,
								onChange: (e) => setSource(e.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "nobitex",
										children: "نوبیتکس"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "frankfurter",
										children: "فرانکفورتر"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "currency-api",
										children: "Currency API"
									})
								]
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void pull(),
						disabled: busy,
						children: busy ? "در حال دریافت…" : "گرفتن و ذخیره"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => void pullLive(),
						disabled: busy,
						children: "قیمت لحظه‌ای تتر"
					})]
				}),
				status && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-7 text-ink-muted",
					children: status
				}),
				live && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-ink-muted",
					children: live
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "ثبت دستی" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, { children: "اگر API در دسترس نبود، نرخ روز را خودتان وارد کنید." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap items-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نرخ (تومان برای هر واحد مبدأ)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: manualRate,
							onChange: (e) => setManualRate(e.target.value),
							inputMode: "decimal"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => {
							const n = Number(manualRate);
							if (!n) return;
							upsertRate({
								date,
								base,
								quote,
								rate: n,
								source: "manual"
							});
							setManualRate("");
						},
						children: "افزودن"
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "overflow-x-auto p-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-lg text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-line text-right text-ink-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "تاریخ"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "جفت"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "نرخ"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "منبع"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-3 py-2 font-medium" })
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: [...rates].sort((a, b) => b.date.localeCompare(a.date)).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-line/70",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-3 py-2",
								children: [toJalali(r.date), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-ink-subtle",
									children: r.date
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-3 py-2",
								children: [
									r.base,
									"/",
									r.quote
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 tabular",
								children: faNum(r.rate, r.rate >= 100 ? 0 : 4)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: r.source
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => removeRate(r.id),
									children: "حذف"
								})
							})
						]
					}, r.id)) })]
				})
			})
		]
	});
}
var SplitComponent = RatesView;
//#endregion
export { SplitComponent as component };
