import { i as __toESM } from "../_runtime.mjs";
import { c as todayIso, s as toJalali, t as faNum } from "./format-C2WtUIVu.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useLedger, n as selectLedgerState, s as netBetween } from "./router-DAQffrml.mjs";
import { n as CardHint, r as CardTitle, t as Card } from "./card-Bsabj3Ds.mjs";
import { t as Button } from "./button-CRV3Xh9o.mjs";
import { n as Input, r as Textarea, t as Field } from "./input-CViW_zGK.mjs";
import { t as Select } from "./select-DHVV7RmC.mjs";
import { n as DialogContent, r as DialogTrigger, t as Dialog } from "./dialog-C9IV0xiP.mjs";
import { t as Badge } from "./badge-BMlXm8zj.mjs";
import { n as PersonChip, t as Money } from "./money-CJqFG9y8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/obligations-XII9BIOI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ObligationsView() {
	const state = useLedger(selectLedgerState);
	const addObligation = useLedger((s) => s.addObligation);
	const updateObligation = useLedger((s) => s.updateObligation);
	const addTransaction = useLedger((s) => s.addTransaction);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-semibold",
					children: "بدهی و مطالبات"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-ink-muted",
					children: "مالکیت دارایی، پرداخت‌کنندهٔ اصلی، و تعهد بازپرداخت سه چیز جدا هستند. مثلاً انگشتر مال فربد است، مادر پولش را داده، و فربد به مادر بدهکار است."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ObDialog, {
					people: state.people,
					assets: state.assets,
					onSave: (v) => {
						addObligation(v);
						addTransaction({
							type: "obligation",
							date: v.createdAt,
							description: v.reason,
							poolId: null,
							assetId: v.relatedAssetId,
							amount: v.amount,
							currency: v.currency,
							quantity: null,
							fromPersonIds: [v.fromPersonId],
							toPersonIds: [v.toPersonId],
							splits: [],
							expenseMode: null,
							relatedObligationId: null,
							relatedAssetId: v.relatedAssetId,
							fxRateToIrt: v.currency === "IRT" ? 1 : null,
							fxSource: v.currency === "IRT" ? "base" : null,
							importSource: null,
							notes: ""
						});
					}
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "تهاتر خالص بین افراد" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, { children: "عدد مثبت یعنی نفر ستون از نفر ردیف طلب دارد." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-md text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "text-ink-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "p-2 text-right font-medium" }), state.people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-2 text-right font-medium",
								children: p.name
							}, p.id))]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: state.people.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-line",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-2 font-medium",
								children: row.name
							}), state.people.map((col) => {
								if (row.id === col.id) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-2 text-ink-subtle",
									children: "—"
								}, col.id);
								const n = netBetween(state, row.id, col.id);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-2 tabular",
									children: n === 0 ? "۰" : faNum(n, 0)
								}, col.id);
							})]
						}, row.id)) })]
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: state.obligations.map((o) => {
					const from = state.people.find((p) => p.id === o.fromPersonId);
					const to = state.people.find((p) => p.id === o.toPersonId);
					const asset = state.assets.find((a) => a.id === o.relatedAssetId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
								className: "flex flex-wrap items-center gap-2",
								children: [
									from && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonChip, {
										name: from.name,
										color: from.color
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-ink-subtle font-normal",
										children: "بدهکار به"
									}),
									to && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonChip, {
										name: to.name,
										color: to.color
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, { children: o.reason })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: o.status === "settled" ? "forest" : o.status === "partial" ? "teal" : "rose",
								children: o.status === "settled" ? "تسویه‌شده" : o.status === "partial" ? "جزئی" : "باز"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-3 grid gap-2 text-sm sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-ink-subtle",
									children: "مبلغ اولیه"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
									amount: o.amount,
									currency: o.currency
								}) })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-ink-subtle",
									children: "مانده"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
									amount: o.remaining,
									currency: o.currency
								}) })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-ink-subtle",
									children: "سررسید"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: o.dueDate ? toJalali(o.dueDate) : "نامشخص" })] })
							]
						}),
						asset && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-ink-muted",
							children: [
								"دارایی مرتبط: ",
								asset.name,
								" — مالک فعلی با پرداخت‌کننده و طلبکار ممکن است یکی نباشد."
							]
						}),
						o.status !== "settled" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettleButton, {
							remaining: o.remaining,
							onSettle: (amt) => {
								const remaining = Math.max(0, o.remaining - amt);
								updateObligation(o.id, {
									remaining,
									status: remaining <= 0 ? "settled" : "partial"
								});
								addTransaction({
									type: "settlement",
									date: todayIso(),
									description: `بازپرداخت به ${to?.name ?? ""}`,
									poolId: null,
									assetId: o.relatedAssetId,
									amount: amt,
									currency: o.currency,
									quantity: null,
									fromPersonIds: [o.fromPersonId],
									toPersonIds: [o.toPersonId],
									splits: [],
									expenseMode: null,
									relatedObligationId: o.id,
									relatedAssetId: o.relatedAssetId,
									fxRateToIrt: o.currency === "IRT" ? 1 : null,
									fxSource: o.currency === "IRT" ? "base" : null,
									importSource: null,
									notes: ""
								});
							}
						})
					] }, o.id);
				})
			})
		]
	});
}
function SettleButton({ remaining, onSettle }) {
	const [amt, setAmt] = (0, import_react.useState)(String(remaining));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 flex flex-wrap items-end gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "مبلغ بازپرداخت",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: amt,
				onChange: (e) => setAmt(e.target.value),
				inputMode: "decimal"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			onClick: () => onSettle(Number(amt) || 0),
			children: "ثبت تسویه"
		})]
	});
}
function ObDialog({ people, assets, onSave }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [fromPersonId, setFrom] = (0, import_react.useState)(people[0]?.id ?? "");
	const [toPersonId, setTo] = (0, import_react.useState)(people[1]?.id ?? "");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [dueDate, setDue] = (0, import_react.useState)("");
	const [relatedAssetId, setAsset] = (0, import_react.useState)("");
	const [reason, setReason] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "تعهد جدید" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			title: "ثبت تعهد",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "بدهکار",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: fromPersonId,
							onChange: (e) => setFrom(e.target.value),
							children: people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "طلبکار",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: toPersonId,
							onChange: (e) => setTo(e.target.value),
							children: people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "مبلغ (تومان)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: amount,
							onChange: (e) => setAmount(e.target.value),
							inputMode: "decimal"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "سررسید",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: dueDate,
							onChange: (e) => setDue(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "دارایی مرتبط",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: relatedAssetId,
							onChange: (e) => setAsset(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "—"
							}), assets.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: a.id,
								children: a.name
							}, a.id))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "علت",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: reason,
							onChange: (e) => setReason(e.target.value)
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				onClick: () => {
					const n = Number(amount) || 0;
					onSave({
						fromPersonId,
						toPersonId,
						amount: n,
						currency: "IRT",
						remaining: n,
						dueDate: dueDate || null,
						createdAt: todayIso(),
						relatedAssetId: relatedAssetId || null,
						relatedTxId: null,
						reason: reason || "تعهد خانوادگی",
						status: "open"
					});
					setOpen(false);
				},
				children: "ذخیره"
			})]
		})]
	});
}
var SplitComponent = ObligationsView;
//#endregion
export { SplitComponent as component };
