import { i as __toESM } from "../_runtime.mjs";
import { n as faPercent } from "./format-C2WtUIVu.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useLedger, r as useEngine } from "./router-DAQffrml.mjs";
import { n as CardHint, r as CardTitle, t as Card } from "./card-Bsabj3Ds.mjs";
import { t as Button } from "./button-CRV3Xh9o.mjs";
import { n as Input, r as Textarea, t as Field } from "./input-CViW_zGK.mjs";
import { n as DialogContent, r as DialogTrigger, t as Dialog } from "./dialog-C9IV0xiP.mjs";
import { n as PersonChip, t as Money } from "./money-CJqFG9y8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/people-BW3tufsF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var COLORS = [
	"#2f4f4c",
	"#5c4a3a",
	"#4a5366",
	"#3f5348",
	"#6a5340",
	"#4e4a5c"
];
function PeopleView() {
	const people = useLedger((s) => s.people);
	const groups = useLedger((s) => s.groups);
	const addPerson = useLedger((s) => s.addPerson);
	const updatePerson = useLedger((s) => s.updatePerson);
	const removePerson = useLedger((s) => s.removePerson);
	const addGroup = useLedger((s) => s.addGroup);
	const updateGroup = useLedger((s) => s.updateGroup);
	const removeGroup = useLedger((s) => s.removeGroup);
	const resetDemo = useLedger((s) => s.resetDemo);
	const engine = useEngine();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-semibold",
					children: "افراد و گروه‌ها"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-sm text-ink-muted",
					children: "هر فرد حساب سرمایه‌ای جدا دارد. گروه فقط برای گزارش جمعی است؛ واحدهای صندوق همچنان به نام افراد ثبت می‌شود."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonDialog, {
						title: "فرد جدید",
						onSave: (v) => addPerson({
							...v,
							color: v.color || COLORS[people.length % COLORS.length]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroupDialog, {
						title: "گروه جدید",
						people,
						onSave: (v) => addGroup(v)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: people.map((p) => {
					const net = engine.personNets.find((n) => n.personId === p.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonChip, {
								name: p.name,
								color: p.color
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonDialog, {
									title: "ویرایش فرد",
									initial: p,
									onSave: (v) => updatePerson(p.id, v),
									trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "ghost",
										children: "ویرایش"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => removePerson(p.id),
									children: "حذف"
								})]
							})]
						}),
						p.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-ink-muted",
							children: p.notes
						}),
						net && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-3 grid grid-cols-2 gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-ink-subtle",
								children: "سهم صندوق"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: faPercent(net.poolPercent) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-ink-subtle",
								children: "خالص"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: net.netIrt }) })] })]
						})
					] }, p.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "گروه‌ها" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, { children: "سهم گروه برابر مجموع سهم اعضای آن است." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-3",
					children: [groups.map((g) => {
						const gn = engine.groupNets.find((x) => x.groupId === g.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-line p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-medium",
										children: g.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroupDialog, {
											title: "ویرایش گروه",
											people,
											initial: g,
											onSave: (v) => updateGroup(g.id, v),
											trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "sm",
												variant: "ghost",
												children: "ویرایش"
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "ghost",
											onClick: () => removeGroup(g.id),
											children: "حذف"
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 flex flex-wrap gap-2 text-sm",
									children: g.memberIds.map((id) => {
										const p = people.find((x) => x.id === id);
										return p ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonChip, {
											name: p.name,
											color: p.color
										}, id) : null;
									})
								}),
								gn && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-sm text-ink-muted",
									children: [
										"سهم جمعی از صندوق ",
										faPercent(gn.poolPercent),
										" — ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: gn.poolValueIrt })
									]
								})
							]
						}, g.id);
					}), !groups.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-ink-muted",
						children: "گروهی تعریف نشده است."
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => resetDemo(),
						children: "بازنشانی دادهٔ نمونه"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => {
							const blob = new Blob([JSON.stringify({
								version: 1,
								people: useLedger.getState().people,
								groups: useLedger.getState().groups,
								pools: useLedger.getState().pools,
								assets: useLedger.getState().assets,
								transactions: useLedger.getState().transactions,
								obligations: useLedger.getState().obligations,
								rates: useLedger.getState().rates,
								settings: useLedger.getState().settings
							}, null, 2)], { type: "application/json" });
							const url = URL.createObjectURL(blob);
							const a = document.createElement("a");
							a.href = url;
							a.download = "sahmban-backup.json";
							a.click();
							URL.revokeObjectURL(url);
						},
						children: "خروجی پشتیبان JSON"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex h-11 cursor-pointer items-center rounded-md border border-line-strong bg-paper-elevated px-4 text-sm",
						children: ["بازیابی JSON", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "application/json",
							className: "hidden",
							onChange: async (e) => {
								const file = e.target.files?.[0];
								if (!file) return;
								const json = JSON.parse(await file.text());
								useLedger.getState().replaceAll(json);
							}
						})]
					})
				]
			})
		]
	});
}
function PersonDialog({ title, initial, onSave, trigger }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)(initial?.name ?? "");
	const [notes, setNotes] = (0, import_react.useState)(initial?.notes ?? "");
	const [color, setColor] = (0, import_react.useState)(initial?.color ?? COLORS[0]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: trigger ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: title })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			title,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نام",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: name,
							onChange: (e) => setName(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "یادداشت",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "رنگ نمودار",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2",
							children: COLORS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "size-8 rounded-full border border-line",
								style: {
									background: c,
									outline: color === c ? "2px solid #1f4e4a" : void 0
								},
								onClick: () => setColor(c)
							}, c))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							if (!name.trim()) return;
							onSave({
								name: name.trim(),
								notes,
								color
							});
							setOpen(false);
						},
						children: "ذخیره"
					})
				]
			})
		})]
	});
}
function GroupDialog({ title, people, initial, onSave, trigger }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)(initial?.name ?? "");
	const [notes, setNotes] = (0, import_react.useState)(initial?.notes ?? "");
	const [memberIds, setMemberIds] = (0, import_react.useState)(initial?.memberIds ?? []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: trigger ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				children: title
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			title,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نام گروه",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: name,
							onChange: (e) => setName(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "اعضا",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2",
							children: people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									className: "size-4",
									checked: memberIds.includes(p.id),
									onChange: (e) => setMemberIds(e.target.checked ? [...memberIds, p.id] : memberIds.filter((id) => id !== p.id))
								}), p.name]
							}, p.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "یادداشت",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							if (!name.trim()) return;
							onSave({
								name: name.trim(),
								notes,
								memberIds
							});
							setOpen(false);
						},
						children: "ذخیره"
					})
				]
			})
		})]
	});
}
var SplitComponent = PeopleView;
//#endregion
export { SplitComponent as component };
