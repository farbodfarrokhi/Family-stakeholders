import { t as toJalaali } from "../_libs/jalaali-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/format-C2WtUIVu.js
var TOMAN_PER_RIAL = .1;
function parseIsoDate(iso) {
	if (/^\d{4}-\d{2}-\d{2}$/.test(iso)) return /* @__PURE__ */ new Date(`${iso}T12:00:00`);
	return new Date(iso);
}
function toJalali(iso) {
	const d = parseIsoDate(iso);
	if (Number.isNaN(d.getTime())) return iso;
	const j = toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
	const mm = String(j.jm).padStart(2, "0");
	const dd = String(j.jd).padStart(2, "0");
	return `${j.jy}/${mm}/${dd}`;
}
function todayIso() {
	const d = /* @__PURE__ */ new Date();
	const mm = String(d.getMonth() + 1).padStart(2, "0");
	const dd = String(d.getDate()).padStart(2, "0");
	return `${d.getFullYear()}-${mm}-${dd}`;
}
function faNum(n, digits = 0) {
	if (!Number.isFinite(n)) return "—";
	return new Intl.NumberFormat("fa-IR", {
		maximumFractionDigits: digits,
		minimumFractionDigits: digits
	}).format(n);
}
function faPercent(n) {
	return `${faNum(n, 2)}٪`;
}
var CURRENCY_LABEL = {
	IRT: "تومان",
	IRR: "ریال",
	USD: "دلار",
	USDT: "تتر",
	EUR: "یورو",
	GBP: "پوند",
	BTC: "بیت‌کوین",
	ETH: "اتریوم",
	GOLD: "طلا"
};
function currencyLabel(code) {
	return CURRENCY_LABEL[code] ?? code;
}
function formatMoney(amount, currency = "IRT") {
	return `${faNum(amount, ["BTC", "ETH"].includes(currency) ? 6 : [
		"USDT",
		"USD",
		"EUR"
	].includes(currency) ? 2 : 0)} ${currencyLabel(currency)}`;
}
function rialToToman(rial) {
	return rial * TOMAN_PER_RIAL;
}
function roundMoney(n, digits = 2) {
	const f = 10 ** digits;
	return Math.round((n + Number.EPSILON) * f) / f;
}
function roundUnits(n) {
	return roundMoney(n, 8);
}
//#endregion
export { roundMoney as a, todayIso as c, rialToToman as i, faPercent as n, roundUnits as o, formatMoney as r, toJalali as s, faNum as t };
