import { i as rialToToman } from "./format-C2WtUIVu.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fx-BooJR0jZ.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
async function getJson(url) {
	const res = await fetch(url, {
		headers: { accept: "application/json" },
		signal: AbortSignal.timeout(12e3)
	});
	if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
	return res.json();
}
function isoToUnix(iso, end = false) {
	const d = /* @__PURE__ */ new Date(end ? `${iso}T23:59:59Z` : `${iso}T00:00:00Z`);
	return Math.floor(d.getTime() / 1e3);
}
var fetchHistoricalRate_createServerFn_handler = createServerRpc({
	id: "bc7c778aef02c4cdc3895afc44a5ada91008818845e6d38bebc905eceaebccae",
	name: "fetchHistoricalRate",
	filename: "src/lib/fx.ts"
}, (opts) => fetchHistoricalRate.__executeServer(opts));
var fetchHistoricalRate = createServerFn({ method: "POST" }).validator((d) => d).handler(fetchHistoricalRate_createServerFn_handler, async ({ data }) => {
	const base = data.base.toUpperCase();
	const quote = data.quote.toUpperCase();
	const date = data.date;
	if (data.source === "frankfurter") {
		const json = await getJson(`https://api.frankfurter.dev/v1/${date}?from=${encodeURIComponent(base)}&to=${encodeURIComponent(quote)}`);
		const rate = json.rates?.[quote];
		if (rate == null) throw new Error("فرانکفورتر این جفت‌ارز را پوشش نمی‌دهد. برای تومان/ریال از نوبیتکس استفاده کنید.");
		return {
			date: json.date ?? date,
			base,
			quote,
			rate,
			source: "frankfurter",
			note: "نرخ مرجع بانک مرکزی اروپا (روز کاری). ریال ایران را شامل نمی‌شود."
		};
	}
	if (data.source === "currency-api") {
		const json = await getJson(`https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@${date}/v1/currencies/${base.toLowerCase()}.min.json`);
		const rate = json[base.toLowerCase()]?.[quote.toLowerCase()];
		if (rate == null) throw new Error("این جفت‌ارز در Currency API پیدا نشد.");
		return {
			date: String(json.date ?? date),
			base,
			quote,
			rate,
			source: "currency-api",
			note: "نرخ‌های این منبع برای ریال معمولاً نرخ رسمی/بین‌بانکی است، نه بازار آزاد ایران."
		};
	}
	const nobitexBase = base === "USD" ? "USDT" : base;
	const symbol = quote === "IRT" || quote === "IRR" || quote === "RLS" || quote === "TOMAN" ? `${nobitexBase}IRT` : `${nobitexBase}${quote}`;
	const from = isoToUnix(date) - 259200;
	const to = isoToUnix(date, true) + 86400;
	const json = await getJson(`https://api.nobitex.ir/market/udf/history?symbol=${encodeURIComponent(symbol)}&resolution=D&from=${from}&to=${to}`);
	if (json.s !== "ok" || !json.t?.length || !json.c?.length) throw new Error("نوبیتکس برای این تاریخ/نماد داده‌ای برنگرداند.");
	let bestIdx = 0;
	let bestDiff = Infinity;
	const target = isoToUnix(date);
	json.t.forEach((t, i) => {
		const d = Math.abs(t - target);
		if (d < bestDiff) {
			bestDiff = d;
			bestIdx = i;
		}
	});
	const closeRial = json.c[bestIdx];
	const closeDate = (/* @__PURE__ */ new Date((json.t[bestIdx] ?? target) * 1e3)).toISOString().slice(0, 10);
	const rate = quote === "IRR" || quote === "RLS" ? closeRial : rialToToman(closeRial);
	return {
		date: closeDate,
		base: nobitexBase,
		quote: quote === "IRR" || quote === "RLS" ? "IRR" : "IRT",
		rate,
		source: "nobitex",
		note: "قیمت پایانی روزانه نوبیتکس (ریال بازار). برای تومان بر ۱۰ تقسیم شده است. USDT تقریباً معادل دلار نقدی بازار آزاد است."
	};
});
var fetchNobitexLatest_createServerFn_handler = createServerRpc({
	id: "e16ec785c2d4d07761a9f3ddf7be88545999b652c2d3c27caabcce044b7d9390",
	name: "fetchNobitexLatest",
	filename: "src/lib/fx.ts"
}, (opts) => fetchNobitexLatest.__executeServer(opts));
var fetchNobitexLatest = createServerFn({ method: "POST" }).validator((d) => d).handler(fetchNobitexLatest_createServerFn_handler, async ({ data }) => {
	const src = data.src.toLowerCase();
	const dst = data.dst.toLowerCase() === "irt" ? "rls" : data.dst.toLowerCase();
	const json = await getJson(`https://api.nobitex.ir/market/stats?srcCurrency=${encodeURIComponent(src)}&dstCurrency=${encodeURIComponent(dst)}`);
	if (json.status !== "ok" || !json.stats) throw new Error("پاسخ نوبیتکس نامعتبر بود.");
	const key = Object.keys(json.stats)[0];
	const row = key ? json.stats[key] : void 0;
	const latestRial = Number(row?.latest ?? row?.dayClose ?? NaN);
	if (!Number.isFinite(latestRial)) throw new Error("قیمت لحظه‌ای نوبیتکس در دسترس نیست.");
	return {
		symbol: key ?? `${src}-${dst}`,
		latestRial,
		latestToman: rialToToman(latestRial)
	};
});
//#endregion
export { fetchHistoricalRate_createServerFn_handler, fetchNobitexLatest_createServerFn_handler };
