import { i as __toESM } from "../_runtime.mjs";
import { c as todayIso, s as toJalali, t as faNum } from "./format-C2WtUIVu.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useLedger, o as labelTx } from "./router-DAQffrml.mjs";
import { t as Card } from "./card-Bsabj3Ds.mjs";
import { t as Button } from "./button-CRV3Xh9o.mjs";
import { n as Input, r as Textarea, t as Field } from "./input-CViW_zGK.mjs";
import { t as Select } from "./select-DHVV7RmC.mjs";
import { n as DialogContent, r as DialogTrigger, t as Dialog } from "./dialog-C9IV0xiP.mjs";
import { t as Badge } from "./badge-BMlXm8zj.mjs";
import { t as Money } from "./money-CJqFG9y8.mjs";
import { n as TX_TYPES } from "./types-6e-Pobfr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ledger-D3wlExFp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TYPE_TONE = {
	contribution: "forest",
	withdrawal: "rose",
	expense: "rose",
	purchase: "teal",
	sale: "teal",
	transfer: "muted",
	gift: "muted",
	exchange: "teal",
	valuation: "muted",
	obligation: "rose",
	settlement: "forest",
	ownership_change: "muted"
};
function LedgerView() {
	const txs = useLedger((s) => s.transactions);
	const people = useLedger((s) => s.people);
	const assets = useLedger((s) => s.assets);
	const pools = useLedger((s) => s.pools);
	const addTransaction = useLedger((s) => s.addTransaction);
	const removeTransaction = useLedger((s) => s.removeTransaction);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [q, setQ] = (0, import_react.useState)("");
	const rows = (0, import_react.useMemo)(() => {
		return [...txs].sort((a, b) => a.date === b.date ? b.seq - a.seq : b.date.localeCompare(a.date)).filter((t) => filter === "all" ? true : t.type === filter).filter((t) => !q || t.description.includes(q) || t.notes.includes(q));
	}, [
		txs,
		filter,
		q
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-semibold",
					children: "دفتر تراکنش‌ها"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-ink-muted",
					children: "هر رویداد — واریز، برداشت، خرید، انتقال، تعهد — در همین دفتر ثبت می‌شود و مبنای محاسبهٔ سهم است."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TxDialog, {
					people,
					assets,
					pools,
					onSave: (v) => addTransaction(v)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "max-w-xs",
					placeholder: "جستجو در شرح",
					value: q,
					onChange: (e) => setQ(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: filter,
					onChange: (e) => setFilter(e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "all",
						children: "همهٔ انواع"
					}), TX_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: t,
						children: labelTx(t)
					}, t))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "overflow-x-auto p-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-xl text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-line text-right text-ink-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "تاریخ"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "نوع"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "شرح"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "مبلغ"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-4 py-3 font-medium" })
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((tx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-line/70",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3 whitespace-nowrap",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: toJalali(tx.date) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-ink-subtle",
									children: tx.date
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: TYPE_TONE[tx.type],
									children: labelTx(tx.type)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: tx.description }), tx.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-ink-muted",
									children: tx.notes
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
									amount: tx.amount,
									currency: tx.currency
								}), tx.quantity != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-ink-subtle",
									children: ["مقدار ", faNum(tx.quantity, 6)]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => removeTransaction(tx.id),
									children: "حذف"
								})
							})
						]
					}, tx.id)) })]
				})
			})
		]
	});
}
function TxDialog({ people, assets, pools, onSave }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [type, setType] = (0, import_react.useState)("contribution");
	const [date, setDate] = (0, import_react.useState)(todayIso());
	const [description, setDescription] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [currency, setCurrency] = (0, import_react.useState)("IRT");
	const [quantity, setQuantity] = (0, import_react.useState)("");
	const [poolId, setPoolId] = (0, import_react.useState)(pools[0]?.id ?? "");
	const [assetId, setAssetId] = (0, import_react.useState)("");
	const [fromId, setFromId] = (0, import_react.useState)(people[0]?.id ?? "");
	const [toId, setToId] = (0, import_react.useState)(people[1]?.id ?? people[0]?.id ?? "");
	const [splitA, setSplitA] = (0, import_react.useState)(people[0]?.id ?? "");
	const [splitB, setSplitB] = (0, import_react.useState)(people[1]?.id ?? "");
	const [pctA, setPctA] = (0, import_react.useState)("60");
	const [pctB, setPctB] = (0, import_react.useState)("40");
	const [joint, setJoint] = (0, import_react.useState)(false);
	const [expenseMode, setExpenseMode] = (0, import_react.useState)("pooled");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [counterparty, setCounterparty] = (0, import_react.useState)(people[2]?.id ?? people[0]?.id ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "ثبت رویداد" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			title: "ثبت رویداد مالی",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نوع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: type,
							onChange: (e) => setType(e.target.value),
							children: TX_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: t,
								children: labelTx(t)
							}, t))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "تاریخ",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "شرح",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: description,
							onChange: (e) => setDescription(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "مبلغ",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: amount,
							onChange: (e) => setAmount(e.target.value),
							inputMode: "decimal"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "ارز",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: currency,
							onChange: (e) => setCurrency(e.target.value),
							children: [
								"IRT",
								"IRR",
								"USD",
								"USDT",
								"EUR",
								"BTC"
							].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c,
								children: c
							}, c))
						})
					}),
					(type === "purchase" || type === "sale" || type === "valuation") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "مقدار دارایی",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: quantity,
							onChange: (e) => setQuantity(e.target.value),
							inputMode: "decimal"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "صندوق",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: poolId,
							onChange: (e) => setPoolId(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "بدون صندوق"
							}), pools.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "دارایی مرتبط",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: assetId,
							onChange: (e) => setAssetId(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "—"
							}), assets.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: a.id,
								children: a.name
							}, a.id))]
						})
					}),
					(type === "withdrawal" || type === "contribution" || type === "transfer" || type === "gift" || type === "exchange" || type === "obligation") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: type === "contribution" ? "واریزکننده" : "از طرف",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: fromId,
							onChange: (e) => setFromId(e.target.value),
							children: people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))
						})
					}),
					(type === "transfer" || type === "gift" || type === "exchange" || type === "obligation" || type === "settlement") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "به طرف",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: toId,
							onChange: (e) => setToId(e.target.value),
							children: people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))
						})
					}),
					type === "contribution" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "size-4",
							checked: joint,
							onChange: (e) => setJoint(e.target.checked)
						}), "واریز مشترک (دو نفر با درصد مشخص)"]
					}),
					joint && type === "contribution" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نفر اول / درصد",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								value: splitA,
								onChange: (e) => setSplitA(e.target.value),
								children: people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: p.id,
									children: p.name
								}, p.id))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: pctA,
								onChange: (e) => setPctA(e.target.value),
								className: "w-20"
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نفر دوم / درصد",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								value: splitB,
								onChange: (e) => setSplitB(e.target.value),
								children: people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: p.id,
									children: p.name
								}, p.id))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: pctB,
								onChange: (e) => setPctB(e.target.value),
								className: "w-20"
							})]
						})
					})] }),
					type === "expense" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "شیوه تخصیص",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: expenseMode,
							onChange: (e) => setExpenseMode(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "pooled",
								children: "هزینه مشترک (کاهش ارزش واحد همه)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "personal",
								children: "به حساب یک نفر (بازخرید واحد)"
							})]
						})
					}),
					type === "exchange" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "طلبکار تعهد (اگر با دریافت‌کننده دارایی فرق دارد)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: counterparty,
							onChange: (e) => setCounterparty(e.target.value),
							children: people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "یادداشت",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value)
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				onClick: () => {
					const n = Number(amount) || 0;
					const splits = joint ? [{
						personId: splitA,
						percent: Number(pctA) || 0
					}, {
						personId: splitB,
						percent: Number(pctB) || 0
					}] : type === "contribution" ? [{
						personId: fromId,
						percent: 100
					}] : type === "exchange" || type === "transfer" || type === "gift" || type === "ownership_change" ? [{
						personId: toId,
						percent: 100
					}] : [];
					onSave({
						type,
						date,
						description: description || labelTx(type),
						poolId: poolId || null,
						assetId: assetId || null,
						amount: n,
						currency,
						quantity: quantity ? Number(quantity) : null,
						fromPersonIds: fromId ? [fromId] : [],
						toPersonIds: toId ? [toId] : [],
						splits,
						expenseMode: type === "expense" ? expenseMode : type === "withdrawal" ? "personal" : null,
						relatedObligationId: null,
						relatedAssetId: assetId || null,
						fxRateToIrt: currency === "IRT" ? 1 : null,
						fxSource: currency === "IRT" ? "base" : null,
						importSource: null,
						notes: type === "exchange" && counterparty && counterparty !== toId ? `${notes}\nطلبکار تعهد: ${people.find((p) => p.id === counterparty)?.name ?? counterparty}` : notes
					});
					if (type === "exchange" && counterparty && n > 0) {
						useLedger.getState().addObligation({
							fromPersonId: toId,
							toPersonId: counterparty,
							amount: n,
							currency,
							remaining: n,
							dueDate: null,
							createdAt: date,
							relatedAssetId: assetId || null,
							relatedTxId: null,
							reason: description || "تعهد ناشی از مبادله دارایی",
							status: "open"
						});
						useLedger.getState().addTransaction({
							type: "obligation",
							date,
							description: `تعهد ${people.find((p) => p.id === toId)?.name} به ${people.find((p) => p.id === counterparty)?.name}`,
							poolId: null,
							assetId: assetId || null,
							amount: n,
							currency,
							quantity: null,
							fromPersonIds: [toId],
							toPersonIds: [counterparty],
							splits: [],
							expenseMode: null,
							relatedObligationId: null,
							relatedAssetId: assetId || null,
							fxRateToIrt: currency === "IRT" ? 1 : null,
							fxSource: currency === "IRT" ? "base" : null,
							importSource: null,
							notes: "دریافت‌کننده دارایی و طلبکار می‌توانند افراد متفاوتی باشند."
						});
						if (assetId) useLedger.getState().updateAsset(assetId, { ownership: [{
							personId: toId,
							percent: 100
						}] });
					}
					setOpen(false);
					setDescription("");
					setAmount("");
				},
				children: "ثبت در دفتر"
			})]
		})]
	});
}
var SplitComponent = LedgerView;
//#endregion
export { SplitComponent as component };
