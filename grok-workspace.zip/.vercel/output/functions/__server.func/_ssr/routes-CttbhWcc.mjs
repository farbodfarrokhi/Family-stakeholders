import { n as faPercent, s as toJalali, t as faNum } from "./format-C2WtUIVu.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useLedger, n as selectLedgerState, o as labelTx, r as useEngine } from "./router-DAQffrml.mjs";
import { n as CardHint, r as CardTitle, t as Card } from "./card-Bsabj3Ds.mjs";
import { t as Button } from "./button-CRV3Xh9o.mjs";
import { t as Badge } from "./badge-BMlXm8zj.mjs";
import { n as PersonChip, t as Money } from "./money-CJqFG9y8.mjs";
import { a as Tooltip, i as ResponsiveContainer, n as Pie, r as Cell, t as PieChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CttbhWcc.js
var import_jsx_runtime = require_jsx_runtime();
function DashboardView() {
	const state = useLedger(selectLedgerState);
	const engine = useEngine();
	const pool = state.pools[0];
	const snap = pool ? engine.pools[pool.id] : null;
	const pie = engine.personNets.filter((p) => p.poolValueIrt > 0).map((p) => {
		const person = state.people.find((x) => x.id === p.personId);
		return {
			name: person?.name ?? p.personId,
			value: p.poolValueIrt,
			color: person?.color ?? "#5c4a3a"
		};
	});
	const familyNet = engine.personNets.reduce((s, p) => s + p.netIrt, 0);
	const recent = [...state.transactions].sort((a, b) => b.seq - a.seq).slice(0, 6);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-ink-muted",
					children: "دفتر حساب خانواده"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-3xl font-semibold tracking-tight",
					children: "نمای کلی سهم‌ها"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-ink-muted",
					children: "سهم هر نفر از صندوق نوبیتکس با روش واحد محاسبه می‌شود: واریز واحد می‌خرد، برداشت واحد می‌فروشد، هزینهٔ مشترک ارزش واحد را کم می‌کند، و رشد دارایی به نسبت واحد بین همه تقسیم می‌شود."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "ارزش صندوق",
						value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: snap?.navIrt ?? 0 }),
						hint: pool?.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "خالص خانواده",
						value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: familyNet }),
						hint: "صندوق + دارایی − بدهی"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "واحدهای صندوق",
						value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular",
							children: faNum(snap?.totalUnits ?? 0, 0)
						}),
						hint: `هر واحد ${faNum(snap?.navPerUnit ?? 1, 2)} تومان`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "تعهدهای باز",
						value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular",
							children: faNum(engine.openObligations.length)
						}),
						hint: "بدهی بین اعضا"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-[1.1fr_0.9fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "سهم افراد از صندوق" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, { children: "بر اساس تعداد واحد در حال حاضر" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-md text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-ink-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-line text-right",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 font-medium",
											children: "فرد"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 font-medium",
											children: "واحد"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 font-medium",
											children: "درصد"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 font-medium",
											children: "ارزش"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 font-medium",
											children: "خالص کل"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: engine.personNets.map((row) => {
								const p = state.people.find((x) => x.id === row.personId);
								if (!p) return null;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-line/70",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonChip, {
												name: p.name,
												color: p.color
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "tabular",
											children: faNum(row.poolUnits, 0)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "tabular",
											children: faPercent(row.poolPercent)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: row.poolValueIrt }) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: row.netIrt }) })
									]
								}, row.personId);
							}) })]
						})
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "ترکیب مالکیت صندوق" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 h-56",
						children: pie.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
							data: pie,
							dataKey: "value",
							nameKey: "name",
							innerRadius: 48,
							outerRadius: 80,
							paddingAngle: 2,
							children: pie.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: e.color }, e.name))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
							formatter: (v) => formatSafe(Number(v)),
							contentStyle: {
								background: "#faf7f1",
								border: "1px solid #ddd4c6",
								borderRadius: 8,
								fontFamily: "Vazirmatn, sans-serif"
							}
						})] }) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-ink-muted",
							children: "هنوز واحدی در صندوق نیست."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1.5 text-sm",
						children: pie.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonChip, {
								name: e.name,
								color: e.color
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: e.value })]
						}, e.name))
					})
				] })]
			}),
			engine.groupNets.map((g) => {
				const group = state.groups.find((x) => x.id === g.groupId);
				if (!group) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, { children: ["گروه ", group.name] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHint, { children: [
						"سهم جمعی از صندوق ",
						faPercent(g.poolPercent),
						" معادل ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: g.poolValueIrt })
					] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						tone: "teal",
						children: ["خالص گروه: ", formatSafe(g.netIrt)]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 grid gap-2 sm:grid-cols-2",
					children: g.members.map((m) => {
						const p = state.people.find((x) => x.id === m.personId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md bg-paper-inset px-3 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-medium",
									children: p?.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 text-xs text-ink-muted",
									children: ["از سهم گروه ", faPercent(g.memberShareOfGroup[m.personId] ?? 0)]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 text-sm",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: m.poolValueIrt })
								})
							]
						}, m.personId);
					})
				})] }, g.groupId);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "آخرین رویدادها" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/ledger",
						children: "دفتر کامل"
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 divide-y divide-line",
				children: recent.map((tx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap items-center justify-between gap-2 py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-medium",
						children: tx.description
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-ink-muted",
						children: [
							toJalali(tx.date),
							" · ",
							labelTx(tx.type)
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						amount: tx.amount,
						currency: tx.currency
					})]
				}, tx.id))
			})] })
		]
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs text-ink-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 text-xl font-semibold",
				children: value
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 text-xs text-ink-subtle",
				children: hint
			})
		]
	});
}
function formatSafe(n) {
	return new Intl.NumberFormat("fa-IR").format(Math.round(n)) + " تومان";
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardView, {});
}
//#endregion
export { Home as component };
