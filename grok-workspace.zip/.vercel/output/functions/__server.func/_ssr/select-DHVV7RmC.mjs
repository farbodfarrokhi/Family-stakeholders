import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { l as cn } from "./router-DAQffrml.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/select-DHVV7RmC.js
var import_jsx_runtime = require_jsx_runtime();
function Select({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		className: cn("h-11 w-full rounded-md border border-line bg-paper-elevated px-3 text-sm text-ink", className),
		...props,
		children
	});
}
//#endregion
export { Select as t };
