import { r as formatMoney } from "./format-C2WtUIVu.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { l as cn } from "./router-DAQffrml.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/money-CJqFG9y8.js
var import_jsx_runtime = require_jsx_runtime();
function Money({ amount, currency = "IRT", className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("tabular", className),
		children: formatMoney(amount, currency)
	});
}
function PersonChip({ name, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1.5 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "size-2.5 rounded-full",
			style: { background: color }
		}), name]
	});
}
//#endregion
export { PersonChip as n, Money as t };
