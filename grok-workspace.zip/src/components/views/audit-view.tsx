import { useMemo, useState } from "react";
import { useEngine, useLedgerState } from "@/lib/store";
import { Card, CardHint, CardTitle } from "@/components/ui/card";
import { Select } from "@/components/ui/select";
import { Field, Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Money } from "@/components/money";
import { faNum, faPercent, toJalali } from "@/lib/format";
import { labelTx, replay } from "@/lib/accounting/engine";

export function AuditView() {
  const state = useLedgerState();
  const live = useEngine();
  const [personId, setPersonId] = useState(state.people[0]?.id ?? "");
  const [asOf, setAsOf] = useState("");
  const engine = useMemo(
    () => (asOf ? replay(state, asOf, false) : live),
    [asOf, state, live],
  );
  const person = state.people.find((p) => p.id === personId);
  const net = engine.personNets.find((p) => p.personId === personId);
  const pool = state.pools[0] ? engine.pools[state.pools[0].id] : null;
  const steps = personId
    ? engine.steps.filter(
        (s) =>
          s.effects.some((e) => e.personId === personId) ||
          s.narrative.join(" ").includes(person?.name ?? "___never___") ||
          s.type === "valuation" ||
          s.type === "expense",
      )
    : engine.steps;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-semibold">ردپای محاسبه</h1>
        <p className="mt-2 max-w-2xl text-sm text-ink-muted">
          به‌جای یک عدد نهایی، مسیر رسیدن به سهم هر نفر را می‌بینید: ارزش صندوق قبل و بعد، تعداد واحد، نرخ هر واحد،
          و اثر هر رویداد.
        </p>
      </header>

      <Card className="grid gap-3 sm:grid-cols-3">
        <Field label="فرد">
          <Select value={personId} onChange={(e) => setPersonId(e.target.value)}>
            {state.people.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="تا تاریخ (اختیاری)">
          <Input type="date" value={asOf} onChange={(e) => setAsOf(e.target.value)} />
        </Field>
        <div className="rounded-md bg-paper-inset p-3 text-sm">
          <div className="text-ink-subtle">وضعیت فعلی {person?.name}</div>
          <div className="mt-1 font-medium">
            {faPercent(net?.poolPercent ?? 0)} از صندوق · <Money amount={net?.poolValueIrt ?? 0} />
          </div>
          <div className="text-xs text-ink-muted">
            {faNum(net?.poolUnits ?? 0, 2)} واحد از {faNum(pool?.totalUnits ?? 0, 2)}
          </div>
        </div>
      </Card>

      {pool && (
        <Card>
          <CardTitle>فرمول سهم</CardTitle>
          <CardHint>
            سهم ریالی = تعداد واحد فرد × (ارزش روز صندوق ÷ تعداد کل واحدها)
          </CardHint>
          <p className="mt-3 text-sm leading-7">
            برای {person?.name}: {faNum(net?.poolUnits ?? 0, 2)} × ({faNum(pool.navIrt, 0)} ÷{" "}
            {faNum(pool.totalUnits, 2)}) = <Money amount={net?.poolValueIrt ?? 0} />
          </p>
          <p className="mt-2 text-sm text-ink-muted leading-7">
            واریز واحد جدید در نرخ روز می‌خرد؛ برداشت شخصی واحد را بازخرید می‌کند؛ هزینهٔ مشترک واحد را کم
            نمی‌کند و فقط ارزش واحد را پایین می‌آورد. رشد قیمت رمزارز بین همه به نسبت واحد تقسیم می‌شود.
          </p>
        </Card>
      )}

      <ol className="space-y-3">
        {engine.steps.map((step, i) => {
          const relevant = steps.includes(step);
          if (personId && !relevant) return null;
          const effect = step.effects.filter((e) => e.personId === personId);
          return (
            <li key={step.txId}>
              <Card className="ledger-rule">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <div className="text-xs text-ink-subtle">
                      {toJalali(step.date)} · رویداد {faNum(i + 1)}
                    </div>
                    <CardTitle className="mt-1">{step.title}</CardTitle>
                  </div>
                  <Badge tone="muted">{labelTx(step.type)}</Badge>
                </div>
                <ul className="mt-3 space-y-1.5 text-sm leading-7">
                  {step.narrative.map((line, idx) => (
                    <li key={idx}>{line}</li>
                  ))}
                </ul>
                {!!step.journal.length && (
                  <div className="mt-3 overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="text-ink-muted">
                          <th className="py-1 text-right font-medium">حساب</th>
                          <th className="py-1 text-right font-medium">بدهکار</th>
                          <th className="py-1 text-right font-medium">بستانکار</th>
                          <th className="py-1 text-right font-medium">شرح</th>
                        </tr>
                      </thead>
                      <tbody>
                        {step.journal.map((j, idx) => (
                          <tr key={idx} className="border-t border-line/80">
                            <td className="py-1">{j.account}</td>
                            <td className="tabular">{j.debit ? faNum(j.debit, 0) : "—"}</td>
                            <td className="tabular">{j.credit ? faNum(j.credit, 0) : "—"}</td>
                            <td>{j.memo}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
                {!!effect.length && (
                  <div className="mt-3 rounded-md bg-teal-soft/60 p-3 text-sm">
                    اثر روی {person?.name}:
                    {effect.map((e, idx) => (
                      <div key={idx} className="mt-1">
                        {e.note}
                        {e.deltaUnits !== 0 && ` · واحد ${faNum(e.deltaUnits, 2)}`}
                        {e.deltaValueIrt !== 0 && (
                          <>
                            {" "}
                            · <Money amount={e.deltaValueIrt} />
                          </>
                        )}
                      </div>
                    ))}
                  </div>
                )}
                {step.after && (
                  <div className="mt-3 grid gap-2 text-xs text-ink-muted sm:grid-cols-3">
                    <div>ارزش صندوق: {faNum(step.after.navIrt, 0)} تومان</div>
                    <div>واحد کل: {faNum(step.after.totalUnits, 2)}</div>
                    <div>NAV واحد: {faNum(step.after.navPerUnit, 4)}</div>
                  </div>
                )}
              </Card>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
