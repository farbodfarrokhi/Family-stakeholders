import { useMemo, useState } from "react";
import { useLedger } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Money } from "@/components/money";
import { labelTx } from "@/lib/accounting/engine";
import { TX_TYPES, type TxType } from "@/lib/accounting/types";
import { faNum, toJalali, todayIso } from "@/lib/format";

const TYPE_TONE: Record<TxType, "muted" | "teal" | "rose" | "forest"> = {
  contribution: "forest",
  withdrawal: "rose",
  expense: "rose",
  purchase: "teal",
  sale: "teal",
  transfer: "muted",
  gift: "muted",
  exchange: "teal",
  valuation: "muted",
  obligation: "rose",
  settlement: "forest",
  ownership_change: "muted",
};

export function LedgerView() {
  const txs = useLedger((s) => s.transactions);
  const people = useLedger((s) => s.people);
  const assets = useLedger((s) => s.assets);
  const pools = useLedger((s) => s.pools);
  const addTransaction = useLedger((s) => s.addTransaction);
  const removeTransaction = useLedger((s) => s.removeTransaction);
  const [filter, setFilter] = useState<TxType | "all">("all");
  const [q, setQ] = useState("");

  const rows = useMemo(() => {
    return [...txs]
      .sort((a, b) => (a.date === b.date ? b.seq - a.seq : b.date.localeCompare(a.date)))
      .filter((t) => (filter === "all" ? true : t.type === filter))
      .filter((t) => !q || t.description.includes(q) || t.notes.includes(q));
  }, [txs, filter, q]);

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-semibold">دفتر تراکنش‌ها</h1>
          <p className="mt-2 max-w-2xl text-sm text-ink-muted">
            هر رویداد — واریز، برداشت، خرید، انتقال، تعهد — در همین دفتر ثبت می‌شود و مبنای محاسبهٔ سهم است.
          </p>
        </div>
        <TxDialog
          people={people}
          assets={assets}
          pools={pools}
          onSave={(v) => addTransaction(v)}
        />
      </header>

      <div className="flex flex-wrap gap-2">
        <Input
          className="max-w-xs"
          placeholder="جستجو در شرح"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <Select value={filter} onChange={(e) => setFilter(e.target.value as TxType | "all")}>
          <option value="all">همهٔ انواع</option>
          {TX_TYPES.map((t) => (
            <option key={t} value={t}>
              {labelTx(t)}
            </option>
          ))}
        </Select>
      </div>

      <Card className="overflow-x-auto p-0">
        <table className="w-full min-w-xl text-sm">
          <thead>
            <tr className="border-b border-line text-right text-ink-muted">
              <th className="px-4 py-3 font-medium">تاریخ</th>
              <th className="px-4 py-3 font-medium">نوع</th>
              <th className="px-4 py-3 font-medium">شرح</th>
              <th className="px-4 py-3 font-medium">مبلغ</th>
              <th className="px-4 py-3 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((tx) => (
              <tr key={tx.id} className="border-b border-line/70">
                <td className="px-4 py-3 whitespace-nowrap">
                  <div>{toJalali(tx.date)}</div>
                  <div className="text-xs text-ink-subtle">{tx.date}</div>
                </td>
                <td className="px-4 py-3">
                  <Badge tone={TYPE_TONE[tx.type]}>{labelTx(tx.type)}</Badge>
                </td>
                <td className="px-4 py-3">
                  <div>{tx.description}</div>
                  {tx.notes && <div className="text-xs text-ink-muted">{tx.notes}</div>}
                </td>
                <td className="px-4 py-3">
                  <Money amount={tx.amount} currency={tx.currency} />
                  {tx.quantity != null && (
                    <div className="text-xs text-ink-subtle">مقدار {faNum(tx.quantity, 6)}</div>
                  )}
                </td>
                <td className="px-4 py-3">
                  <Button size="sm" variant="ghost" onClick={() => removeTransaction(tx.id)}>
                    حذف
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

function TxDialog({
  people,
  assets,
  pools,
  onSave,
}: {
  people: { id: string; name: string }[];
  assets: { id: string; name: string }[];
  pools: { id: string; name: string }[];
  onSave: (v: Parameters<ReturnType<typeof useLedger.getState>["addTransaction"]>[0]) => void;
}) {
  const [open, setOpen] = useState(false);
  const [type, setType] = useState<TxType>("contribution");
  const [date, setDate] = useState(todayIso());
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState("IRT");
  const [quantity, setQuantity] = useState("");
  const [poolId, setPoolId] = useState(pools[0]?.id ?? "");
  const [assetId, setAssetId] = useState("");
  const [fromId, setFromId] = useState(people[0]?.id ?? "");
  const [toId, setToId] = useState(people[1]?.id ?? people[0]?.id ?? "");
  const [splitA, setSplitA] = useState(people[0]?.id ?? "");
  const [splitB, setSplitB] = useState(people[1]?.id ?? "");
  const [pctA, setPctA] = useState("60");
  const [pctB, setPctB] = useState("40");
  const [joint, setJoint] = useState(false);
  const [expenseMode, setExpenseMode] = useState<"pooled" | "personal">("pooled");
  const [notes, setNotes] = useState("");
  const [counterparty, setCounterparty] = useState(people[2]?.id ?? people[0]?.id ?? "");

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>ثبت رویداد</Button>
      </DialogTrigger>
      <DialogContent title="ثبت رویداد مالی">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="نوع">
            <Select value={type} onChange={(e) => setType(e.target.value as TxType)}>
              {TX_TYPES.map((t) => (
                <option key={t} value={t}>
                  {labelTx(t)}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="تاریخ">
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
          <Field label="شرح" className="sm:col-span-2">
            <Input value={description} onChange={(e) => setDescription(e.target.value)} />
          </Field>
          <Field label="مبلغ">
            <Input value={amount} onChange={(e) => setAmount(e.target.value)} inputMode="decimal" />
          </Field>
          <Field label="ارز">
            <Select value={currency} onChange={(e) => setCurrency(e.target.value)}>
              {["IRT", "IRR", "USD", "USDT", "EUR", "BTC"].map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </Select>
          </Field>
          {(type === "purchase" || type === "sale" || type === "valuation") && (
            <Field label="مقدار دارایی">
              <Input value={quantity} onChange={(e) => setQuantity(e.target.value)} inputMode="decimal" />
            </Field>
          )}
          <Field label="صندوق">
            <Select value={poolId} onChange={(e) => setPoolId(e.target.value)}>
              <option value="">بدون صندوق</option>
              {pools.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="دارایی مرتبط">
            <Select value={assetId} onChange={(e) => setAssetId(e.target.value)}>
              <option value="">—</option>
              {assets.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                </option>
              ))}
            </Select>
          </Field>
          {(type === "withdrawal" ||
            type === "contribution" ||
            type === "transfer" ||
            type === "gift" ||
            type === "exchange" ||
            type === "obligation") && (
            <Field label={type === "contribution" ? "واریزکننده" : "از طرف"}>
              <Select value={fromId} onChange={(e) => setFromId(e.target.value)}>
                {people.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </Select>
            </Field>
          )}
          {(type === "transfer" || type === "gift" || type === "exchange" || type === "obligation" || type === "settlement") && (
            <Field label="به طرف">
              <Select value={toId} onChange={(e) => setToId(e.target.value)}>
                {people.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </Select>
            </Field>
          )}
          {type === "contribution" && (
            <label className="flex items-center gap-2 text-sm sm:col-span-2">
              <input type="checkbox" className="size-4" checked={joint} onChange={(e) => setJoint(e.target.checked)} />
              واریز مشترک (دو نفر با درصد مشخص)
            </label>
          )}
          {joint && type === "contribution" && (
            <>
              <Field label="نفر اول / درصد">
                <div className="flex gap-2">
                  <Select value={splitA} onChange={(e) => setSplitA(e.target.value)}>
                    {people.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                  </Select>
                  <Input value={pctA} onChange={(e) => setPctA(e.target.value)} className="w-20" />
                </div>
              </Field>
              <Field label="نفر دوم / درصد">
                <div className="flex gap-2">
                  <Select value={splitB} onChange={(e) => setSplitB(e.target.value)}>
                    {people.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                  </Select>
                  <Input value={pctB} onChange={(e) => setPctB(e.target.value)} className="w-20" />
                </div>
              </Field>
            </>
          )}
          {type === "expense" && (
            <Field label="شیوه تخصیص">
              <Select value={expenseMode} onChange={(e) => setExpenseMode(e.target.value as "pooled" | "personal")}>
                <option value="pooled">هزینه مشترک (کاهش ارزش واحد همه)</option>
                <option value="personal">به حساب یک نفر (بازخرید واحد)</option>
              </Select>
            </Field>
          )}
          {type === "exchange" && (
            <Field label="طلبکار تعهد (اگر با دریافت‌کننده دارایی فرق دارد)">
              <Select value={counterparty} onChange={(e) => setCounterparty(e.target.value)}>
                {people.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </Select>
            </Field>
          )}
          <Field label="یادداشت" className="sm:col-span-2">
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
          </Field>
        </div>
        <Button
          className="mt-4"
          onClick={() => {
            const n = Number(amount) || 0;
            const splits = joint
              ? [
                  { personId: splitA, percent: Number(pctA) || 0 },
                  { personId: splitB, percent: Number(pctB) || 0 },
                ]
              : type === "contribution"
                ? [{ personId: fromId, percent: 100 }]
                : type === "exchange" || type === "transfer" || type === "gift" || type === "ownership_change"
                  ? [{ personId: toId, percent: 100 }]
                  : [];
            onSave({
              type,
              date,
              description: description || labelTx(type),
              poolId: poolId || null,
              assetId: assetId || null,
              amount: n,
              currency,
              quantity: quantity ? Number(quantity) : null,
              fromPersonIds: fromId ? [fromId] : [],
              toPersonIds: toId ? [toId] : [],
              splits,
              expenseMode: type === "expense" ? expenseMode : type === "withdrawal" ? "personal" : null,
              relatedObligationId: null,
              relatedAssetId: assetId || null,
              fxRateToIrt: currency === "IRT" ? 1 : null,
              fxSource: currency === "IRT" ? "base" : null,
              importSource: null,
              notes:
                type === "exchange" && counterparty && counterparty !== toId
                  ? `${notes}\nطلبکار تعهد: ${people.find((p) => p.id === counterparty)?.name ?? counterparty}`
                  : notes,
            });
            if (type === "exchange" && counterparty && n > 0) {
              useLedger.getState().addObligation({
                fromPersonId: toId,
                toPersonId: counterparty,
                amount: n,
                currency,
                remaining: n,
                dueDate: null,
                createdAt: date,
                relatedAssetId: assetId || null,
                relatedTxId: null,
                reason: description || "تعهد ناشی از مبادله دارایی",
                status: "open",
              });
              useLedger.getState().addTransaction({
                type: "obligation",
                date,
                description: `تعهد ${people.find((p) => p.id === toId)?.name} به ${people.find((p) => p.id === counterparty)?.name}`,
                poolId: null,
                assetId: assetId || null,
                amount: n,
                currency,
                quantity: null,
                fromPersonIds: [toId],
                toPersonIds: [counterparty],
                splits: [],
                expenseMode: null,
                relatedObligationId: null,
                relatedAssetId: assetId || null,
                fxRateToIrt: currency === "IRT" ? 1 : null,
                fxSource: currency === "IRT" ? "base" : null,
                importSource: null,
                notes: "دریافت‌کننده دارایی و طلبکار می‌توانند افراد متفاوتی باشند.",
              });
              if (assetId) {
                useLedger.getState().updateAsset(assetId, {
                  ownership: [{ personId: toId, percent: 100 }],
                });
              }
            }
            setOpen(false);
            setDescription("");
            setAmount("");
          }}
        >
          ثبت در دفتر
        </Button>
      </DialogContent>
    </Dialog>
  );
}
