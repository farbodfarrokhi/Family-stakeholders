import { useState } from "react";
import { useLedger } from "@/lib/store";
import { Card, CardHint, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/input";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { PersonChip } from "@/components/money";
import { useEngine } from "@/lib/store";
import { faPercent } from "@/lib/format";
import { Money } from "@/components/money";

const COLORS = ["#2f4f4c", "#5c4a3a", "#4a5366", "#3f5348", "#6a5340", "#4e4a5c"];

export function PeopleView() {
  const people = useLedger((s) => s.people);
  const groups = useLedger((s) => s.groups);
  const addPerson = useLedger((s) => s.addPerson);
  const updatePerson = useLedger((s) => s.updatePerson);
  const removePerson = useLedger((s) => s.removePerson);
  const addGroup = useLedger((s) => s.addGroup);
  const updateGroup = useLedger((s) => s.updateGroup);
  const removeGroup = useLedger((s) => s.removeGroup);
  const resetDemo = useLedger((s) => s.resetDemo);
  const engine = useEngine();

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-semibold">افراد و گروه‌ها</h1>
          <p className="mt-2 max-w-xl text-sm text-ink-muted">
            هر فرد حساب سرمایه‌ای جدا دارد. گروه فقط برای گزارش جمعی است؛ واحدهای صندوق همچنان به نام افراد ثبت می‌شود.
          </p>
        </div>
        <div className="flex gap-2">
          <PersonDialog
            title="فرد جدید"
            onSave={(v) => addPerson({ ...v, color: v.color || COLORS[people.length % COLORS.length] })}
          />
          <GroupDialog title="گروه جدید" people={people} onSave={(v) => addGroup(v)} />
        </div>
      </header>

      <div className="grid gap-3 sm:grid-cols-2">
        {people.map((p) => {
          const net = engine.personNets.find((n) => n.personId === p.id);
          return (
            <Card key={p.id}>
              <div className="flex items-start justify-between gap-2">
                <PersonChip name={p.name} color={p.color} />
                <div className="flex gap-1">
                  <PersonDialog
                    title="ویرایش فرد"
                    initial={p}
                    onSave={(v) => updatePerson(p.id, v)}
                    trigger={
                      <Button size="sm" variant="ghost">
                        ویرایش
                      </Button>
                    }
                  />
                  <Button size="sm" variant="ghost" onClick={() => removePerson(p.id)}>
                    حذف
                  </Button>
                </div>
              </div>
              {p.notes && <p className="mt-2 text-sm text-ink-muted">{p.notes}</p>}
              {net && (
                <dl className="mt-3 grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <dt className="text-ink-subtle">سهم صندوق</dt>
                    <dd>{faPercent(net.poolPercent)}</dd>
                  </div>
                  <div>
                    <dt className="text-ink-subtle">خالص</dt>
                    <dd>
                      <Money amount={net.netIrt} />
                    </dd>
                  </div>
                </dl>
              )}
            </Card>
          );
        })}
      </div>

      <Card>
        <CardTitle>گروه‌ها</CardTitle>
        <CardHint>سهم گروه برابر مجموع سهم اعضای آن است.</CardHint>
        <div className="mt-4 space-y-3">
          {groups.map((g) => {
            const gn = engine.groupNets.find((x) => x.groupId === g.id);
            return (
              <div key={g.id} className="rounded-md border border-line p-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="font-medium">{g.name}</div>
                  <div className="flex gap-1">
                    <GroupDialog
                      title="ویرایش گروه"
                      people={people}
                      initial={g}
                      onSave={(v) => updateGroup(g.id, v)}
                      trigger={
                        <Button size="sm" variant="ghost">
                          ویرایش
                        </Button>
                      }
                    />
                    <Button size="sm" variant="ghost" onClick={() => removeGroup(g.id)}>
                      حذف
                    </Button>
                  </div>
                </div>
                <div className="mt-2 flex flex-wrap gap-2 text-sm">
                  {g.memberIds.map((id) => {
                    const p = people.find((x) => x.id === id);
                    return p ? <PersonChip key={id} name={p.name} color={p.color} /> : null;
                  })}
                </div>
                {gn && (
                  <p className="mt-2 text-sm text-ink-muted">
                    سهم جمعی از صندوق {faPercent(gn.poolPercent)} — <Money amount={gn.poolValueIrt} />
                  </p>
                )}
              </div>
            );
          })}
          {!groups.length && <p className="text-sm text-ink-muted">گروهی تعریف نشده است.</p>}
        </div>
      </Card>

      <div className="flex flex-wrap gap-2">
        <Button variant="outline" onClick={() => resetDemo()}>
          بازنشانی دادهٔ نمونه
        </Button>
        <Button
          variant="outline"
          onClick={() => {
            const blob = new Blob(
              [
                JSON.stringify(
                  {
                    version: 1,
                    people: useLedger.getState().people,
                    groups: useLedger.getState().groups,
                    pools: useLedger.getState().pools,
                    assets: useLedger.getState().assets,
                    transactions: useLedger.getState().transactions,
                    obligations: useLedger.getState().obligations,
                    rates: useLedger.getState().rates,
                    settings: useLedger.getState().settings,
                  },
                  null,
                  2,
                ),
              ],
              { type: "application/json" },
            );
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = "sahmban-backup.json";
            a.click();
            URL.revokeObjectURL(url);
          }}
        >
          خروجی پشتیبان JSON
        </Button>
        <label className="inline-flex h-11 cursor-pointer items-center rounded-md border border-line-strong bg-paper-elevated px-4 text-sm">
          بازیابی JSON
          <input
            type="file"
            accept="application/json"
            className="hidden"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              const json = JSON.parse(await file.text());
              useLedger.getState().replaceAll(json);
            }}
          />
        </label>
      </div>
    </div>
  );
}

function PersonDialog({
  title,
  initial,
  onSave,
  trigger,
}: {
  title: string;
  initial?: { name: string; notes: string; color: string };
  onSave: (v: { name: string; notes: string; color: string }) => void;
  trigger?: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState(initial?.name ?? "");
  const [notes, setNotes] = useState(initial?.notes ?? "");
  const [color, setColor] = useState(initial?.color ?? COLORS[0]);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger ?? <Button>{title}</Button>}</DialogTrigger>
      <DialogContent title={title}>
        <div className="space-y-3">
          <Field label="نام">
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="یادداشت">
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
          </Field>
          <Field label="رنگ نمودار">
            <div className="flex gap-2">
              {COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  className="size-8 rounded-full border border-line"
                  style={{ background: c, outline: color === c ? "2px solid #1f4e4a" : undefined }}
                  onClick={() => setColor(c)}
                />
              ))}
            </div>
          </Field>
          <Button
            onClick={() => {
              if (!name.trim()) return;
              onSave({ name: name.trim(), notes, color });
              setOpen(false);
            }}
          >
            ذخیره
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function GroupDialog({
  title,
  people,
  initial,
  onSave,
  trigger,
}: {
  title: string;
  people: { id: string; name: string }[];
  initial?: { name: string; notes: string; memberIds: string[] };
  onSave: (v: { name: string; notes: string; memberIds: string[] }) => void;
  trigger?: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState(initial?.name ?? "");
  const [notes, setNotes] = useState(initial?.notes ?? "");
  const [memberIds, setMemberIds] = useState<string[]>(initial?.memberIds ?? []);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger ?? <Button variant="outline">{title}</Button>}</DialogTrigger>
      <DialogContent title={title}>
        <div className="space-y-3">
          <Field label="نام گروه">
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="اعضا">
            <div className="space-y-2">
              {people.map((p) => (
                <label key={p.id} className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    className="size-4"
                    checked={memberIds.includes(p.id)}
                    onChange={(e) =>
                      setMemberIds(
                        e.target.checked ? [...memberIds, p.id] : memberIds.filter((id) => id !== p.id),
                      )
                    }
                  />
                  {p.name}
                </label>
              ))}
            </div>
          </Field>
          <Field label="یادداشت">
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
          </Field>
          <Button
            onClick={() => {
              if (!name.trim()) return;
              onSave({ name: name.trim(), notes, memberIds });
              setOpen(false);
            }}
          >
            ذخیره
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
