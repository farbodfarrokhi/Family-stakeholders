import { useEngine, useLedgerState } from "@/lib/store";
import { Card, CardHint, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Money, PersonChip } from "@/components/money";
import { faNum, faPercent, toJalali } from "@/lib/format";
import { labelTx } from "@/lib/accounting/engine";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export function DashboardView() {
  const state = useLedgerState();
  const engine = useEngine();
  const pool = state.pools[0];
  const snap = pool ? engine.pools[pool.id] : null;
  const pie = engine.personNets
    .filter((p) => p.poolValueIrt > 0)
    .map((p) => {
      const person = state.people.find((x) => x.id === p.personId);
      return {
        name: person?.name ?? p.personId,
        value: p.poolValueIrt,
        color: person?.color ?? "#5c4a3a",
      };
    });

  const familyNet = engine.personNets.reduce((s, p) => s + p.netIrt, 0);
  const recent = [...state.transactions].sort((a, b) => b.seq - a.seq).slice(0, 6);

  return (
    <div className="space-y-6">
      <header>
        <p className="text-sm text-ink-muted">دفتر حساب خانواده</p>
        <h1 className="mt-1 text-3xl font-semibold tracking-tight">نمای کلی سهم‌ها</h1>
        <p className="mt-2 max-w-2xl text-sm text-ink-muted">
          سهم هر نفر از صندوق نوبیتکس با روش واحد محاسبه می‌شود: واریز واحد می‌خرد، برداشت واحد
          می‌فروشد، هزینهٔ مشترک ارزش واحد را کم می‌کند، و رشد دارایی به نسبت واحد بین همه تقسیم می‌شود.
        </p>
      </header>

      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="ارزش صندوق" value={<Money amount={snap?.navIrt ?? 0} />} hint={pool?.name} />
        <Stat label="خالص خانواده" value={<Money amount={familyNet} />} hint="صندوق + دارایی − بدهی" />
        <Stat
          label="واحدهای صندوق"
          value={<span className="tabular">{faNum(snap?.totalUnits ?? 0, 0)}</span>}
          hint={`هر واحد ${faNum(snap?.navPerUnit ?? 1, 2)} تومان`}
        />
        <Stat
          label="تعهدهای باز"
          value={<span className="tabular">{faNum(engine.openObligations.length)}</span>}
          hint="بدهی بین اعضا"
        />
      </section>

      <section className="grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
        <Card>
          <CardTitle>سهم افراد از صندوق</CardTitle>
          <CardHint>بر اساس تعداد واحد در حال حاضر</CardHint>
          <div className="mt-4 hidden overflow-x-auto sm:block">
            <table className="w-full text-sm">
              <thead className="text-ink-muted">
                <tr className="border-b border-line text-right">
                  <th className="py-2 font-medium">فرد</th>
                  <th className="py-2 font-medium">واحد</th>
                  <th className="py-2 font-medium">درصد</th>
                  <th className="py-2 font-medium">ارزش</th>
                  <th className="py-2 font-medium">خالص کل</th>
                </tr>
              </thead>
              <tbody>
                {engine.personNets.map((row) => {
                  const p = state.people.find((x) => x.id === row.personId);
                  if (!p) return null;
                  return (
                    <tr key={row.personId} className="border-b border-line/70">
                      <td className="py-2.5">
                        <PersonChip name={p.name} color={p.color} />
                      </td>
                      <td className="tabular">{faNum(row.poolUnits, 0)}</td>
                      <td className="tabular">{faPercent(row.poolPercent)}</td>
                      <td>
                        <Money amount={row.poolValueIrt} />
                      </td>
                      <td>
                        <Money amount={row.netIrt} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <ul className="mt-4 space-y-2 sm:hidden">
            {engine.personNets.map((row) => {
              const p = state.people.find((x) => x.id === row.personId);
              if (!p) return null;
              return (
                <li key={row.personId} className="rounded-md bg-paper-inset px-3 py-3">
                  <div className="flex items-center justify-between gap-2">
                    <PersonChip name={p.name} color={p.color} />
                    <span className="text-sm tabular">{faPercent(row.poolPercent)}</span>
                  </div>
                  <div className="mt-1 text-sm">
                    صندوق <Money amount={row.poolValueIrt} />
                  </div>
                  <div className="text-xs text-ink-muted">
                    خالص <Money amount={row.netIrt} />
                  </div>
                </li>
              );
            })}
          </ul>
        </Card>

        <Card>
          <CardTitle>ترکیب مالکیت صندوق</CardTitle>
          <div className="mt-4 h-56">
            {pie.length ? (
              <ResponsiveContainer>
                <PieChart>
                  <Pie data={pie} dataKey="value" nameKey="name" innerRadius={48} outerRadius={80} paddingAngle={2}>
                    {pie.map((e) => (
                      <Cell key={e.name} fill={e.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(v) => formatSafe(Number(v))}
                    contentStyle={{
                      background: "#faf7f1",
                      border: "1px solid #ddd4c6",
                      borderRadius: 8,
                      fontFamily: "Vazirmatn, sans-serif",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-sm text-ink-muted">هنوز واحدی در صندوق نیست.</p>
            )}
          </div>
          <ul className="space-y-1.5 text-sm">
            {pie.map((e) => (
              <li key={e.name} className="flex items-center justify-between">
                <PersonChip name={e.name} color={e.color} />
                <Money amount={e.value} />
              </li>
            ))}
          </ul>
        </Card>
      </section>

      {engine.groupNets.map((g) => {
        const group = state.groups.find((x) => x.id === g.groupId);
        if (!group) return null;
        return (
          <Card key={g.groupId}>
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <CardTitle>گروه {group.name}</CardTitle>
                <CardHint>
                  سهم جمعی از صندوق {faPercent(g.poolPercent)} معادل <Money amount={g.poolValueIrt} />
                </CardHint>
              </div>
              <Badge tone="teal">خالص گروه: {formatSafe(g.netIrt)}</Badge>
            </div>
            <div className="mt-4 grid gap-2 sm:grid-cols-2">
              {g.members.map((m) => {
                const p = state.people.find((x) => x.id === m.personId);
                return (
                  <div key={m.personId} className="rounded-md bg-paper-inset px-3 py-3">
                    <div className="text-sm font-medium">{p?.name}</div>
                    <div className="mt-1 text-xs text-ink-muted">
                      از سهم گروه {faPercent(g.memberShareOfGroup[m.personId] ?? 0)}
                    </div>
                    <div className="mt-1 text-sm">
                      <Money amount={m.poolValueIrt} />
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        );
      })}

      <Card>
        <div className="flex items-center justify-between">
          <CardTitle>آخرین رویدادها</CardTitle>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/ledger">دفتر کامل</Link>
          </Button>
        </div>
        <ul className="mt-3 divide-y divide-line">
          {recent.map((tx) => (
            <li key={tx.id} className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm">
              <div>
                <div className="font-medium">{tx.description}</div>
                <div className="text-xs text-ink-muted">
                  {toJalali(tx.date)} · {labelTx(tx.type)}
                </div>
              </div>
              <Money amount={tx.amount} currency={tx.currency} />
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}

function Stat({ label, value, hint }: { label: string; value: React.ReactNode; hint?: string }) {
  return (
    <Card className="p-4">
      <div className="text-xs text-ink-muted">{label}</div>
      <div className="mt-1 text-lg font-semibold leading-snug">{value}</div>
      {hint && <div className="mt-1 text-xs text-ink-subtle">{hint}</div>}
    </Card>
  );
}

function formatSafe(n: number) {
  return new Intl.NumberFormat("fa-IR").format(Math.round(n)) + " تومان";
}
