import { useState } from "react";
import { useLedger, useLedgerState } from "@/lib/store";
import { Card, CardHint, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Money, PersonChip } from "@/components/money";
import { netBetween } from "@/lib/accounting/engine";
import { faNum, toJalali, todayIso } from "@/lib/format";

export function ObligationsView() {
  const state = useLedgerState();
  const addObligation = useLedger((s) => s.addObligation);
  const updateObligation = useLedger((s) => s.updateObligation);
  const addTransaction = useLedger((s) => s.addTransaction);

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-semibold">بدهی و مطالبات</h1>
          <p className="mt-2 max-w-2xl text-sm text-ink-muted">
            مالکیت دارایی، پرداخت‌کنندهٔ اصلی، و تعهد بازپرداخت سه چیز جدا هستند. مثلاً انگشتر مال فربد است، مادر
            پولش را داده، و فربد به مادر بدهکار است.
          </p>
        </div>
        <ObDialog
          people={state.people}
          assets={state.assets}
          onSave={(v) => {
            addObligation(v);
            addTransaction({
              type: "obligation",
              date: v.createdAt,
              description: v.reason,
              poolId: null,
              assetId: v.relatedAssetId,
              amount: v.amount,
              currency: v.currency,
              quantity: null,
              fromPersonIds: [v.fromPersonId],
              toPersonIds: [v.toPersonId],
              splits: [],
              expenseMode: null,
              relatedObligationId: null,
              relatedAssetId: v.relatedAssetId,
              fxRateToIrt: v.currency === "IRT" ? 1 : null,
              fxSource: v.currency === "IRT" ? "base" : null,
              importSource: null,
              notes: "",
            });
          }}
        />
      </header>

      <Card>
        <CardTitle>تهاتر خالص بین افراد</CardTitle>
        <CardHint>عدد مثبت یعنی نفر ستون از نفر ردیف طلب دارد.</CardHint>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-md text-sm">
            <thead>
              <tr className="text-ink-muted">
                <th className="p-2 text-right font-medium"></th>
                {state.people.map((p) => (
                  <th key={p.id} className="p-2 text-right font-medium">
                    {p.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {state.people.map((row) => (
                <tr key={row.id} className="border-t border-line">
                  <td className="p-2 font-medium">{row.name}</td>
                  {state.people.map((col) => {
                    if (row.id === col.id) return <td key={col.id} className="p-2 text-ink-subtle">—</td>;
                    const n = netBetween(state, row.id, col.id);
                    return (
                      <td key={col.id} className="p-2 tabular">
                        {n === 0 ? "۰" : faNum(n, 0)}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="space-y-3">
        {state.obligations.map((o) => {
          const from = state.people.find((p) => p.id === o.fromPersonId);
          const to = state.people.find((p) => p.id === o.toPersonId);
          const asset = state.assets.find((a) => a.id === o.relatedAssetId);
          return (
            <Card key={o.id}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <CardTitle className="flex flex-wrap items-center gap-2">
                    {from && <PersonChip name={from.name} color={from.color} />}
                    <span className="text-ink-subtle font-normal">بدهکار به</span>
                    {to && <PersonChip name={to.name} color={to.color} />}
                  </CardTitle>
                  <CardHint>{o.reason}</CardHint>
                </div>
                <Badge tone={o.status === "settled" ? "forest" : o.status === "partial" ? "teal" : "rose"}>
                  {o.status === "settled" ? "تسویه‌شده" : o.status === "partial" ? "جزئی" : "باز"}
                </Badge>
              </div>
              <dl className="mt-3 grid gap-2 text-sm sm:grid-cols-3">
                <div>
                  <dt className="text-ink-subtle">مبلغ اولیه</dt>
                  <dd>
                    <Money amount={o.amount} currency={o.currency} />
                  </dd>
                </div>
                <div>
                  <dt className="text-ink-subtle">مانده</dt>
                  <dd>
                    <Money amount={o.remaining} currency={o.currency} />
                  </dd>
                </div>
                <div>
                  <dt className="text-ink-subtle">سررسید</dt>
                  <dd>{o.dueDate ? toJalali(o.dueDate) : "نامشخص"}</dd>
                </div>
              </dl>
              {asset && (
                <p className="mt-2 text-sm text-ink-muted">
                  دارایی مرتبط: {asset.name} — مالک فعلی با پرداخت‌کننده و طلبکار ممکن است یکی نباشد.
                </p>
              )}
              {o.status !== "settled" && (
                <SettleButton
                  remaining={o.remaining}
                  onSettle={(amt) => {
                    const remaining = Math.max(0, o.remaining - amt);
                    updateObligation(o.id, {
                      remaining,
                      status: remaining <= 0 ? "settled" : "partial",
                    });
                    addTransaction({
                      type: "settlement",
                      date: todayIso(),
                      description: `بازپرداخت به ${to?.name ?? ""}`,
                      poolId: null,
                      assetId: o.relatedAssetId,
                      amount: amt,
                      currency: o.currency,
                      quantity: null,
                      fromPersonIds: [o.fromPersonId],
                      toPersonIds: [o.toPersonId],
                      splits: [],
                      expenseMode: null,
                      relatedObligationId: o.id,
                      relatedAssetId: o.relatedAssetId,
                      fxRateToIrt: o.currency === "IRT" ? 1 : null,
                      fxSource: o.currency === "IRT" ? "base" : null,
                      importSource: null,
                      notes: "",
                    });
                  }}
                />
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}

function SettleButton({ remaining, onSettle }: { remaining: number; onSettle: (n: number) => void }) {
  const [amt, setAmt] = useState(String(remaining));
  return (
    <div className="mt-3 flex flex-wrap items-end gap-2">
      <Field label="مبلغ بازپرداخت">
        <Input value={amt} onChange={(e) => setAmt(e.target.value)} inputMode="decimal" />
      </Field>
      <Button onClick={() => onSettle(Number(amt) || 0)}>ثبت تسویه</Button>
    </div>
  );
}

function ObDialog({
  people,
  assets,
  onSave,
}: {
  people: { id: string; name: string }[];
  assets: { id: string; name: string }[];
  onSave: (v: {
    fromPersonId: string;
    toPersonId: string;
    amount: number;
    currency: string;
    remaining: number;
    dueDate: string | null;
    createdAt: string;
    relatedAssetId: string | null;
    relatedTxId: string | null;
    reason: string;
    status: "open";
  }) => void;
}) {
  const [open, setOpen] = useState(false);
  const [fromPersonId, setFrom] = useState(people[0]?.id ?? "");
  const [toPersonId, setTo] = useState(people[1]?.id ?? "");
  const [amount, setAmount] = useState("");
  const [dueDate, setDue] = useState("");
  const [relatedAssetId, setAsset] = useState("");
  const [reason, setReason] = useState("");
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>تعهد جدید</Button>
      </DialogTrigger>
      <DialogContent title="ثبت تعهد">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="بدهکار">
            <Select value={fromPersonId} onChange={(e) => setFrom(e.target.value)}>
              {people.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="طلبکار">
            <Select value={toPersonId} onChange={(e) => setTo(e.target.value)}>
              {people.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="مبلغ (تومان)">
            <Input value={amount} onChange={(e) => setAmount(e.target.value)} inputMode="decimal" />
          </Field>
          <Field label="سررسید">
            <Input type="date" value={dueDate} onChange={(e) => setDue(e.target.value)} />
          </Field>
          <Field label="دارایی مرتبط" className="sm:col-span-2">
            <Select value={relatedAssetId} onChange={(e) => setAsset(e.target.value)}>
              <option value="">—</option>
              {assets.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="علت" className="sm:col-span-2">
            <Textarea value={reason} onChange={(e) => setReason(e.target.value)} />
          </Field>
        </div>
        <Button
          className="mt-4"
          onClick={() => {
            const n = Number(amount) || 0;
            onSave({
              fromPersonId,
              toPersonId,
              amount: n,
              currency: "IRT",
              remaining: n,
              dueDate: dueDate || null,
              createdAt: todayIso(),
              relatedAssetId: relatedAssetId || null,
              relatedTxId: null,
              reason: reason || "تعهد خانوادگی",
              status: "open",
            });
            setOpen(false);
          }}
        >
          ذخیره
        </Button>
      </DialogContent>
    </Dialog>
  );
}
