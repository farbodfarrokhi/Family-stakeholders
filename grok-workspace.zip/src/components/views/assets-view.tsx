import { useState } from "react";
import { useLedger } from "@/lib/store";
import { Card, CardHint, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Money, PersonChip } from "@/components/money";
import { assetClassLabel } from "@/lib/accounting/engine";
import { ASSET_CLASSES, type Asset, type AssetClass } from "@/lib/accounting/types";
import { faNum, faPercent, toJalali, todayIso } from "@/lib/format";

export function AssetsView() {
  const assets = useLedger((s) => s.assets);
  const people = useLedger((s) => s.people);
  const pools = useLedger((s) => s.pools);
  const addAsset = useLedger((s) => s.addAsset);
  const updateAsset = useLedger((s) => s.updateAsset);
  const removeAsset = useLedger((s) => s.removeAsset);

  const grouped = ASSET_CLASSES.map((c) => ({
    class: c,
    items: assets.filter((a) => a.assetClass === c),
  })).filter((g) => g.items.length);

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-semibold">دارایی‌ها</h1>
          <p className="mt-2 max-w-2xl text-sm text-ink-muted">
            هر دارایی جداگانه ثبت می‌شود: بهای تمام‌شده، ارزش روز، مالک، و پرداخت‌کننده. دارایی صندوق با واحدهای
            سرمایه‌ای افراد اداره می‌شود؛ دارایی شخصی می‌تواند مالکیت جزئی داشته باشد.
          </p>
        </div>
        <AssetDialog
          title="دارایی جدید"
          people={people}
          pools={pools}
          onSave={(v) => addAsset(v)}
        />
      </header>

      {grouped.map((g) => (
        <section key={g.class} className="space-y-3">
          <h2 className="text-sm font-medium text-ink-muted">{assetClassLabel(g.class)}</h2>
          <div className="grid gap-3 md:grid-cols-2">
            {g.items.map((a) => (
              <Card key={a.id}>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <CardTitle>{a.name}</CardTitle>
                    <CardHint>
                      {a.symbol ? `${a.symbol} · ` : ""}
                      {faNum(a.quantity, a.assetClass === "crypto" ? 6 : 2)} {a.unit}
                    </CardHint>
                  </div>
                  <Badge tone={a.poolId ? "teal" : "muted"}>{a.poolId ? "صندوق" : "شخصی"}</Badge>
                </div>
                <dl className="mt-3 grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <dt className="text-ink-subtle">بهای تمام‌شده</dt>
                    <dd>
                      <Money amount={a.costBasis} currency={a.costCurrency} />
                    </dd>
                  </div>
                  <div>
                    <dt className="text-ink-subtle">ارزش روز</dt>
                    <dd>
                      <Money amount={a.currentValue} currency={a.valueCurrency} />
                    </dd>
                  </div>
                  <div>
                    <dt className="text-ink-subtle">تاریخ تملک</dt>
                    <dd>{toJalali(a.acquiredAt)}</dd>
                  </div>
                  <div>
                    <dt className="text-ink-subtle">وضعیت</dt>
                    <dd>{a.status === "held" ? "در اختیار" : a.status}</dd>
                  </div>
                </dl>
                {!!a.ownership.length && (
                  <div className="mt-3 text-sm">
                    <div className="text-ink-subtle">مالکیت</div>
                    <ul className="mt-1 space-y-1">
                      {a.ownership.map((o) => {
                        const p = people.find((x) => x.id === o.personId);
                        return (
                          <li key={o.personId} className="flex justify-between">
                            <PersonChip name={p?.name ?? o.personId} color={p?.color ?? "#5c4a3a"} />
                            <span>{faPercent(o.percent)}</span>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                )}
                {!!a.paidBy.length && (
                  <div className="mt-3 text-sm">
                    <div className="text-ink-subtle">پرداخت‌کنندهٔ اصلی</div>
                    <ul className="mt-1 space-y-1">
                      {a.paidBy.map((o) => {
                        const p = people.find((x) => x.id === o.personId);
                        return (
                          <li key={o.personId} className="flex justify-between">
                            <span>{p?.name}</span>
                            <Money amount={o.amount} currency={o.currency} />
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                )}
                {a.notes && <p className="mt-3 text-sm text-ink-muted">{a.notes}</p>}
                <div className="mt-3 flex gap-1">
                  <AssetDialog
                    title="ویرایش دارایی"
                    people={people}
                    pools={pools}
                    initial={a}
                    onSave={(v) => updateAsset(a.id, v)}
                    trigger={
                      <Button size="sm" variant="ghost">
                        ویرایش
                      </Button>
                    }
                  />
                  <Button size="sm" variant="ghost" onClick={() => removeAsset(a.id)}>
                    حذف
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}

function AssetDialog({
  title,
  people,
  pools,
  initial,
  onSave,
  trigger,
}: {
  title: string;
  people: { id: string; name: string }[];
  pools: { id: string; name: string }[];
  initial?: Asset;
  onSave: (v: Omit<Asset, "id">) => void;
  trigger?: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState(initial?.name ?? "");
  const [assetClass, setAssetClass] = useState<AssetClass>(initial?.assetClass ?? "crypto");
  const [symbol, setSymbol] = useState(initial?.symbol ?? "");
  const [quantity, setQuantity] = useState(String(initial?.quantity ?? 1));
  const [unit, setUnit] = useState(initial?.unit ?? "عدد");
  const [costBasis, setCostBasis] = useState(String(initial?.costBasis ?? 0));
  const [currentValue, setCurrentValue] = useState(String(initial?.currentValue ?? 0));
  const [acquiredAt, setAcquiredAt] = useState(initial?.acquiredAt ?? todayIso());
  const [poolId, setPoolId] = useState(initial?.poolId ?? "");
  const [notes, setNotes] = useState(initial?.notes ?? "");
  const [ownerId, setOwnerId] = useState(initial?.ownership[0]?.personId ?? people[0]?.id ?? "");
  const [payerId, setPayerId] = useState(initial?.paidBy[0]?.personId ?? people[0]?.id ?? "");

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger ?? <Button>{title}</Button>}</DialogTrigger>
      <DialogContent title={title}>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="نام">
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="طبقه">
            <Select value={assetClass} onChange={(e) => setAssetClass(e.target.value as AssetClass)}>
              {ASSET_CLASSES.map((c) => (
                <option key={c} value={c}>
                  {assetClassLabel(c)}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="نماد">
            <Input value={symbol} onChange={(e) => setSymbol(e.target.value)} placeholder="USDT" />
          </Field>
          <Field label="واحد شمارش">
            <Input value={unit} onChange={(e) => setUnit(e.target.value)} />
          </Field>
          <Field label="مقدار">
            <Input value={quantity} onChange={(e) => setQuantity(e.target.value)} inputMode="decimal" />
          </Field>
          <Field label="تاریخ تملک">
            <Input type="date" value={acquiredAt} onChange={(e) => setAcquiredAt(e.target.value)} />
          </Field>
          <Field label="بهای تمام‌شده (تومان)">
            <Input value={costBasis} onChange={(e) => setCostBasis(e.target.value)} inputMode="decimal" />
          </Field>
          <Field label="ارزش روز (تومان)">
            <Input value={currentValue} onChange={(e) => setCurrentValue(e.target.value)} inputMode="decimal" />
          </Field>
          <Field label="صندوق">
            <Select value={poolId} onChange={(e) => setPoolId(e.target.value)}>
              <option value="">دارایی شخصی / خانوادگی</option>
              {pools.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="مالک فعلی">
            <Select value={ownerId} onChange={(e) => setOwnerId(e.target.value)}>
              {people.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="پرداخت‌کنندهٔ اصلی">
            <Select value={payerId} onChange={(e) => setPayerId(e.target.value)}>
              {people.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="یادداشت" className="sm:col-span-2">
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
          </Field>
        </div>
        <Button
          className="mt-4"
          onClick={() => {
            if (!name.trim()) return;
            const cost = Number(costBasis) || 0;
            onSave({
              name: name.trim(),
              assetClass,
              symbol,
              quantity: Number(quantity) || 0,
              unit,
              costBasis: cost,
              costCurrency: "IRT",
              currentValue: Number(currentValue) || 0,
              valueCurrency: "IRT",
              acquiredAt,
              poolId: poolId || null,
              ownership: ownerId && !poolId ? [{ personId: ownerId, percent: 100 }] : [],
              paidBy: payerId ? [{ personId: payerId, amount: cost, currency: "IRT" }] : [],
              notes,
              status: "held",
            });
            setOpen(false);
          }}
        >
          ذخیره
        </Button>
      </DialogContent>
    </Dialog>
  );
}
