import { useState } from "react";
import { useLedger, useLedgerState } from "@/lib/store";
import { Card, CardHint, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { Field } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Money } from "@/components/money";
import {
  buildTemplateWorkbook,
  downloadBuffer,
  parseWorkbook,
  rowsToTransactions,
  type ParsedRow,
} from "@/lib/accounting/excel";
import { faNum, toJalali } from "@/lib/format";
import { labelTx } from "@/lib/accounting/engine";

export function ImportView() {
  const state = useLedgerState();
  const importTransactions = useLedger((s) => s.importTransactions);
  const [rows, setRows] = useState<ParsedRow[]>([]);
  const [headers, setHeaders] = useState<string[]>([]);
  const [poolId, setPoolId] = useState(state.pools[0]?.id ?? "");
  const [error, setError] = useState("");
  const [done, setDone] = useState(0);

  async function onFile(file: File) {
    setError("");
    setDone(0);
    try {
      const buf = await file.arrayBuffer();
      const parsed = parseWorkbook(buf);
      setHeaders(parsed.headers);
      setRows(parsed.rows);
    } catch (e) {
      setError(e instanceof Error ? e.message : "خواندن فایل ممکن نشد.");
    }
  }

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-semibold">ورود از اکسل</h1>
        <p className="mt-2 max-w-2xl text-sm text-ink-muted">
          خروجی نوبیتکس یا هر جدول با ستون‌های تاریخ، نوع، مبلغ، ارز، شرح و شخص. ستون‌ها به‌صورت خودکار تشخیص داده
          می‌شوند. مبالغ ریال نوبیتکس به تومان تبدیل می‌گردد.
        </p>
      </header>

      <Card className="flex flex-wrap items-center gap-3">
        <Button
          variant="outline"
          onClick={() => downloadBuffer(buildTemplateWorkbook(), "sahmban-template.xlsx")}
        >
          دانلود نمونه اکسل
        </Button>
        <label className="inline-flex h-11 cursor-pointer items-center rounded-md bg-teal px-4 text-sm text-teal-fg">
          انتخاب فایل
          <input
            type="file"
            accept=".xlsx,.xls,.csv"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void onFile(f);
            }}
          />
        </label>
        <Field label="صندوق مقصد" className="min-w-48">
          <Select value={poolId} onChange={(e) => setPoolId(e.target.value)}>
            <option value="">بدون صندوق</option>
            {state.pools.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </Select>
        </Field>
      </Card>

      {error && (
        <p className="text-sm text-rose" role="alert">
          {error}
        </p>
      )}

      {!!headers.length && (
        <Card>
          <CardTitle>ستون‌های شناسایی‌شده</CardTitle>
          <CardHint>{headers.join(" · ")}</CardHint>
        </Card>
      )}

      {!!rows.length && (
        <>
          <Card className="overflow-x-auto p-0">
            <table className="w-full min-w-xl text-sm">
              <thead>
                <tr className="border-b border-line text-right text-ink-muted">
                  <th className="px-3 py-2 font-medium">تاریخ</th>
                  <th className="px-3 py-2 font-medium">نوع</th>
                  <th className="px-3 py-2 font-medium">شرح</th>
                  <th className="px-3 py-2 font-medium">شخص</th>
                  <th className="px-3 py-2 font-medium">مبلغ</th>
                </tr>
              </thead>
              <tbody>
                {rows.slice(0, 80).map((r, i) => (
                  <tr key={i} className="border-b border-line/70">
                    <td className="px-3 py-2">{toJalali(r.date)}</td>
                    <td className="px-3 py-2">
                      <Badge tone="muted">{labelTx(r.type)}</Badge>
                    </td>
                    <td className="px-3 py-2">{r.description}</td>
                    <td className="px-3 py-2">{r.person || "—"}</td>
                    <td className="px-3 py-2">
                      <Money amount={r.amount} currency={r.currency === "IRR" ? "IRR" : r.currency} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
          <div className="flex items-center gap-3">
            <Button
              onClick={() => {
                const start = state.transactions.reduce((m, t) => Math.max(m, t.seq), 0);
                const txs = rowsToTransactions(rows, state, poolId || null, start);
                importTransactions(txs);
                setDone(txs.length);
                setRows([]);
              }}
            >
              ثبت {faNum(rows.length)} ردیف در دفتر
            </Button>
            {done > 0 && <span className="text-sm text-forest">{faNum(done)} تراکنش وارد شد.</span>}
          </div>
        </>
      )}

      <Card>
        <CardTitle>نکتهٔ نوبیتکس</CardTitle>
        <p className="mt-2 text-sm leading-7 text-ink-muted">
          در خروجی‌های نوبیتکس مبلغ معمولاً به ریال است. اگر ستون ارز «RLS» یا «IRR» باشد، سهم‌بان هنگام ورود آن را
          به تومان تبدیل می‌کند. نام افراد باید با نام ثبت‌شده در بخش افراد یکی باشد تا واریز به حساب همان شخص بنشیند.
        </p>
      </Card>
    </div>
  );
}
