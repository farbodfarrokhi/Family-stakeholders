import { useState } from "react";
import { useLedger } from "@/lib/store";
import { Card, CardHint, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { fetchHistoricalRate, fetchNobitexLatest } from "@/lib/fx";
import { faNum, toJalali, todayIso } from "@/lib/format";

export function RatesView() {
  const rates = useLedger((s) => s.rates);
  const upsertRate = useLedger((s) => s.upsertRate);
  const removeRate = useLedger((s) => s.removeRate);
  const [date, setDate] = useState("2024-06-01");
  const [base, setBase] = useState("USDT");
  const [quote, setQuote] = useState("IRT");
  const [source, setSource] = useState<"nobitex" | "frankfurter" | "currency-api">("nobitex");
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);
  const [manualRate, setManualRate] = useState("");
  const [live, setLive] = useState<string>("");

  async function pull() {
    setBusy(true);
    setStatus("");
    try {
      const res = await fetchHistoricalRate({
        data: { date, base, quote, source },
      });
      upsertRate({
        date: res.date,
        base: res.base,
        quote: res.quote,
        rate: res.rate,
        source: res.source,
      });
      setStatus(
        `نرخ ذخیره‌شد: ۱ ${res.base} = ${faNum(res.rate, res.quote === "IRT" ? 0 : 4)} ${res.quote} — ${res.note}`,
      );
    } catch (e) {
      setStatus(e instanceof Error ? e.message : "خطا در دریافت نرخ");
    } finally {
      setBusy(false);
    }
  }

  async function pullLive() {
    setBusy(true);
    try {
      const res = await fetchNobitexLatest({ data: { src: "usdt", dst: "irt" } });
      setLive(`آخرین قیمت تتر نوبیتکس: ${faNum(res.latestToman, 0)} تومان (خام ریال: ${faNum(res.latestRial, 0)})`);
      upsertRate({
        date: todayIso(),
        base: "USDT",
        quote: "IRT",
        rate: res.latestToman,
        source: "nobitex",
      });
    } catch (e) {
      setLive(e instanceof Error ? e.message : "نوبیتکس در دسترس نیست");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-semibold">نرخ ارز و قیمت تاریخی</h1>
        <p className="mt-2 max-w-2xl text-sm text-ink-muted">
          برای خانوادهٔ ایرانی که در نوبیتکس سرمایه‌گذاری می‌کند، نرخ «دلار به تومان» باید نرخ بازار آزاد باشد نه نرخ
          رسمی. سه منبع آماده است؛ می‌توانید کلید یا پروکسی خودتان را بعداً جایگزین کنید.
        </p>
      </header>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card>
          <Badge tone="teal">پیشنهادی</Badge>
          <CardTitle className="mt-2">نوبیتکس</CardTitle>
          <CardHint>
            تاریخچهٔ روزانهٔ USDTIRT از{" "}
            <span className="font-medium text-ink">api.nobitex.ir/market/udf/history</span>. قیمت به ریال است و سهم‌بان
            برای تومان بر ۱۰ تقسیم می‌کند. نزدیک‌ترین معادل دلار نقدی بازار آزاد.
          </CardHint>
        </Card>
        <Card>
          <CardTitle>فرانکفورتر</CardTitle>
          <CardHint>
            api.frankfurter.dev — رایگان، بدون کلید، نرخ مرجع بانک مرکزی اروپا از ۱۹۹۹. برای USD/EUR/GBP عالی است.
            ریال ایران را ندارد.
          </CardHint>
        </Card>
        <Card>
          <CardTitle>Currency API</CardTitle>
          <CardHint>
            CDN فاوِز احمد، نرخ روزانه بر اساس تاریخ. برای IRR معمولاً نرخ رسمی است و با بازار آزاد فاصله دارد؛ فقط
            به‌عنوان مقایسه استفاده شود.
          </CardHint>
        </Card>
      </div>

      <Card>
        <CardTitle>دریافت نرخ تاریخی</CardTitle>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="تاریخ میلادی">
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
          <Field label="مبدأ">
            <Input value={base} onChange={(e) => setBase(e.target.value.toUpperCase())} />
          </Field>
          <Field label="مقصد">
            <Input value={quote} onChange={(e) => setQuote(e.target.value.toUpperCase())} />
          </Field>
          <Field label="منبع">
            <Select
              value={source}
              onChange={(e) => setSource(e.target.value as "nobitex" | "frankfurter" | "currency-api")}
            >
              <option value="nobitex">نوبیتکس</option>
              <option value="frankfurter">فرانکفورتر</option>
              <option value="currency-api">Currency API</option>
            </Select>
          </Field>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button onClick={() => void pull()} disabled={busy}>
            {busy ? "در حال دریافت…" : "گرفتن و ذخیره"}
          </Button>
          <Button variant="outline" onClick={() => void pullLive()} disabled={busy}>
            قیمت لحظه‌ای تتر
          </Button>
        </div>
        {status && <p className="mt-3 text-sm leading-7 text-ink-muted">{status}</p>}
        {live && <p className="mt-2 text-sm text-ink-muted">{live}</p>}
      </Card>

      <Card>
        <CardTitle>ثبت دستی</CardTitle>
        <CardHint>اگر API در دسترس نبود، نرخ روز را خودتان وارد کنید.</CardHint>
        <div className="mt-3 flex flex-wrap items-end gap-2">
          <Field label="نرخ (تومان برای هر واحد مبدأ)">
            <Input value={manualRate} onChange={(e) => setManualRate(e.target.value)} inputMode="decimal" />
          </Field>
          <Button
            variant="outline"
            onClick={() => {
              const n = Number(manualRate);
              if (!n) return;
              upsertRate({ date, base, quote, rate: n, source: "manual" });
              setManualRate("");
            }}
          >
            افزودن
          </Button>
        </div>
      </Card>

      <Card className="overflow-x-auto p-0">
        <table className="w-full min-w-lg text-sm">
          <thead>
            <tr className="border-b border-line text-right text-ink-muted">
              <th className="px-3 py-2 font-medium">تاریخ</th>
              <th className="px-3 py-2 font-medium">جفت</th>
              <th className="px-3 py-2 font-medium">نرخ</th>
              <th className="px-3 py-2 font-medium">منبع</th>
              <th className="px-3 py-2 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {[...rates]
              .sort((a, b) => b.date.localeCompare(a.date))
              .map((r) => (
                <tr key={r.id} className="border-b border-line/70">
                  <td className="px-3 py-2">
                    {toJalali(r.date)}
                    <div className="text-xs text-ink-subtle">{r.date}</div>
                  </td>
                  <td className="px-3 py-2">
                    {r.base}/{r.quote}
                  </td>
                  <td className="px-3 py-2 tabular">{faNum(r.rate, r.rate >= 100 ? 0 : 4)}</td>
                  <td className="px-3 py-2">{r.source}</td>
                  <td className="px-3 py-2">
                    <Button size="sm" variant="ghost" onClick={() => removeRate(r.id)}>
                      حذف
                    </Button>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
