import { formatMoney } from "@/lib/format";
import { cn } from "@/lib/utils";

export function Money({
  amount,
  currency = "IRT",
  className,
}: {
  amount: number;
  currency?: string;
  className?: string;
}) {
  return <span className={cn("tabular", className)}>{formatMoney(amount, currency)}</span>;
}

export function PersonChip({
  name,
  color,
}: {
  name: string;
  color: string;
}) {
  return (
    <span className="inline-flex items-center gap-1.5 text-sm">
      <span className="size-2.5 rounded-full" style={{ background: color }} />
      {name}
    </span>
  );
}
