import { toGregorian, toJalaali as toJalaaliDate } from "jalaali-js";

export const TOMAN_PER_RIAL = 0.1;
export const RIAL_PER_TOMAN = 10;

export function parseIsoDate(iso: string): Date {
  if (/^\d{4}-\d{2}-\d{2}$/.test(iso)) return new Date(`${iso}T12:00:00`);
  return new Date(iso);
}

export function toJalali(iso: string): string {
  const d = parseIsoDate(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const j = toJalaaliDate(d.getFullYear(), d.getMonth() + 1, d.getDate());
  const mm = String(j.jm).padStart(2, "0");
  const dd = String(j.jd).padStart(2, "0");
  return `${j.jy}/${mm}/${dd}`;
}

export function jalaliToIso(jy: number, jm: number, jd: number): string {
  const g = toGregorian(jy, jm, jd);
  const mm = String(g.gm).padStart(2, "0");
  const dd = String(g.gd).padStart(2, "0");
  return `${g.gy}-${mm}-${dd}`;
}

export function todayIso(): string {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${mm}-${dd}`;
}

export function faNum(n: number, digits = 0): string {
  if (!Number.isFinite(n)) return "—";
  return new Intl.NumberFormat("fa-IR", {
    maximumFractionDigits: digits,
    minimumFractionDigits: digits,
  }).format(n);
}

export function faPercent(n: number): string {
  return `${faNum(n, 2)}٪`;
}

export const CURRENCY_LABEL: Record<string, string> = {
  IRT: "تومان",
  IRR: "ریال",
  USD: "دلار",
  USDT: "تتر",
  EUR: "یورو",
  GBP: "پوند",
  BTC: "بیت‌کوین",
  ETH: "اتریوم",
  GOLD: "طلا",
};

export function currencyLabel(code: string): string {
  return CURRENCY_LABEL[code] ?? code;
}

export function formatMoney(amount: number, currency = "IRT"): string {
  const digits = ["BTC", "ETH"].includes(currency) ? 6 : ["USDT", "USD", "EUR"].includes(currency) ? 2 : 0;
  return `${faNum(amount, digits)} ${currencyLabel(currency)}`;
}

export function rialToToman(rial: number): number {
  return rial * TOMAN_PER_RIAL;
}

export function tomanToRial(toman: number): number {
  return toman * RIAL_PER_TOMAN;
}

export function roundMoney(n: number, digits = 2): number {
  const f = 10 ** digits;
  return Math.round((n + Number.EPSILON) * f) / f;
}

export function roundUnits(n: number): number {
  return roundMoney(n, 8);
}
