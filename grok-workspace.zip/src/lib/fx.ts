import { createServerFn } from "@tanstack/react-start";
import { rialToToman } from "@/lib/format";

export type FxResult = {
  date: string;
  base: string;
  quote: string;
  rate: number;
  source: "frankfurter" | "nobitex" | "currency-api";
  note: string;
};

type Query = {
  date: string;
  base: string;
  quote: string;
  source: "frankfurter" | "nobitex" | "currency-api";
};

async function getJson(url: string): Promise<unknown> {
  const res = await fetch(url, {
    headers: { accept: "application/json" },
    signal: AbortSignal.timeout(12_000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
  return res.json();
}

function isoToUnix(iso: string, end = false): number {
  const d = new Date(end ? `${iso}T23:59:59Z` : `${iso}T00:00:00Z`);
  return Math.floor(d.getTime() / 1000);
}

export const fetchHistoricalRate = createServerFn({ method: "POST" })
  .validator((d: Query) => d)
  .handler(async ({ data }): Promise<FxResult> => {
    const base = data.base.toUpperCase();
    const quote = data.quote.toUpperCase();
    const date = data.date;

    if (data.source === "frankfurter") {
      const url = `https://api.frankfurter.dev/v1/${date}?from=${encodeURIComponent(base)}&to=${encodeURIComponent(quote)}`;
      const json = (await getJson(url)) as {
        date?: string;
        rates?: Record<string, number>;
      };
      const rate = json.rates?.[quote];
      if (rate == null) {
        throw new Error(
          "فرانکفورتر این جفت‌ارز را پوشش نمی‌دهد. برای تومان/ریال از نوبیتکس استفاده کنید.",
        );
      }
      return {
        date: json.date ?? date,
        base,
        quote,
        rate,
        source: "frankfurter",
        note: "نرخ مرجع بانک مرکزی اروپا (روز کاری). ریال ایران را شامل نمی‌شود.",
      };
    }

    if (data.source === "currency-api") {
      const url = `https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@${date}/v1/currencies/${base.toLowerCase()}.min.json`;
      const json = (await getJson(url)) as Record<string, unknown>;
      const bag = json[base.toLowerCase()] as Record<string, number> | undefined;
      const rate = bag?.[quote.toLowerCase()];
      if (rate == null) throw new Error("این جفت‌ارز در Currency API پیدا نشد.");
      return {
        date: String(json.date ?? date),
        base,
        quote,
        rate,
        source: "currency-api",
        note: "نرخ‌های این منبع برای ریال معمولاً نرخ رسمی/بین‌بانکی است، نه بازار آزاد ایران.",
      };
    }

    const nobitexBase = base === "USD" ? "USDT" : base;
    const wantsToman = quote === "IRT" || quote === "IRR" || quote === "RLS" || quote === "TOMAN";
    const symbol = wantsToman ? `${nobitexBase}IRT` : `${nobitexBase}${quote}`;
    const from = isoToUnix(date) - 3 * 86400;
    const to = isoToUnix(date, true) + 86400;
    const url = `https://api.nobitex.ir/market/udf/history?symbol=${encodeURIComponent(symbol)}&resolution=D&from=${from}&to=${to}`;
    const json = (await getJson(url)) as {
      s?: string;
      t?: number[];
      c?: number[];
    };
    if (json.s !== "ok" || !json.t?.length || !json.c?.length) {
      throw new Error("نوبیتکس برای این تاریخ/نماد داده‌ای برنگرداند.");
    }
    let bestIdx = 0;
    let bestDiff = Infinity;
    const target = isoToUnix(date);
    json.t.forEach((t, i) => {
      const d = Math.abs(t - target);
      if (d < bestDiff) {
        bestDiff = d;
        bestIdx = i;
      }
    });
    const closeRial = json.c[bestIdx];
    const closeDate = new Date((json.t[bestIdx] ?? target) * 1000).toISOString().slice(0, 10);
    const rate = quote === "IRR" || quote === "RLS" ? closeRial : rialToToman(closeRial);
    return {
      date: closeDate,
      base: nobitexBase,
      quote: quote === "IRR" || quote === "RLS" ? "IRR" : "IRT",
      rate,
      source: "nobitex",
      note: "قیمت پایانی روزانه نوبیتکس (ریال بازار). برای تومان بر ۱۰ تقسیم شده است. USDT تقریباً معادل دلار نقدی بازار آزاد است.",
    };
  });

export const fetchNobitexLatest = createServerFn({ method: "POST" })
  .validator((d: { src: string; dst: string }) => d)
  .handler(async ({ data }) => {
    const src = data.src.toLowerCase();
    const dst = data.dst.toLowerCase() === "irt" ? "rls" : data.dst.toLowerCase();
    const url = `https://api.nobitex.ir/market/stats?srcCurrency=${encodeURIComponent(src)}&dstCurrency=${encodeURIComponent(dst)}`;
    const json = (await getJson(url)) as {
      status?: string;
      stats?: Record<string, { latest?: string; dayClose?: string }>;
    };
    if (json.status !== "ok" || !json.stats) throw new Error("پاسخ نوبیتکس نامعتبر بود.");
    const key = Object.keys(json.stats)[0];
    const row = key ? json.stats[key] : undefined;
    const latestRial = Number(row?.latest ?? row?.dayClose ?? NaN);
    if (!Number.isFinite(latestRial)) throw new Error("قیمت لحظه‌ای نوبیتکس در دسترس نیست.");
    return {
      symbol: key ?? `${src}-${dst}`,
      latestRial,
      latestToman: rialToToman(latestRial),
    };
  });
