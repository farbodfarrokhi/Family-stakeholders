import * as XLSX from "xlsx";
import { uid } from "@/lib/utils";
import { todayIso } from "@/lib/format";
import type { LedgerState, Transaction, TxType } from "./types";

const HEADER_ALIASES: Record<string, string[]> = {
  date: ["date", "تاریخ", "created_at", "time", "زمان", "روز"],
  type: ["type", "نوع", "transaction_type", "kind", "عملیات"],
  amount: ["amount", "مبلغ", "value", "volume_dst", "price"],
  currency: ["currency", "ارز", "coin", "symbol", "dstcurrency", "src"],
  description: ["description", "شرح", "توضیح", "memo", "details", "title"],
  person: ["person", "شخص", "name", "from", "عضو"],
  quantity: ["quantity", "تعداد", "qty", "volume", "amount_src"],
  symbol: ["market", "بازار", "pair", "نماد"],
};

function norm(s: string): string {
  return s.toLowerCase().replace(/[\s_\-]/g, "").replace(/ي/g, "ی").replace(/ك/g, "ک");
}

function detectColumn(headers: string[], key: keyof typeof HEADER_ALIASES): number {
  const aliases = HEADER_ALIASES[key].map(norm);
  return headers.findIndex((h) => aliases.includes(norm(h)));
}

function parseDate(v: unknown): string {
  if (v instanceof Date && !Number.isNaN(v.getTime())) {
    const mm = String(v.getMonth() + 1).padStart(2, "0");
    const dd = String(v.getDate()).padStart(2, "0");
    return `${v.getFullYear()}-${mm}-${dd}`;
  }
  const s = String(v ?? "").trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
  const j = s.match(/^(\d{4})[\/.-](\d{1,2})[\/.-](\d{1,2})/);
  if (j) {
    const y = Number(j[1]);
    if (y > 1500 && y < 1600) {
      return s; // jalali left as-is if we cannot convert here; engine uses ISO
    }
    const mm = j[2].padStart(2, "0");
    const dd = j[3].padStart(2, "0");
    return `${j[1]}-${mm}-${dd}`;
  }
  return todayIso();
}

function guessType(raw: string): TxType {
  const t = norm(raw);
  if (/(deposit|واریز|شارژ|contribution|in)/.test(t)) return "contribution";
  if (/(withdraw|برداشت|خروج|withdrawal|out)/.test(t)) return "withdrawal";
  if (/(expense|هزینه|خرید\s?کالا)/.test(t)) return "expense";
  if (/(buy|خرید|purchase)/.test(t)) return "purchase";
  if (/(sell|فروش|sale)/.test(t)) return "sale";
  if (/(transfer|انتقال)/.test(t)) return "transfer";
  if (/(gift|هدیه)/.test(t)) return "gift";
  if (/(val|ارزش)/.test(t)) return "valuation";
  return "contribution";
}

function parseAmount(v: unknown): number {
  if (typeof v === "number") return v;
  const s = String(v ?? "").replace(/[,\s]/g, "").replace(/٬/g, "");
  const n = Number(s);
  return Number.isFinite(n) ? n : 0;
}

function guessCurrency(raw: string): string {
  const t = norm(raw);
  if (/(usdt|tether|تتر)/.test(t)) return "USDT";
  if (/(usd|dollar|دلار)/.test(t)) return "USD";
  if (/(btc|bitcoin|بیت)/.test(t)) return "BTC";
  if (/(eth|اتریوم)/.test(t)) return "ETH";
  if (/(eur|یورو)/.test(t)) return "EUR";
  if (/(irr|rial|ریال|rls)/.test(t)) return "IRR";
  if (/(irt|toman|تومان)/.test(t)) return "IRT";
  return raw.toUpperCase() || "IRT";
}

export type ParsedRow = {
  date: string;
  type: TxType;
  amount: number;
  currency: string;
  description: string;
  person: string;
  quantity: number | null;
  raw: Record<string, unknown>;
};

export function parseWorkbook(data: ArrayBuffer): { headers: string[]; rows: ParsedRow[] } {
  const wb = XLSX.read(data, { type: "array", cellDates: true });
  const sheet = wb.Sheets[wb.SheetNames[0]];
  const aoa = XLSX.utils.sheet_to_json<(string | number | Date)[]>(sheet, {
    header: 1,
    defval: "",
    raw: true,
  });
  if (!aoa.length) return { headers: [], rows: [] };
  const headers = (aoa[0] ?? []).map((h) => String(h));
  const iDate = detectColumn(headers, "date");
  const iType = detectColumn(headers, "type");
  const iAmount = detectColumn(headers, "amount");
  const iCur = detectColumn(headers, "currency");
  const iDesc = detectColumn(headers, "description");
  const iPerson = detectColumn(headers, "person");
  const iQty = detectColumn(headers, "quantity");

  const rows: ParsedRow[] = [];
  for (let i = 1; i < aoa.length; i++) {
    const line = aoa[i] ?? [];
    if (line.every((c) => c === "" || c == null)) continue;
    const raw: Record<string, unknown> = {};
    headers.forEach((h, idx) => {
      raw[h] = line[idx];
    });
    const amount = parseAmount(iAmount >= 0 ? line[iAmount] : 0);
    if (!amount && !String(iDesc >= 0 ? line[iDesc] : "").trim()) continue;
    rows.push({
      date: parseDate(iDate >= 0 ? line[iDate] : todayIso()),
      type: guessType(String(iType >= 0 ? line[iType] : "contribution")),
      amount: Math.abs(amount),
      currency: guessCurrency(String(iCur >= 0 ? line[iCur] : "IRT")),
      description: String(iDesc >= 0 ? line[iDesc] : `ردیف ${i}`),
      person: String(iPerson >= 0 ? line[iPerson] : ""),
      quantity: iQty >= 0 && line[iQty] !== "" ? parseAmount(line[iQty]) : null,
      raw,
    });
  }
  return { headers, rows };
}

export function rowsToTransactions(
  rows: ParsedRow[],
  state: LedgerState,
  poolId: string | null,
  startSeq: number,
): Transaction[] {
  const byName = new Map(state.people.map((p) => [p.name.trim(), p.id]));
  return rows.map((row, idx) => {
    const personId = row.person ? byName.get(row.person.trim()) : undefined;
    const isOut = row.type === "withdrawal" || row.type === "expense";
    let amount = row.amount;
    let currency = row.currency;
    if (currency === "IRR") {
      amount = amount / 10;
      currency = "IRT";
    }
    return {
      id: uid("tx"),
      seq: startSeq + idx + 1,
      type: row.type,
      date: row.date,
      description: row.description || "واردشده از اکسل",
      poolId,
      assetId: null,
      amount,
      currency,
      quantity: row.quantity,
      fromPersonIds: personId && isOut ? [personId] : personId ? [personId] : [],
      toPersonIds: personId && !isOut ? [] : [],
      splits: personId && row.type === "contribution" ? [{ personId, percent: 100 }] : [],
      expenseMode: row.type === "expense" ? "pooled" : row.type === "withdrawal" ? "personal" : null,
      relatedObligationId: null,
      relatedAssetId: null,
      fxRateToIrt: currency === "IRT" ? 1 : null,
      fxSource: currency === "IRT" ? "base" : null,
      importSource: "excel",
      notes: "",
    };
  });
}

export function buildTemplateWorkbook(): ArrayBuffer {
  const rows = [
    ["تاریخ", "نوع", "مبلغ", "ارز", "شرح", "شخص", "تعداد"],
    ["2023-04-10", "واریز", 50000000, "IRT", "واریز اولیه فربد", "فربد", ""],
    ["2023-06-15", "واریز", 30000000, "IRT", "واریز مشترک", "فربد", ""],
    ["2023-09-01", "خرید", 10000000, "IRT", "خرید تتر", "", 200],
    ["2024-08-20", "هزینه", 5000000, "IRT", "درمان", "", ""],
    ["2024-12-01", "برداشت", 3000000, "IRT", "برداشت شخصی فربد", "فربد", ""],
  ];
  const ws = XLSX.utils.aoa_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "تراکنش‌ها");
  return XLSX.write(wb, { type: "array", bookType: "xlsx" }) as ArrayBuffer;
}

export function downloadBuffer(buf: ArrayBuffer, filename: string) {
  const blob = new Blob([buf], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
