export const ASSET_CLASSES = [
  "cash",
  "crypto",
  "fiat_foreign",
  "gold",
  "jewelry",
  "vehicle",
  "real_estate",
  "stock",
  "other",
] as const;

export type AssetClass = (typeof ASSET_CLASSES)[number];

export const TX_TYPES = [
  "contribution",
  "withdrawal",
  "expense",
  "purchase",
  "sale",
  "transfer",
  "gift",
  "exchange",
  "valuation",
  "obligation",
  "settlement",
  "ownership_change",
] as const;

export type TxType = (typeof TX_TYPES)[number];

export type Person = {
  id: string;
  name: string;
  notes: string;
  color: string;
};

export type Group = {
  id: string;
  name: string;
  memberIds: string[];
  notes: string;
};

export type Pool = {
  id: string;
  name: string;
  baseCurrency: string;
  notes: string;
};

export type OwnershipSlice = {
  personId: string;
  percent: number;
};

export type PayerSlice = {
  personId: string;
  amount: number;
  currency: string;
};

export type Asset = {
  id: string;
  name: string;
  assetClass: AssetClass;
  symbol: string;
  quantity: number;
  unit: string;
  costBasis: number;
  costCurrency: string;
  currentValue: number;
  valueCurrency: string;
  acquiredAt: string;
  poolId: string | null;
  ownership: OwnershipSlice[];
  paidBy: PayerSlice[];
  notes: string;
  status: "held" | "sold" | "gifted" | "transferred";
};

export type Split = {
  personId: string;
  percent: number;
};

export type Transaction = {
  id: string;
  seq: number;
  type: TxType;
  date: string;
  description: string;
  poolId: string | null;
  assetId: string | null;
  amount: number;
  currency: string;
  quantity: number | null;
  fromPersonIds: string[];
  toPersonIds: string[];
  splits: Split[];
  expenseMode: "pooled" | "personal" | null;
  relatedObligationId: string | null;
  relatedAssetId: string | null;
  fxRateToIrt: number | null;
  fxSource: string | null;
  importSource: string | null;
  notes: string;
};

export type Obligation = {
  id: string;
  fromPersonId: string;
  toPersonId: string;
  amount: number;
  currency: string;
  remaining: number;
  dueDate: string | null;
  createdAt: string;
  relatedAssetId: string | null;
  relatedTxId: string | null;
  reason: string;
  status: "open" | "partial" | "settled";
};

export type RateQuote = {
  id: string;
  date: string;
  base: string;
  quote: string;
  rate: number;
  source: "frankfurter" | "nobitex" | "currency-api" | "manual";
};

export type Settings = {
  displayUnit: "toman" | "rial";
  baseCurrency: "IRT";
  preferredFx: "nobitex" | "frankfurter" | "currency-api" | "manual";
};

export type LedgerState = {
  version: 1;
  people: Person[];
  groups: Group[];
  pools: Pool[];
  assets: Asset[];
  transactions: Transaction[];
  obligations: Obligation[];
  rates: RateQuote[];
  settings: Settings;
};

export type JournalLine = {
  account: string;
  personId: string | null;
  debit: number;
  credit: number;
  memo: string;
};

export type PoolSnapshot = {
  date: string;
  cashIrt: number;
  positions: { assetId: string; quantity: number; valueIrt: number }[];
  units: Record<string, number>;
  totalUnits: number;
  navIrt: number;
  navPerUnit: number;
  sharePercent: Record<string, number>;
  shareValueIrt: Record<string, number>;
};

export type AuditStep = {
  txId: string;
  date: string;
  type: TxType;
  title: string;
  narrative: string[];
  journal: JournalLine[];
  before: PoolSnapshot | null;
  after: PoolSnapshot | null;
  effects: {
    personId: string;
    deltaUnits: number;
    deltaValueIrt: number;
    note: string;
  }[];
};

export type PersonNet = {
  personId: string;
  poolValueIrt: number;
  poolPercent: number;
  poolUnits: number;
  privateAssetsIrt: number;
  receivablesIrt: number;
  payablesIrt: number;
  netIrt: number;
};

export type GroupNet = {
  groupId: string;
  poolValueIrt: number;
  poolPercent: number;
  netIrt: number;
  members: PersonNet[];
  memberShareOfGroup: Record<string, number>;
};

export type EngineResult = {
  asOf: string;
  pools: Record<string, PoolSnapshot>;
  steps: AuditStep[];
  personNets: PersonNet[];
  groupNets: GroupNet[];
  openObligations: Obligation[];
};
