import { faNum, faPercent, formatMoney, roundMoney, roundUnits } from "../format.ts";
import type {
  Asset,
  AuditStep,
  EngineResult,
  GroupNet,
  JournalLine,
  LedgerState,
  Obligation,
  PersonNet,
  PoolSnapshot,
  RateQuote,
  Transaction,
} from "./types";

function emptyUnits(people: LedgerState["people"]): Record<string, number> {
  const u: Record<string, number> = {};
  for (const p of people) u[p.id] = 0;
  return u;
}

function cloneUnits(u: Record<string, number>): Record<string, number> {
  return { ...u };
}

function totalUnitsOf(u: Record<string, number>): number {
  return Object.values(u).reduce((s, n) => s + n, 0);
}

function sharesFromUnits(units: Record<string, number>, navIrt: number) {
  const totalUnits = totalUnitsOf(units);
  const sharePercent: Record<string, number> = {};
  const shareValueIrt: Record<string, number> = {};
  for (const [id, qty] of Object.entries(units)) {
    const pct = totalUnits > 0 ? (qty / totalUnits) * 100 : 0;
    sharePercent[id] = roundMoney(pct, 6);
    shareValueIrt[id] = roundMoney(qty * (totalUnits > 0 ? navIrt / totalUnits : 0), 4);
  }
  return { totalUnits, sharePercent, shareValueIrt };
}

export function convertToIrt(
  amount: number,
  currency: string,
  date: string,
  rates: RateQuote[],
  fallbackRate: number | null,
): { irt: number; rate: number; source: string } {
  if (currency === "IRT" || currency === "TOMAN") {
    return { irt: amount, rate: 1, source: "base" };
  }
  if (currency === "IRR") {
    return { irt: amount / 10, rate: 0.1, source: "rial" };
  }

  const quoteIrt = (base: string) => {
    const exact = rates
      .filter((r) => r.base === base && (r.quote === "IRT" || r.quote === "IRR") && r.date <= date)
      .sort((a, b) => (a.date < b.date ? 1 : -1))[0];
    if (!exact) return null;
    const rate = exact.quote === "IRR" ? exact.rate / 10 : exact.rate;
    return { rate, source: exact.source };
  };

  const hit = quoteIrt(currency);
  if (hit) return { irt: amount * hit.rate, rate: hit.rate, source: hit.source };

  if ((currency === "USD" || currency === "USDT") && quoteIrt(currency === "USD" ? "USDT" : "USD")) {
    const alt = quoteIrt(currency === "USD" ? "USDT" : "USD")!;
    return { irt: amount * alt.rate, rate: alt.rate, source: alt.source };
  }

  if (fallbackRate && fallbackRate > 0) {
    return { irt: amount * fallbackRate, rate: fallbackRate, source: "tx" };
  }

  const any = rates
    .filter((r) => r.base === currency && (r.quote === "IRT" || r.quote === "IRR"))
    .sort((a, b) => (a.date < b.date ? 1 : -1))[0];
  if (any) {
    const rate = any.quote === "IRR" ? any.rate / 10 : any.rate;
    return { irt: amount * rate, rate, source: any.source };
  }

  return { irt: amount, rate: 1, source: "unknown" };
}

function personName(state: LedgerState, id: string): string {
  return state.people.find((p) => p.id === id)?.name ?? id;
}

function assetName(state: LedgerState, id: string | null): string {
  if (!id) return "—";
  return state.assets.find((a) => a.id === id)?.name ?? id;
}

function snapshotOf(
  date: string,
  cashIrt: number,
  positions: PoolSnapshot["positions"],
  units: Record<string, number>,
): PoolSnapshot {
  const navIrt = roundMoney(
    cashIrt + positions.reduce((s, p) => s + p.valueIrt, 0),
    4,
  );
  const { totalUnits, sharePercent, shareValueIrt } = sharesFromUnits(units, navIrt);
  const navPerUnit = totalUnits > 0 ? navIrt / totalUnits : 1;
  return {
    date,
    cashIrt: roundMoney(cashIrt, 4),
    positions: positions.map((p) => ({ ...p })),
    units: cloneUnits(units),
    totalUnits: roundUnits(totalUnits),
    navIrt,
    navPerUnit: roundMoney(navPerUnit, 8),
    sharePercent,
    shareValueIrt,
  };
}

function splitPercents(tx: Transaction, fallbackIds: string[]): { personId: string; percent: number }[] {
  if (tx.splits.length > 0) {
    const sum = tx.splits.reduce((s, x) => s + x.percent, 0) || 100;
    return tx.splits.map((s) => ({ personId: s.personId, percent: (s.percent / sum) * 100 }));
  }
  const ids = fallbackIds.length ? fallbackIds : [];
  if (!ids.length) return [];
  const even = 100 / ids.length;
  return ids.map((personId) => ({ personId, percent: even }));
}

function positionValue(
  asset: Asset,
  qty: number,
  date: string,
  valuations: { date: string; assetId: string; unitPriceIrt: number }[],
  asOfNow: boolean,
): number {
  if (qty === 0) return 0;
  if (asOfNow && asset.currentValue && asset.quantity) {
    return (asset.currentValue / asset.quantity) * qty;
  }
  const last = valuations
    .filter((v) => v.assetId === asset.id && v.date <= date)
    .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0))[0];
  if (last) return last.unitPriceIrt * qty;
  if (asset.costBasis && asset.quantity) return (asset.costBasis / asset.quantity) * qty;
  return 0;
}

function rebuildPositions(
  state: LedgerState,
  poolId: string,
  qtyByAsset: Record<string, number>,
  date: string,
  valuations: { date: string; assetId: string; unitPriceIrt: number }[],
  asOfNow: boolean,
): PoolSnapshot["positions"] {
  const out: PoolSnapshot["positions"] = [];
  for (const asset of state.assets.filter((a) => a.poolId === poolId)) {
    const qty = qtyByAsset[asset.id] ?? 0;
    if (qty === 0) continue;
    out.push({
      assetId: asset.id,
      quantity: qty,
      valueIrt: roundMoney(positionValue(asset, qty, date, valuations, asOfNow), 4),
    });
  }
  return out;
}

export function replay(state: LedgerState, asOf?: string, asOfNow = true): EngineResult {
  const asOfDate = asOf ?? "9999-12-31";
  const txs = [...state.transactions]
    .filter((t) => t.date <= asOfDate)
    .sort((a, b) => (a.date === b.date ? a.seq - b.seq : a.date.localeCompare(b.date)));

  const steps: AuditStep[] = [];
  const poolCash: Record<string, number> = {};
  const poolUnits: Record<string, Record<string, number>> = {};
  const poolQty: Record<string, Record<string, number>> = {};
  const valuations: { date: string; assetId: string; unitPriceIrt: number }[] = [];

  for (const pool of state.pools) {
    poolCash[pool.id] = 0;
    poolUnits[pool.id] = emptyUnits(state.people);
    poolQty[pool.id] = {};
  }

  const assetOwner: Record<string, { personId: string; percent: number }[]> = {};
  for (const a of state.assets) {
    assetOwner[a.id] = a.ownership.map((o) => ({ ...o }));
  }

  const obligations: Obligation[] = state.obligations.map((o) => ({ ...o }));

  for (const tx of txs) {
    const poolId = tx.poolId;
    const before =
      poolId && poolUnits[poolId]
        ? snapshotOf(
            tx.date,
            poolCash[poolId],
            rebuildPositions(state, poolId, poolQty[poolId], tx.date, valuations, false),
            poolUnits[poolId],
          )
        : null;

    const journal: JournalLine[] = [];
    const narrative: string[] = [];
    const effects: AuditStep["effects"] = [];
    const conv = convertToIrt(tx.amount, tx.currency, tx.date, state.rates, tx.fxRateToIrt);
    const amountIrt = roundMoney(conv.irt, 4);

    if (tx.currency !== "IRT" && conv.source !== "base") {
      narrative.push(
        `نرخ تبدیل ${tx.currency} به تومان در تاریخ ${tx.date}: ${faNum(conv.rate, 0)} (منبع: ${conv.source}). مبلغ معادل ${formatMoney(amountIrt, "IRT")}.`,
      );
    }

    if (tx.type === "contribution" && poolId) {
      const snap = before!;
      const navPerUnit = snap.totalUnits > 0 ? snap.navPerUnit : 1;
      const unitsIssued = navPerUnit > 0 ? amountIrt / navPerUnit : amountIrt;
      const parts = splitPercents(tx, tx.fromPersonIds);
      narrative.push(
        snap.totalUnits === 0
          ? "صندوق خالی بود؛ ارزش هر واحد برابر ۱ تومان قرار گرفت."
          : `ارزش صندوق پیش از واریز ${formatMoney(snap.navIrt, "IRT")} و تعداد واحد ${faNum(snap.totalUnits, 2)} بود؛ بنابراین ارزش هر واحد ${faNum(navPerUnit, 4)} تومان است.`,
      );
      narrative.push(
        `مبلغ واریزی ${formatMoney(amountIrt, "IRT")} معادل ${faNum(unitsIssued, 4)} واحد جدید است.`,
      );
      poolCash[poolId] += amountIrt;
      journal.push({
        account: "cash",
        personId: null,
        debit: amountIrt,
        credit: 0,
        memo: "افزایش وجه صندوق",
      });
      for (const part of parts) {
        const u = (unitsIssued * part.percent) / 100;
        poolUnits[poolId][part.personId] = (poolUnits[poolId][part.personId] ?? 0) + u;
        journal.push({
          account: "capital",
          personId: part.personId,
          debit: 0,
          credit: (amountIrt * part.percent) / 100,
          memo: `صدور واحد برای ${personName(state, part.personId)}`,
        });
        effects.push({
          personId: part.personId,
          deltaUnits: u,
          deltaValueIrt: (amountIrt * part.percent) / 100,
          note: `${faPercent(part.percent)} از واریز → ${faNum(u, 4)} واحد`,
        });
        narrative.push(
          `${personName(state, part.personId)} ${faPercent(part.percent)} از این واریز را دارد (${faNum(u, 4)} واحد).`,
        );
      }
    } else if (tx.type === "withdrawal" && poolId) {
      const snap = before!;
      const navPerUnit = snap.navPerUnit || 1;
      const unitsRedeemed = amountIrt / navPerUnit;
      const payer = tx.fromPersonIds[0];
      const available = poolUnits[poolId][payer] ?? 0;
      const redeem = Math.min(unitsRedeemed, available);
      const cashOut = redeem * navPerUnit;
      poolCash[poolId] -= cashOut;
      poolUnits[poolId][payer] = available - redeem;
      journal.push({
        account: "capital",
        personId: payer,
        debit: cashOut,
        credit: 0,
        memo: "بازخرید واحد",
      });
      journal.push({
        account: "cash",
        personId: null,
        debit: 0,
        credit: cashOut,
        memo: "خروج وجه از صندوق",
      });
      effects.push({
        personId: payer,
        deltaUnits: -redeem,
        deltaValueIrt: -cashOut,
        note: "برداشت شخصی از محل واحدهای خودش",
      });
      narrative.push(
        `برداشت شخصی ${personName(state, payer)} به مبلغ ${formatMoney(amountIrt, "IRT")}.`,
      );
      narrative.push(
        `ارزش هر واحد ${faNum(navPerUnit, 4)} تومان بود؛ ${faNum(redeem, 4)} واحد بازخرید شد و سهم سرمایه‌ای او کاهش یافت. ارزش هر واحد بقیهٔ اعضا تغییر نمی‌کند.`,
      );
    } else if (tx.type === "expense" && poolId) {
      const snap = before!;
      if (tx.expenseMode === "personal" && tx.fromPersonIds[0]) {
        const payer = tx.fromPersonIds[0];
        const navPerUnit = snap.navPerUnit || 1;
        const redeem = amountIrt / navPerUnit;
        poolUnits[poolId][payer] = (poolUnits[poolId][payer] ?? 0) - redeem;
        poolCash[poolId] -= amountIrt;
        effects.push({
          personId: payer,
          deltaUnits: -redeem,
          deltaValueIrt: -amountIrt,
          note: "هزینه به حساب شخصی او",
        });
        narrative.push(
          `هزینهٔ ${formatMoney(amountIrt, "IRT")} از سهم ${personName(state, payer)} کسر شد (بازخرید واحد).`,
        );
      } else {
        poolCash[poolId] -= amountIrt;
        journal.push({
          account: "expense",
          personId: null,
          debit: amountIrt,
          credit: 0,
          memo: tx.description || "هزینه مشترک",
        });
        journal.push({
          account: "cash",
          personId: null,
          debit: 0,
          credit: amountIrt,
          memo: "پرداخت از صندوق",
        });
        narrative.push(
          `هزینهٔ مشترک ${formatMoney(amountIrt, "IRT")} از وجه صندوق پرداخت شد. تعداد واحدها ثابت ماند؛ ارزش هر واحد کاهش یافت و همه به نسبت واحدهایشان در هزینه شریک شدند.`,
        );
        if (snap.totalUnits > 0) {
          for (const [pid, u] of Object.entries(snap.units)) {
            if (u <= 0) continue;
            const share = (u / snap.totalUnits) * amountIrt;
            effects.push({
              personId: pid,
              deltaUnits: 0,
              deltaValueIrt: -share,
              note: `تحمل ${faPercent((u / snap.totalUnits) * 100)} از هزینهٔ مشترک`,
            });
          }
        }
      }
    } else if (tx.type === "purchase" && poolId && tx.assetId) {
      const qty = tx.quantity ?? 0;
      poolCash[poolId] -= amountIrt;
      poolQty[poolId][tx.assetId] = (poolQty[poolId][tx.assetId] ?? 0) + qty;
      if (qty > 0) {
        valuations.push({ date: tx.date, assetId: tx.assetId, unitPriceIrt: amountIrt / qty });
      }
      journal.push({
        account: `asset:${tx.assetId}`,
        personId: null,
        debit: amountIrt,
        credit: 0,
        memo: `خرید ${assetName(state, tx.assetId)}`,
      });
      journal.push({
        account: "cash",
        personId: null,
        debit: 0,
        credit: amountIrt,
        memo: "پرداخت از صندوق",
      });
      narrative.push(
        `خرید ${faNum(qty, 6)} ${assetName(state, tx.assetId)} به بهای تمام‌شده ${formatMoney(amountIrt, "IRT")}. وجه نقد کم و دارایی صندوق زیاد شد؛ تعداد واحدها ثابت است.`,
      );
    } else if (tx.type === "sale" && poolId && tx.assetId) {
      const qty = tx.quantity ?? 0;
      poolCash[poolId] += amountIrt;
      poolQty[poolId][tx.assetId] = Math.max(0, (poolQty[poolId][tx.assetId] ?? 0) - qty);
      journal.push({
        account: "cash",
        personId: null,
        debit: amountIrt,
        credit: 0,
        memo: "وجه حاصل از فروش",
      });
      journal.push({
        account: `asset:${tx.assetId}`,
        personId: null,
        debit: 0,
        credit: amountIrt,
        memo: `فروش ${assetName(state, tx.assetId)}`,
      });
      narrative.push(
        `فروش ${faNum(qty, 6)} ${assetName(state, tx.assetId)} به مبلغ ${formatMoney(amountIrt, "IRT")}.`,
      );
    } else if (tx.type === "valuation" && tx.assetId) {
      const qty = tx.quantity ?? state.assets.find((a) => a.id === tx.assetId)?.quantity ?? 0;
      const unit = qty > 0 ? amountIrt / qty : amountIrt;
      valuations.push({ date: tx.date, assetId: tx.assetId, unitPriceIrt: unit });
      narrative.push(
        `ارزش‌گذاری ${assetName(state, tx.assetId)}: ارزش روز ${formatMoney(amountIrt, "IRT")}` +
          (qty ? ` برای ${faNum(qty, 6)} واحد (هر واحد ${formatMoney(unit, "IRT")}).` : "."),
      );
      narrative.push(
        "تعداد واحد صندوق تغییر نمی‌کند؛ سود یا زیان تحقق‌نیافته در ارزش خالص دارایی منعکس می‌شود و به نسبت واحد بین اعضا تقسیم می‌گردد.",
      );
    } else if (tx.type === "transfer" || tx.type === "gift" || tx.type === "exchange" || tx.type === "ownership_change") {
      const assetId = tx.assetId ?? tx.relatedAssetId;
      if (assetId && tx.toPersonIds.length) {
        const parts = splitPercents(tx, tx.toPersonIds);
        assetOwner[assetId] = parts.map((p) => ({ personId: p.personId, percent: p.percent }));
        narrative.push(
          `مالکیت «${assetName(state, assetId)}» به ${parts.map((p) => `${personName(state, p.personId)} (${faPercent(p.percent)})`).join("، ")} منتقل شد.`,
        );
        if (tx.fromPersonIds.length) {
          narrative.push(
            `انتقال‌دهنده: ${tx.fromPersonIds.map((id) => personName(state, id)).join("، ")}.`,
          );
        }
        if (tx.type === "gift") {
          narrative.push("این انتقال هدیه است و به‌خودی‌خود بدهی ایجاد نمی‌کند.");
        }
        if (tx.type === "exchange" && amountIrt > 0) {
          narrative.push(`ارزش توافقی مبادله: ${formatMoney(amountIrt, "IRT")}.`);
        }
      }
      if (tx.type === "transfer" && poolId && tx.fromPersonIds[0] && tx.toPersonIds[0] && amountIrt > 0) {
        const from = tx.fromPersonIds[0];
        const to = tx.toPersonIds[0];
        const navPerUnit = before?.navPerUnit || 1;
        const u = amountIrt / navPerUnit;
        poolUnits[poolId][from] = (poolUnits[poolId][from] ?? 0) - u;
        poolUnits[poolId][to] = (poolUnits[poolId][to] ?? 0) + u;
        effects.push({ personId: from, deltaUnits: -u, deltaValueIrt: -amountIrt, note: "انتقال واحد" });
        effects.push({ personId: to, deltaUnits: u, deltaValueIrt: amountIrt, note: "دریافت واحد" });
        narrative.push(
          `${faNum(u, 4)} واحد صندوق از ${personName(state, from)} به ${personName(state, to)} منتقل شد.`,
        );
      }
    } else if (tx.type === "obligation") {
      narrative.push(
        `تعهد ثبت شد: ${personName(state, tx.fromPersonIds[0] ?? "")} باید ${formatMoney(amountIrt, tx.currency === "IRT" ? "IRT" : tx.currency)} به ${personName(state, tx.toPersonIds[0] ?? "")} بپردازد.`,
      );
      if (tx.relatedAssetId) {
        narrative.push(
          `این تعهد مربوط به دارایی «${assetName(state, tx.relatedAssetId)}» است. مالکیت دارایی از هویت پرداخت‌کننده و هویت طلبکار جدا ثبت شده است.`,
        );
      }
    } else if (tx.type === "settlement") {
      const ob = obligations.find((o) => o.id === tx.relatedObligationId);
      if (ob) {
        ob.remaining = Math.max(0, ob.remaining - tx.amount);
        ob.status = ob.remaining <= 0.0001 ? "settled" : "partial";
      }
      narrative.push(`بازپرداخت ${formatMoney(tx.amount, tx.currency)} بابت تعهد.`);
    } else if (tx.type === "contribution") {
      narrative.push(`واریز ${formatMoney(amountIrt, "IRT")} خارج از صندوق (ثبت سرمایه‌ای شخصی).`);
    } else if (tx.type === "withdrawal") {
      narrative.push(`برداشت ${formatMoney(amountIrt, "IRT")} خارج از صندوق.`);
    }

    const after =
      poolId && poolUnits[poolId]
        ? snapshotOf(
            tx.date,
            poolCash[poolId],
            rebuildPositions(state, poolId, poolQty[poolId], tx.date, valuations, false),
            poolUnits[poolId],
          )
        : null;

    if (after && before && after.totalUnits > 0) {
      narrative.push(
        `پس از این رویداد: ارزش صندوق ${formatMoney(after.navIrt, "IRT")}، تعداد واحد ${faNum(after.totalUnits, 2)}، ارزش هر واحد ${faNum(after.navPerUnit, 4)} تومان.`,
      );
    }

    steps.push({
      txId: tx.id,
      date: tx.date,
      type: tx.type,
      title: tx.description || labelTx(tx.type),
      narrative,
      journal,
      before,
      after,
      effects,
    });
  }

  const pools: Record<string, PoolSnapshot> = {};
  for (const pool of state.pools) {
    pools[pool.id] = snapshotOf(
      asOf ?? todayStamp(),
      poolCash[pool.id] ?? 0,
      rebuildPositions(state, pool.id, poolQty[pool.id] ?? {}, asOf ?? todayStamp(), valuations, asOfNow),
      poolUnits[pool.id] ?? emptyUnits(state.people),
    );
  }

  const mainPool = state.pools[0]?.id;
  const mainSnap = mainPool ? pools[mainPool] : null;

  const personNets: PersonNet[] = state.people.map((person) => {
    const poolUnitsQty = mainSnap?.units[person.id] ?? 0;
    const poolValueIrt = mainSnap?.shareValueIrt[person.id] ?? 0;
    const poolPercent = mainSnap?.sharePercent[person.id] ?? 0;
    let privateAssetsIrt = 0;
    for (const asset of state.assets) {
      if (asset.poolId) continue;
      if (asset.status !== "held") continue;
      const own = (assetOwner[asset.id] ?? asset.ownership).find((o) => o.personId === person.id);
      if (!own) continue;
      const val = convertToIrt(asset.currentValue, asset.valueCurrency, asOf ?? todayStamp(), state.rates, null).irt;
      privateAssetsIrt += (val * own.percent) / 100;
    }
    let receivablesIrt = 0;
    let payablesIrt = 0;
    for (const ob of obligations) {
      if (ob.status === "settled") continue;
      const irt = convertToIrt(ob.remaining, ob.currency, asOf ?? todayStamp(), state.rates, null).irt;
      if (ob.toPersonId === person.id) receivablesIrt += irt;
      if (ob.fromPersonId === person.id) payablesIrt += irt;
    }
    return {
      personId: person.id,
      poolValueIrt: roundMoney(poolValueIrt, 2),
      poolPercent: roundMoney(poolPercent, 4),
      poolUnits: roundUnits(poolUnitsQty),
      privateAssetsIrt: roundMoney(privateAssetsIrt, 2),
      receivablesIrt: roundMoney(receivablesIrt, 2),
      payablesIrt: roundMoney(payablesIrt, 2),
      netIrt: roundMoney(poolValueIrt + privateAssetsIrt + receivablesIrt - payablesIrt, 2),
    };
  });

  const groupNets: GroupNet[] = state.groups.map((g) => {
    const members = personNets.filter((p) => g.memberIds.includes(p.personId));
    const poolValueIrt = members.reduce((s, m) => s + m.poolValueIrt, 0);
    const netIrt = members.reduce((s, m) => s + m.netIrt, 0);
    const poolPercent = members.reduce((s, m) => s + m.poolPercent, 0);
    const memberShareOfGroup: Record<string, number> = {};
    for (const m of members) {
      memberShareOfGroup[m.personId] = poolValueIrt > 0 ? (m.poolValueIrt / poolValueIrt) * 100 : 0;
    }
    return { groupId: g.id, poolValueIrt, poolPercent, netIrt, members, memberShareOfGroup };
  });

  return {
    asOf: asOf ?? todayStamp(),
    pools,
    steps,
    personNets,
    groupNets,
    openObligations: obligations.filter((o) => o.status !== "settled"),
  };
}

function todayStamp(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function labelTx(type: Transaction["type"]): string {
  const map: Record<Transaction["type"], string> = {
    contribution: "واریز به صندوق",
    withdrawal: "برداشت شخصی",
    expense: "هزینه",
    purchase: "خرید دارایی",
    sale: "فروش دارایی",
    transfer: "انتقال",
    gift: "هدیه",
    exchange: "مبادله / تسویه چندطرفه",
    valuation: "ارزش‌گذاری",
    obligation: "ثبت تعهد",
    settlement: "بازپرداخت تعهد",
    ownership_change: "تغییر مالکیت",
  };
  return map[type];
}

export function assetClassLabel(c: Asset["assetClass"]): string {
  const map: Record<Asset["assetClass"], string> = {
    cash: "نقد",
    crypto: "رمزارز",
    fiat_foreign: "ارز خارجی",
    gold: "طلا",
    jewelry: "جواهرات",
    vehicle: "وسیله نقلیه",
    real_estate: "ملک",
    stock: "سهام",
    other: "سایر",
  };
  return map[c];
}

export function netBetween(state: LedgerState, a: string, b: string): number {
  let n = 0;
  for (const o of state.obligations) {
    if (o.status === "settled") continue;
    const irt = convertToIrt(o.remaining, o.currency, o.createdAt, state.rates, null).irt;
    if (o.fromPersonId === a && o.toPersonId === b) n -= irt;
    if (o.fromPersonId === b && o.toPersonId === a) n += irt;
  }
  return roundMoney(n, 2);
}
