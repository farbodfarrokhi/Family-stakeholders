import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createDemoLedger, DEMO_IDS } from "./demo.ts";
import { replay } from "./engine.ts";

describe("family pool NAV", () => {
  const state = createDemoLedger();
  const result = replay(state, "2026-09-01", true);
  const pool = result.pools[DEMO_IDS.POOL];
  const farbod = result.personNets.find((p) => p.personId === DEMO_IDS.FARBOD)!;
  const sara = result.personNets.find((p) => p.personId === DEMO_IDS.SARA)!;
  const hossein = result.personNets.find((p) => p.personId === DEMO_IDS.HOSSEIN)!;
  const group = result.groupNets.find((g) => g.groupId === DEMO_IDS.SIBLINGS)!;

  it("issues units on first contribution at NAV 1", () => {
    const step = result.steps.find((s) => s.txId === "tx_c1")!;
    assert.equal(step.after?.totalUnits, 50_000_000);
    assert.equal(step.after?.units[DEMO_IDS.FARBOD], 50_000_000);
  });

  it("splits a joint contribution 60/40", () => {
    const step = result.steps.find((s) => s.txId === "tx_c2")!;
    assert.ok(step.after);
    assert.equal(Math.round(step.after!.units[DEMO_IDS.SARA]), 12_000_000);
    assert.equal(Math.round(step.after!.units[DEMO_IDS.FARBOD]), 68_000_000);
  });

  it("keeps units constant on pooled expense so everyone bears it", () => {
    const before = result.steps.find((s) => s.txId === "tx_exp")!.before!;
    const after = result.steps.find((s) => s.txId === "tx_exp")!.after!;
    assert.equal(Math.round(before.totalUnits), Math.round(after.totalUnits));
    assert.ok(after.navIrt < before.navIrt);
  });

  it("redeems only Farbod units on personal withdrawal", () => {
    const before = result.steps.find((s) => s.txId === "tx_wd")!.before!;
    const after = result.steps.find((s) => s.txId === "tx_wd")!.after!;
    assert.ok(after.units[DEMO_IDS.FARBOD] < before.units[DEMO_IDS.FARBOD]);
    assert.equal(Math.round(after.units[DEMO_IDS.SARA]), Math.round(before.units[DEMO_IDS.SARA]));
  });

  it("allocates current pool value by units", () => {
    assert.ok(pool.navIrt > 0);
    const sum = farbod.poolValueIrt + sara.poolValueIrt + hossein.poolValueIrt;
    assert.ok(Math.abs(sum - pool.navIrt) < 2);
    assert.ok(farbod.poolPercent > sara.poolPercent);
    assert.ok(farbod.poolPercent > hossein.poolPercent);
  });

  it("computes sibling group as sum of members", () => {
    assert.ok(Math.abs(group.poolValueIrt - (farbod.poolValueIrt + sara.poolValueIrt)) < 1);
    const within = group.memberShareOfGroup[DEMO_IDS.FARBOD];
    assert.ok(within > 50);
  });

  it("keeps the ring owned by Farbod and payable to mother", () => {
    assert.equal(farbod.payablesIrt, 8_000_000);
    const maryam = result.personNets.find((p) => p.personId === DEMO_IDS.MARYAM)!;
    assert.equal(maryam.receivablesIrt, 8_000_000);
    assert.ok(farbod.privateAssetsIrt > 0);
  });

  it("writes an auditable narrative for each pool event", () => {
    for (const step of result.steps) {
      assert.ok(step.narrative.length > 0, step.txId);
    }
  });
});
