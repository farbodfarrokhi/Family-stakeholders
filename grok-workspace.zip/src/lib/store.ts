import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { useShallow } from "zustand/react/shallow";
import { useMemo } from "react";
import { createDemoLedger } from "@/lib/accounting/demo";
import { replay } from "@/lib/accounting/engine";
import type {
  Asset,
  Group,
  LedgerState,
  Obligation,
  Person,
  Pool,
  RateQuote,
  Transaction,
} from "@/lib/accounting/types";
import { uid } from "@/lib/utils";

type Actions = {
  hydrated: boolean;
  setHydrated: (v: boolean) => void;
  resetDemo: () => void;
  replaceAll: (state: LedgerState) => void;
  addPerson: (p: Omit<Person, "id"> & { id?: string }) => string;
  updatePerson: (id: string, patch: Partial<Person>) => void;
  removePerson: (id: string) => void;
  addGroup: (g: Omit<Group, "id"> & { id?: string }) => string;
  updateGroup: (id: string, patch: Partial<Group>) => void;
  removeGroup: (id: string) => void;
  addPool: (p: Omit<Pool, "id"> & { id?: string }) => string;
  addAsset: (a: Omit<Asset, "id"> & { id?: string }) => string;
  updateAsset: (id: string, patch: Partial<Asset>) => void;
  removeAsset: (id: string) => void;
  addTransaction: (t: Omit<Transaction, "id" | "seq"> & { id?: string }) => string;
  updateTransaction: (id: string, patch: Partial<Transaction>) => void;
  removeTransaction: (id: string) => void;
  addObligation: (o: Omit<Obligation, "id"> & { id?: string }) => string;
  updateObligation: (id: string, patch: Partial<Obligation>) => void;
  removeObligation: (id: string) => void;
  upsertRate: (r: Omit<RateQuote, "id"> & { id?: string }) => string;
  removeRate: (id: string) => void;
  importTransactions: (txs: Transaction[]) => void;
};

export type Store = LedgerState & Actions;

const demo = createDemoLedger();

export const useLedger = create<Store>()(
  persist(
    (set, get) => ({
      ...demo,
      hydrated: false,
      setHydrated: (v) => set({ hydrated: v }),
      resetDemo: () => set({ ...createDemoLedger(), hydrated: true }),
      replaceAll: (state) => set({ ...state, hydrated: true }),
      addPerson: (p) => {
        const id = p.id ?? uid("p");
        set({ people: [...get().people, { ...p, id }] });
        return id;
      },
      updatePerson: (id, patch) =>
        set({ people: get().people.map((x) => (x.id === id ? { ...x, ...patch } : x)) }),
      removePerson: (id) =>
        set({
          people: get().people.filter((x) => x.id !== id),
          groups: get().groups.map((g) => ({
            ...g,
            memberIds: g.memberIds.filter((m) => m !== id),
          })),
        }),
      addGroup: (g) => {
        const id = g.id ?? uid("g");
        set({ groups: [...get().groups, { ...g, id }] });
        return id;
      },
      updateGroup: (id, patch) =>
        set({ groups: get().groups.map((x) => (x.id === id ? { ...x, ...patch } : x)) }),
      removeGroup: (id) => set({ groups: get().groups.filter((x) => x.id !== id) }),
      addPool: (p) => {
        const id = p.id ?? uid("pool");
        set({ pools: [...get().pools, { ...p, id }] });
        return id;
      },
      addAsset: (a) => {
        const id = a.id ?? uid("a");
        set({ assets: [...get().assets, { ...a, id }] });
        return id;
      },
      updateAsset: (id, patch) =>
        set({ assets: get().assets.map((x) => (x.id === id ? { ...x, ...patch } : x)) }),
      removeAsset: (id) => set({ assets: get().assets.filter((x) => x.id !== id) }),
      addTransaction: (t) => {
        const id = t.id ?? uid("tx");
        const seq = get().transactions.reduce((m, x) => Math.max(m, x.seq), 0) + 1;
        set({ transactions: [...get().transactions, { ...t, id, seq }] });
        return id;
      },
      updateTransaction: (id, patch) =>
        set({
          transactions: get().transactions.map((x) => (x.id === id ? { ...x, ...patch } : x)),
        }),
      removeTransaction: (id) =>
        set({ transactions: get().transactions.filter((x) => x.id !== id) }),
      addObligation: (o) => {
        const id = o.id ?? uid("ob");
        set({ obligations: [...get().obligations, { ...o, id }] });
        return id;
      },
      updateObligation: (id, patch) =>
        set({
          obligations: get().obligations.map((x) => (x.id === id ? { ...x, ...patch } : x)),
        }),
      removeObligation: (id) => set({ obligations: get().obligations.filter((x) => x.id !== id) }),
      upsertRate: (r) => {
        const existing = get().rates.find(
          (x) => x.date === r.date && x.base === r.base && x.quote === r.quote && x.source === r.source,
        );
        if (existing) {
          set({
            rates: get().rates.map((x) => (x.id === existing.id ? { ...existing, ...r } : x)),
          });
          return existing.id;
        }
        const id = r.id ?? uid("r");
        set({ rates: [...get().rates, { ...r, id }] });
        return id;
      },
      removeRate: (id) => set({ rates: get().rates.filter((x) => x.id !== id) }),
      importTransactions: (txs) => set({ transactions: [...get().transactions, ...txs] }),
    }),
    {
      name: "sahmban-ledger-v1",
      storage: createJSONStorage(() => {
        if (typeof window === "undefined") {
          return {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
          };
        }
        return localStorage;
      }),
      skipHydration: true,
      partialize: (s) => ({
        version: s.version,
        people: s.people,
        groups: s.groups,
        pools: s.pools,
        assets: s.assets,
        transactions: s.transactions,
        obligations: s.obligations,
        rates: s.rates,
        settings: s.settings,
      }),
    },
  ),
);

const ledgerKeys = (s: Store): LedgerState => ({
  version: s.version,
  people: s.people,
  groups: s.groups,
  pools: s.pools,
  assets: s.assets,
  transactions: s.transactions,
  obligations: s.obligations,
  rates: s.rates,
  settings: s.settings,
});

export function useLedgerState(): LedgerState {
  return useLedger(useShallow(ledgerKeys));
}

export function useEngine(asOf?: string) {
  const state = useLedgerState();
  return useMemo(() => replay(state, asOf, !asOf), [state, asOf]);
}
